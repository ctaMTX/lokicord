package b.a.t.b.a;

import com.discord.simpleast.core.node.Node;

/** TextNode.kt */
public class a extends Node {

    public a(String text) { }

}
