package b.a.i;

import android.view.View;
import android.widget.TextView;

import com.facebook.drawee.span.SimpleDraweeSpanTextView;

/** ViewUsernameBinding.java */
public class g4 {

    /** root view */
    public View a;

    public TextView b;

    public SimpleDraweeSpanTextView c;

    public View getRoot() {
        return null;
    }
}
