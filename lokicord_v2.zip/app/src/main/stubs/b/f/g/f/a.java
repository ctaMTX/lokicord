package b.f.g.f;

/** GenericDraweeHierarchyBuilder.java */
public class a {
    /** RoundingParams */
    public c r;
}
