package b.f.g.f;

/** RoundingParams.java */
public class c {
    public boolean b;
    public float[] c;
}
