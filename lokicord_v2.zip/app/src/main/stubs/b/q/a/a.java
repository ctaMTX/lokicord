package b.q.a;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

/** Ucrop */
public class a {

    public Intent a;

    /**
     * The bundle we use to pass in arguments.
     * Proguard removed the builder classes, so we must add to the Bundle directly.
     */
    public Bundle b;

    public a(Uri src, Uri dest) {}

}
