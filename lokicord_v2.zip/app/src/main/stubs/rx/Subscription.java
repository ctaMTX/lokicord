package rx;

/* loaded from: classes3.dex */
public interface Subscription {
    boolean isUnsubscribed();

    void unsubscribe();
}