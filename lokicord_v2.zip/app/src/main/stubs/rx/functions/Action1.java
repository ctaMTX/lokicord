package rx.functions;

/* loaded from: classes3.dex */
public interface Action1<T> {
    void call(T t);
}