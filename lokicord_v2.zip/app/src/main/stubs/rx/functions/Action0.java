package rx.functions;

public interface Action0 {
    void call();
}