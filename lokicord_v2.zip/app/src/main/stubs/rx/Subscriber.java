package rx;

public class Subscriber<T> {
}
