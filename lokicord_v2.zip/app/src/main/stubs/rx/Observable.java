package rx;

import java.util.List;

import rx.functions.Action1;

public class Observable<T> {

    public interface a<T> extends Action1<Subscriber<? super T>> {
    }

    public final Subscription U(Subscriber<? super T> subscriber) {
       return null;
    }

    public static <T> Observable<T> H(Observable<? extends Observable<? extends T>> observable) {
        return null;
    }

    public static <T> Observable<T> h0(a<T> aVar) {
        return null;
    }

    /** toList */
    public final Observable<List<T>> f0() {
        return null;
    }

    /** take() */
    public Observable<T> Z(int number) {
        return this;
    }
}
