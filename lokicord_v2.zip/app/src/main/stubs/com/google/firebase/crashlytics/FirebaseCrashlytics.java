package com.google.firebase.crashlytics;

public class FirebaseCrashlytics {

    public static FirebaseCrashlytics getInstance() {
        return new FirebaseCrashlytics();
    }

    public void setCustomKey(String key, String value) {}

}
