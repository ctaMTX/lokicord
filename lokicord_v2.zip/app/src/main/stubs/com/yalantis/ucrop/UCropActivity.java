package com.yalantis.ucrop;

public class UCropActivity {
}
