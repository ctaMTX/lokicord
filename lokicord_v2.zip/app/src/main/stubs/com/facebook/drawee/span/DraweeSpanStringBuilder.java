package com.facebook.drawee.span;

import android.text.SpannableStringBuilder;

public class DraweeSpanStringBuilder extends SpannableStringBuilder {
}
