package com.lytefast.flexinput.viewmodel;

public interface FlexInputViewModel {

    boolean hideExpressionTray();

}