package com.lytefast.flexinput.fragment;

import com.lytefast.flexinput.viewmodel.FlexInputViewModel;

public class FlexInputFragment {
    public FlexInputViewModel s;
}