package com.discord.widgets.chat.input;

import com.discord.api.sticker.Sticker;
import com.discord.widgets.chat.input.sticker.StickerPickerListener;

public class WidgetChatInputAttachments$createAndConfigureExpressionFragment$stickerPickerListener$1 implements StickerPickerListener {
    public WidgetChatInputAttachments this$0;

    @Override
    public void onStickerPicked(Sticker sticker) {

    }
}
