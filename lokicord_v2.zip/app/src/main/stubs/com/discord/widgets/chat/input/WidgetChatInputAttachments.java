package com.discord.widgets.chat.input;

import com.lytefast.flexinput.fragment.FlexInputFragment;

public class WidgetChatInputAttachments {
    public FlexInputFragment access$getFlexInputFragment$p(WidgetChatInputAttachments attachments) {
        return null;
    }
}
