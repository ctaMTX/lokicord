package com.discord.widgets.chat.input.sticker;

import com.discord.api.sticker.Sticker;
import com.discord.utilities.stickers.StickerUtils;

public class StickerItem {

    public final StickerUtils.StickerSendability getSendability() { return null; }

    public final Sticker getSticker() { return null; }

    public StickerUtils.StickerSendability getRealSendability() { return null; }
}
