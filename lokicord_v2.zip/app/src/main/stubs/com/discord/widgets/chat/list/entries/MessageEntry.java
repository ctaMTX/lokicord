package com.discord.widgets.chat.list.entries;

import com.discord.models.message.Message;

public class MessageEntry {
    public Message getMessage() {
        return null;
    }
}
