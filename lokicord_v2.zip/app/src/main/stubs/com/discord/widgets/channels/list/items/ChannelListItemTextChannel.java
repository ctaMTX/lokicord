package com.discord.widgets.channels.list.items;

import com.discord.api.channel.Channel;

public class ChannelListItemTextChannel {
    public final Channel getChannel() {
        return null;
    }
}
