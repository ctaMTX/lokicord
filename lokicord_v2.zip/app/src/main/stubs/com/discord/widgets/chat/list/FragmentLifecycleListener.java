package com.discord.widgets.chat.list;

@SuppressWarnings("unused")
public interface FragmentLifecycleListener {
    void onPause();
    void onResume();
}