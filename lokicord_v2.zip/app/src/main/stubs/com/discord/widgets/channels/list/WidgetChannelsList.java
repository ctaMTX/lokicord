package com.discord.widgets.channels.list;

import androidx.fragment.app.Fragment;

public class WidgetChannelsList extends Fragment {

    public static WidgetChannelsListAdapter access$getAdapter$p(WidgetChannelsList fragment) {
        return null;
    }

    public static void access$setSelectedGuildId$p(WidgetChannelsList list, Long id) {}

    public void onViewBoundOrOnResume() {}

    public void scrollToTop() {}

}
