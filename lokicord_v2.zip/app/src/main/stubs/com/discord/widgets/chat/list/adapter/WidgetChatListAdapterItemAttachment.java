package com.discord.widgets.chat.list.adapter;

import android.content.Context;

import com.discord.api.message.attachment.MessageAttachment;

public class WidgetChatListAdapterItemAttachment {

    public static final Companion Companion = new Companion();

    public static class Companion {
        public static void access$navigateToAttachment(WidgetChatListAdapterItemAttachment.Companion companion, Context context, MessageAttachment attachment) {

        }
    }
}
