package com.discord.widgets.channels.list.items;

import com.discord.utilities.mg_recycler.MGRecyclerDataPayload;

public abstract class ChannelListItem implements MGRecyclerDataPayload {
}
