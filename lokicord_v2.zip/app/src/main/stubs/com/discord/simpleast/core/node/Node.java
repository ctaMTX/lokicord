package com.discord.simpleast.core.node;

public class Node {

    public void addChild(Node node) {}

}
