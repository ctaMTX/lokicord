package com.discord.simpleast.core.node;

import java.util.List;

public class StyleNode extends Node {

    public StyleNode(List<?> list) {}

}
