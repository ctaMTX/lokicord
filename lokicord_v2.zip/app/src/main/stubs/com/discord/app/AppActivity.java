package com.discord.app;

import androidx.appcompat.app.AppCompatActivity;

public class AppActivity extends AppCompatActivity {

    public static class Main {}

}
