package com.discord.app;

import androidx.fragment.app.Fragment;

public class AppBottomSheet extends Fragment {

    public void dismiss() {}

}
