package com.discord.app;

import androidx.fragment.app.Fragment;

public class AppFragment extends Fragment {

    public AppActivity getAppActivity() { return null; }

}