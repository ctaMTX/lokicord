package com.discord.app;

import android.app.Application;

public class App extends Application {

    public static Application app;

}
