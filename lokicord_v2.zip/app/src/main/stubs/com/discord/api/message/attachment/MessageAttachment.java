package com.discord.api.message.attachment;

public class MessageAttachment {

    public String filename;
    public long id;
    public String url;
    public String proxyUrl;

    public long size;
    public Integer height;
    public Integer width;

}
