package com.discord.api.message.allowedmentions;

public class MessageAllowedMentions {
}
