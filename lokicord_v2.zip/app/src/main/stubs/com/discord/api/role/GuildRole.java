package com.discord.api.role;

public class GuildRole {
}
