package com.discord.api.thread;

public class ThreadMember {
}
