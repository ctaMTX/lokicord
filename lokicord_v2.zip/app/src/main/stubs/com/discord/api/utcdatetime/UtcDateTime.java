package com.discord.api.utcdatetime;

public class UtcDateTime {

    /** getDateTimeMillis() */
    public long g() { return -1; }

}
