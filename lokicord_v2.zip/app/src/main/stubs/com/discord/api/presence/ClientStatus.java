package com.discord.api.presence;

public enum ClientStatus {
    ONLINE,
    IDLE,
    DND,
    INVISIBLE,
    OFFLINE
}