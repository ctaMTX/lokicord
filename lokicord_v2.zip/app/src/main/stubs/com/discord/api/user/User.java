package com.discord.api.user;

public class User {

    /** getId() */
    public long getId() { return 0; }

    /** getUsername() */
    public String getUsername() { return null; }

    /** getDiscriminator() */
    public String f() { return null; }

}
