package com.discord.api.voice.state;

public class VoiceState {
}
