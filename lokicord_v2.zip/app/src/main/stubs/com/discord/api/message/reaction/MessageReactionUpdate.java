package com.discord.api.message.reaction;

public class MessageReactionUpdate {

    /**
     * getUserId()
     */
    public long d() {
        return 0;
    }

}
