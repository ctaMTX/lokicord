package com.discord.databinding;

import android.widget.Button;

public class WidgetUserSheetBinding {

    // call button
    public Button Q;

    // call button
    public Button l;

}
