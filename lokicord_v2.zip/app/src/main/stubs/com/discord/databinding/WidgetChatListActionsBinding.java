package com.discord.databinding;

import android.view.View;
import android.widget.TextView;

public class WidgetChatListActionsBinding {

    // copy button
    public TextView c;

    public View getRoot() { return null; }

}
