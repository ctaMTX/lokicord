package com.discord.databinding;

public class WidgetChatListBinding {}