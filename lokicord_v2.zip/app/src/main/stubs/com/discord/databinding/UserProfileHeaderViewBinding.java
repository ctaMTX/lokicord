package com.discord.databinding;

import android.view.View;

import org.jetbrains.annotations.NotNull;

public class UserProfileHeaderViewBinding {

    private View a;

    @NotNull
    public View getRoot() { return a; }
}
