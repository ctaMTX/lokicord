package com.discord.stores;

public class StoreAuthentication {

    public String getFingerprint$app_productionGoogleRelease() {
        return "";
    }

    public boolean isAuthed() { return false; }

}