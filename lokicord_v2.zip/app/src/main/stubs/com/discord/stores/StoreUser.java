package com.discord.stores;

import com.discord.models.user.MeUser;

public class StoreUser {

    public MeUser getMe() {
        return null;
    }

}