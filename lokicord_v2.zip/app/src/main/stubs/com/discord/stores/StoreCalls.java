package com.discord.stores;

import java.util.List;

public class StoreCalls {

    public static /* synthetic */ void stopRinging$default(StoreCalls storeCalls, long j, List<Long> list, int i, Object obj) {}

}
