package com.discord.stores;

import com.discord.utilities.search.network.SearchFetcher;

public class StoreSearchQuery {

    public final SearchFetcher searchFetcher = new SearchFetcher();

}
