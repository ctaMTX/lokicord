package com.discord.stores;

import com.discord.api.stageinstance.StageInstance;

import java.util.HashMap;
import java.util.Map;

public class StoreStageInstances {

    public final Map<Long, StageInstance> getStageInstancesForGuildInternal(long guildId) {
        return new HashMap<>();
    }
}
