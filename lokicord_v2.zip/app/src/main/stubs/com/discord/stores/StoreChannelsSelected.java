package com.discord.stores;

public class StoreChannelsSelected {
    public final long getId() { return 0; }
}
