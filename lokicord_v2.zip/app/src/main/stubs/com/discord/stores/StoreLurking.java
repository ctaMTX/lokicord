package com.discord.stores;

import kotlin.jvm.functions.Function0;

public class StoreLurking {

    public static void postLeaveGuild$default(
            StoreLurking lurking,
            long guildId,
            Function0<?> ignore,
            Function0<?> ignore2,
            int i,
            Object obj
    ) {}

    // Removes "Instantiation of utility class" IDE warnings
    private void foo() {}

}