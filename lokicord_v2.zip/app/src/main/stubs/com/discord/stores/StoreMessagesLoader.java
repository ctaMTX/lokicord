package com.discord.stores;

public class StoreMessagesLoader {

    public final synchronized void jumpToMessage(long channelId, long messageId) {}

}
