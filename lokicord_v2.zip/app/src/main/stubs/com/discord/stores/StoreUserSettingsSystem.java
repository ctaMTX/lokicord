package com.discord.stores;

public class StoreUserSettingsSystem {

    public String getTheme() { return ""; }

}
