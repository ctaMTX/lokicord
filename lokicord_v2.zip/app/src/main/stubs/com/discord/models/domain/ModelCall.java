package com.discord.models.domain;

import com.discord.api.voice.state.VoiceState;

import java.util.List;

public class ModelCall {
    public long getChannelId() {
        return 0;
    }

    public List<VoiceState> getVoiceStates() {
        return null;
    }

    public List<VoiceState> getRinging() {
        return null;
    }
}
