package com.discord.models.domain;

public class Model {

    public static class JsonReader {

        public void skipValue() {}

    }

}
