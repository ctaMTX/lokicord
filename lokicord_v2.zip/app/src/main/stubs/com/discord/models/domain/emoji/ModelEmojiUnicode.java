package com.discord.models.domain.emoji;

public class ModelEmojiUnicode /* implements Model, Emoji */ {
    public String getMessageContentReplacement() { return null; }
}
