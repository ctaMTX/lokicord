package com.discord.models.domain;

public class ModelUserSettings {

}
