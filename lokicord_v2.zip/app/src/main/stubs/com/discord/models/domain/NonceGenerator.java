package com.discord.models.domain;

import com.discord.utilities.time.Clock;

public class NonceGenerator {
    public static long computeNonce(Clock clock) {
        return 0;
    }
}
