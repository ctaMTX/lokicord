package com.discord.models.guild;

public class Guild {

    public final int getPremiumTier() { return 1; }
    public String getName() { return null; }
    public long getId() { return 0; }
    public final long getOwnerId() { return 0; }

}
