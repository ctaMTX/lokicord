package com.discord.utilities.time;

import android.content.Context;

public class TimeUtils {

    public static CharSequence toReadableTimeString(Context context, long time, Clock clock) {
        return "";
    }
}