package com.discord.utilities.fcm;

import android.content.Context;

public class NotificationClient {

    public static final NotificationClient INSTANCE = new NotificationClient();

    public final void clear(long j, Context context2, boolean z2) {}

    public void onNewToken(String token) {}

}
