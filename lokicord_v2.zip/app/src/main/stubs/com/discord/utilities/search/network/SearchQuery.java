package com.discord.utilities.search.network;

import java.util.List;
import java.util.Map;

public class SearchQuery {

    public SearchQuery(Map<String, ? extends List<String>> params, boolean includeNsfw) {}
}
