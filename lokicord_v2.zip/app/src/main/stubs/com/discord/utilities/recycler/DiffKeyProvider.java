package com.discord.utilities.recycler;

public interface DiffKeyProvider {
    String getKey();
}