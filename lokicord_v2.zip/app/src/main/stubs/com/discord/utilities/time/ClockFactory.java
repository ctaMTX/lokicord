package com.discord.utilities.time;

public class ClockFactory {

    public static Clock get() {
        return () -> -1;
    }

}