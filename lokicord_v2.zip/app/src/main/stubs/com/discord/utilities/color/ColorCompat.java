package com.discord.utilities.color;

import android.content.Context;

import androidx.annotation.AttrRes;

public class ColorCompat {
    public static int getThemedColor(Context context, @AttrRes int i) {
        return 0;
    }
}
