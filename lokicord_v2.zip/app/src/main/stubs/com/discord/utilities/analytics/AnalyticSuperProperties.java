package com.discord.utilities.analytics;

public class AnalyticSuperProperties {
    public static final AnalyticSuperProperties INSTANCE = new AnalyticSuperProperties();

    public final String getSuperPropertiesStringBase64() {
        return "";
    }

}