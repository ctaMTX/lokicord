package com.discord.utilities.time;

public interface Clock {

    long currentTimeMillis();

}
