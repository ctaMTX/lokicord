package com.discord.utilities.fcm;

public class NotificationData {
    public final String getType() {
        return null;
    }
}
