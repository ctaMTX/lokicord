package mods.view;

import java.util.LinkedHashMap;

public class SpinnerMap extends LinkedHashMap<String, String> {

    public SpinnerMap() {
        super();
    }

    public SpinnerMap(int capacity) {
        super(capacity);
    }
}