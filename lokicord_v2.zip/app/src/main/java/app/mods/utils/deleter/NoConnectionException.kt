package mods.utils.deleter

internal class NoConnectionException : Exception("Not connected")