package mods.utils.search

data class SearchKey(
    val channelOrGuildId: Long,
    val authorId: Long
)