package mods.utils.deleter

data class MessageIdHolder(
    val channelId: Long,
    val messageId: Long
)