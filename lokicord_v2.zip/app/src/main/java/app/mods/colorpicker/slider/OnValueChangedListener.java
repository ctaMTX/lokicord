package mods.colorpicker.slider;

public interface OnValueChangedListener {
	void onValueChanged(float value);
}