package mods.colorpicker;

public interface OnColorSelectedListener {
	void onColorSelected(int selectedColor);
}
