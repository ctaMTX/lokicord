package mods.colorpicker;

public interface OnColorChangedListener {
	void onColorChanged(int selectedColor);
}
