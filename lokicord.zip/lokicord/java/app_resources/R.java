package com.discord.app_resources;

public final class R {
    private R() {
    }
}
