package com.discord.app;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.annotation.LayoutRes;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.discord.app.AppPermissions;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import kotlin.Lazy;
import kotlin.Unit;
import kotlin.f;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.u;
import kotlin.jvm.internal.v;
import kotlin.jvm.internal.w;
import kotlin.reflect.KProperty;
import rx.functions.Action0;
import rx.subjects.PublishSubject;
import rx.subjects.Subject;
import rx.subscriptions.CompositeSubscription;

/* compiled from: AppBottomSheet.kt */
public abstract class AppBottomSheet extends BottomSheetDialogFragment implements AppComponent, AppPermissions.Requests {
    static final /* synthetic */ KProperty[] $$delegatedProperties = {w.a((u) new v(w.Q(AppBottomSheet.class), "appPermissions", "getAppPermissions()Lcom/discord/app/AppPermissions;"))};
    private final Lazy appPermissions$delegate = f.b(new a(this));
    private CompositeSubscription compositeSubscription;
    private final Subject<Void, Void> paused;
    private View peekBottomView;
    private final View.OnLayoutChangeListener peekLayoutListener = new c(this);

    private final AppPermissions getAppPermissions() {
        return (AppPermissions) this.appPermissions$delegate.getValue();
    }

    public void bindSubscriptions(CompositeSubscription compositeSubscription2) {
        k.h(compositeSubscription2, "compositeSubscription");
    }

    @LayoutRes
    public abstract int getContentViewResId();

    public AppBottomSheet() {
        PublishSubject LJ = PublishSubject.LJ();
        k.g(LJ, "PublishSubject.create()");
        this.paused = LJ;
    }

    public Subject<Void, Void> getPaused() {
        return this.paused;
    }

    public final AppActivity getAppActivity() {
        return (AppActivity) getActivity();
    }

    public final Bundle getArgumentsOrDefault() {
        Bundle arguments = getArguments();
        if (arguments == null) {
            arguments = new Bundle();
        }
        k.g(arguments, "arguments ?: Bundle()");
        return arguments;
    }

    /* compiled from: AppBottomSheet.kt */
    static final class c implements View.OnLayoutChangeListener {
        final /* synthetic */ AppBottomSheet this$0;

        c(AppBottomSheet appBottomSheet) {
            this.this$0 = appBottomSheet;
        }

        public final void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
            this.this$0.updatePeekHeightPx(i4);
        }
    }

    private final BottomSheetBehavior<View> getBottomSheetBehavior() {
        View view = getView();
        ViewParent parent = view != null ? view.getParent() : null;
        if (!(parent instanceof View)) {
            parent = null;
        }
        View view2 = (View) parent;
        ViewGroup.LayoutParams layoutParams = view2 != null ? view2.getLayoutParams() : null;
        if (!(layoutParams instanceof CoordinatorLayout.LayoutParams)) {
            layoutParams = null;
        }
        CoordinatorLayout.LayoutParams layoutParams2 = (CoordinatorLayout.LayoutParams) layoutParams;
        CoordinatorLayout.Behavior behavior = layoutParams2 != null ? layoutParams2.getBehavior() : null;
        if (!(behavior instanceof BottomSheetBehavior)) {
            behavior = null;
        }
        return (BottomSheetBehavior) behavior;
    }

    public void requestVideoCallPermissions(Action0 action0) {
        getAppPermissions().requestVideoCallPermissions(action0);
    }

    public void requestMedia(Action0 action0) {
        getAppPermissions().requestMedia(action0);
    }

    public void requestMicrophone(Action0 action0) {
        getAppPermissions().requestMicrophone(action0);
    }

    public void requestMediaDownload(Action0 action0) {
        getAppPermissions().requestMediaDownload(action0);
    }

    public Dialog onCreateDialog(Bundle bundle) {
        Dialog dialog;
        Context context = getContext();
        if (context != null) {
            dialog = new BottomSheetDialog(context);
        } else {
            dialog = super.onCreateDialog(bundle);
            k.g(dialog, "super.onCreateDialog(savedInstanceState)");
        }
        dialog.setCanceledOnTouchOutside(true);
        return dialog;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        k.h(layoutInflater, "inflater");
        return layoutInflater.inflate(getContentViewResId(), (ViewGroup) null);
    }

    public void onViewCreated(View view, Bundle bundle) {
        k.h(view, "view");
        super.onViewCreated(view, bundle);
        BottomSheetBehavior<View> bottomSheetBehavior = getBottomSheetBehavior();
        if (bottomSheetBehavior != null) {
            bottomSheetBehavior.setBottomSheetCallback(new b(this));
        }
    }

    /* compiled from: AppBottomSheet.kt */
    public static final class b extends BottomSheetBehavior.BottomSheetCallback {
        final /* synthetic */ AppBottomSheet this$0;

        public final void onSlide(View view, float f) {
            k.h(view, "bottomSheet");
        }

        b(AppBottomSheet appBottomSheet) {
            this.this$0 = appBottomSheet;
        }

        public final void onStateChanged(View view, int i) {
            k.h(view, "bottomSheet");
            if (i == 5) {
                this.this$0.dismiss();
            }
        }
    }

    public void show(FragmentManager fragmentManager, String str) {
        k.h(str, "tag");
        if ((fragmentManager != null ? fragmentManager.findFragmentByTag(str) : null) == null) {
            try {
                super.show(fragmentManager, str);
            } catch (Exception unused) {
            }
        }
    }

    public int show(FragmentTransaction fragmentTransaction, String str) {
        k.h(fragmentTransaction, "transaction");
        k.h(str, "tag");
        try {
            return super.show(fragmentTransaction, str);
        } catch (Exception unused) {
            return -1;
        }
    }

    public void dismiss() {
        try {
            super.dismiss();
        } catch (Exception unused) {
        }
    }

    public void onResume() {
        super.onResume();
        CompositeSubscription compositeSubscription2 = new CompositeSubscription();
        bindSubscriptions(compositeSubscription2);
        this.compositeSubscription = compositeSubscription2;
    }

    public void onPause() {
        super.onPause();
        CompositeSubscription compositeSubscription2 = this.compositeSubscription;
        if (compositeSubscription2 != null) {
            compositeSubscription2.clear();
        }
        getPaused().onNext(null);
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        k.h(strArr, "permissions");
        k.h(iArr, "grantResults");
        super.onRequestPermissionsResult(i, strArr, iArr);
        getAppPermissions().a(i, iArr);
    }

    public final void setPeekHeightBottomView(View view) {
        while (!k.n(this.peekBottomView, view)) {
            View view2 = this.peekBottomView;
            if (view2 != null) {
                view2.removeOnLayoutChangeListener(this.peekLayoutListener);
            }
            this.peekBottomView = view;
            if (view != null) {
                view.addOnLayoutChangeListener(this.peekLayoutListener);
                view.requestLayout();
                return;
            }
            view = getView();
        }
    }

    public final void setBottomSheetState(int i) {
        BottomSheetBehavior<View> bottomSheetBehavior = getBottomSheetBehavior();
        if (bottomSheetBehavior != null) {
            bottomSheetBehavior.setState(i);
        }
    }

    /* access modifiers changed from: private */
    public final void updatePeekHeightPx(int i) {
        BottomSheetBehavior<View> bottomSheetBehavior = getBottomSheetBehavior();
        if (bottomSheetBehavior != null) {
            bottomSheetBehavior.setPeekHeight(i);
        }
    }

    /* compiled from: AppBottomSheet.kt */
    static final class d implements View.OnClickListener {
        final /* synthetic */ AppBottomSheet this$0;
        final /* synthetic */ View ug;
        final /* synthetic */ Function1 uh;

        d(AppBottomSheet appBottomSheet, View view, Function1 function1) {
            this.this$0 = appBottomSheet;
            this.ug = view;
            this.uh = function1;
        }

        public final void onClick(View view) {
            this.uh.invoke(this.ug);
            this.this$0.dismiss();
        }
    }

    /* access modifiers changed from: protected */
    public final void setOnClickAndDismissListener(View view, Function1<? super View, Unit> function1) {
        k.h(view, "$this$setOnClickAndDismissListener");
        k.h(function1, "onClickListener");
        view.setOnClickListener(new d(this, view, function1));
    }

    public static /* synthetic */ void showKeyboard$default(AppBottomSheet appBottomSheet, View view, int i, Object obj) {
        if (obj == null) {
            if ((i & 1) != 0) {
                view = null;
            }
            appBottomSheet.showKeyboard(view);
            return;
        }
        throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: showKeyboard");
    }

    public final void showKeyboard(View view) {
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            appActivity.showKeyboard(view);
        }
    }

    public static /* synthetic */ void hideKeyboard$default(AppBottomSheet appBottomSheet, View view, int i, Object obj) {
        if (obj == null) {
            if ((i & 1) != 0) {
                view = null;
            }
            appBottomSheet.hideKeyboard(view);
            return;
        }
        throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: hideKeyboard");
    }

    public final void hideKeyboard(View view) {
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            appActivity.hideKeyboard(view);
        }
    }

    /* compiled from: AppBottomSheet.kt */
    static final class a extends l implements Function0<AppPermissions> {
        final /* synthetic */ AppBottomSheet this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(AppBottomSheet appBottomSheet) {
            super(0);
            this.this$0 = appBottomSheet;
        }

        public final /* synthetic */ Object invoke() {
            return new AppPermissions(this.this$0);
        }
    }
}
