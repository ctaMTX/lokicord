package com.discord.app;

import android.content.Context;
import androidx.annotation.StringRes;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.discord.R;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import kotlin.Unit;
import kotlin.a.m;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.l;
import rx.functions.Action0;

/* compiled from: AppPermissions.kt */
public final class AppPermissions {
    private static final HashMap<Integer, String[]> uF = new HashMap<>();
    private static final int uG = uG;
    private static final int uH = uH;
    private static final int uI = uI;
    private static final int uJ = uJ;
    @Deprecated
    public static final a uK = new a((byte) 0);
    /* access modifiers changed from: private */
    public final Fragment fragment;
    private final HashMap<Integer, Function0<Unit>> uE = new HashMap<>();

    /* compiled from: AppPermissions.kt */
    public interface Requests {
        void requestVideoCallPermissions(Action0 action0);
    }

    /* compiled from: AppPermissions.kt */
    static final class b extends l implements Function1<Integer, Function0<? extends Unit>> {
        final /* synthetic */ AppPermissions this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        b(AppPermissions appPermissions) {
            super(1);
            this.this$0 = appPermissions;
        }

        public final /* synthetic */ Object invoke(Object obj) {
            return x(((Number) obj).intValue());
        }

        public final Function0<Unit> x(@StringRes final int i) {
            return new Function0<Unit>(this) {
                final /* synthetic */ b this$0;

                {
                    this.this$0 = r1;
                }

                public final /* synthetic */ Object invoke() {
                    h.a(this.this$0.this$0.fragment.getContext(), i, 0);
                    return Unit.bjE;
                }
            };
        }
    }

    public AppPermissions(Fragment fragment2) {
        k.h(fragment2, "fragment");
        this.fragment = fragment2;
    }

    public final void requestVideoCallPermissions(Action0 action0) {
        a(uG, action0);
    }

    public final void requestMedia(Action0 action0) {
        a(uI, action0);
    }

    public final void requestMicrophone(Action0 action0) {
        a(uH, action0);
    }

    public final void requestMediaDownload(Action0 action0) {
        a(uJ, action0);
    }

    public final synchronized void a(int i, int[] iArr) {
        Function0<Unit> function0;
        k.h(iArr, "grantResults");
        b bVar = new b(this);
        Function0 remove = this.uE.remove(Integer.valueOf(i));
        if (i == uH) {
            function0 = bVar.x(R.string.permission_microphone_denied);
        } else if (i == uI) {
            function0 = bVar.x(R.string.permission_media_denied);
        } else {
            function0 = i == uJ ? bVar.x(R.string.permission_media_download_denied) : null;
        }
        if (b(iArr)) {
            if (remove != null) {
                remove.invoke();
            }
        } else if (function0 != null) {
            function0.invoke();
        }
    }

    private final synchronized void a(int i, Action0 action0) {
        Function0 cVar = new c(action0);
        String[] strArr = uF.get(Integer.valueOf(i));
        if (strArr != null) {
            k.g(strArr, "PERMISSION_GROUPS[requestCode] ?: return");
            Context context = this.fragment.getContext();
            if (context != null) {
                Collection arrayList = new ArrayList(strArr.length);
                for (String checkSelfPermission : strArr) {
                    arrayList.add(Integer.valueOf(ContextCompat.checkSelfPermission(context, checkSelfPermission)));
                }
                if (b(m.h((List) arrayList))) {
                    cVar.invoke();
                    return;
                }
            }
            this.uE.put(Integer.valueOf(i), cVar);
            this.fragment.requestPermissions(strArr, i);
        }
    }

    /* compiled from: AppPermissions.kt */
    static final class a {
        private a() {
        }

        public /* synthetic */ a(byte b2) {
            this();
        }
    }

    static {
        uF.put(Integer.valueOf(uH), new String[]{"android.permission.RECORD_AUDIO"});
        uF.put(Integer.valueOf(uG), new String[]{"android.permission.RECORD_AUDIO", "android.permission.CAMERA"});
        uF.put(Integer.valueOf(uI), new String[]{"android.permission.CAMERA", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"});
        uF.put(Integer.valueOf(uJ), new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"});
    }

    private static boolean b(int[] iArr) {
        int length = iArr.length;
        int i = 0;
        while (true) {
            boolean z = true;
            if (i >= length) {
                return true;
            }
            if (iArr[i] != 0) {
                z = false;
            }
            if (!z) {
                return false;
            }
            i++;
        }
    }

    /* compiled from: AppPermissions.kt */
    static final class c extends l implements Function0<Unit> {
        final /* synthetic */ Action0 $onSuccess;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        c(Action0 action0) {
            super(0);
            this.$onSuccess = action0;
        }

        public final /* synthetic */ Object invoke() {
            Action0 action0 = this.$onSuccess;
            if (action0 == null) {
                return null;
            }
            action0.call();
            return Unit.bjE;
        }
    }
}
