package com.discord.app;

import androidx.annotation.AnimRes;
import androidx.appcompat.app.AppCompatActivity;
import com.discord.R;

/* compiled from: AppTransitionActivity.kt */
public abstract class j extends AppCompatActivity {
    /* access modifiers changed from: private */
    public static boolean vL;
    public static final b vM = new b((byte) 0);
    a vK = c.TYPE_SLIDE_POP_VERTICAL.animations;

    public void onPause() {
        super.onPause();
        a(vL, false);
    }

    public void onResume() {
        super.onResume();
        a(vL, true);
        vL = false;
    }

    public void onBackPressed() {
        super.onBackPressed();
        vL = true;
    }

    private final void a(boolean z, boolean z2) {
        a aVar;
        int i;
        int i2;
        if (z && z2) {
            return;
        }
        if ((z || z2) && (aVar = this.vK) != null) {
            if (z2) {
                i = aVar.vN;
            } else {
                i = aVar.vP;
            }
            if (z2) {
                i2 = aVar.vO;
            } else {
                i2 = aVar.vQ;
            }
            overridePendingTransition(i, i2);
        }
    }

    /* compiled from: AppTransitionActivity.kt */
    public enum c {
        TYPE_FADE(new a(R.anim.activity_fade_open_in, R.anim.activity_fade_open_out, R.anim.activity_fade_close_in, R.anim.activity_fade_close_out)),
        TYPE_STANDARD(new a(R.anim.activity_standard_open_in, R.anim.activity_standard_open_out, R.anim.activity_standard_close_in, R.anim.activity_standard_close_out)),
        TYPE_SLIDE_HORIZONTAL(new a(R.anim.activity_slide_horizontal_open_in, R.anim.activity_slide_horizontal_open_out, R.anim.activity_slide_horizontal_close_in, R.anim.activity_slide_horizontal_close_out)),
        TYPE_SLIDE_VERTICAL(new a(R.anim.activity_slide_vertical_open_in, R.anim.activity_slide_vertical_open_out, R.anim.activity_slide_vertical_close_in, R.anim.activity_slide_vertical_close_out)),
        TYPE_SLIDE_POP_VERTICAL(new a(R.anim.activity_slide_pop_vertical_open_in, R.anim.activity_slide_pop_vertical_open_out, R.anim.activity_slide_pop_vertical_close_in, R.anim.activity_slide_pop_vertical_close_out)),
        TYPE_SLIDE_POP_HORIZONTAL(new a(R.anim.activity_slide_pop_horizontal_open_in, R.anim.activity_slide_pop_horizontal_open_out, R.anim.activity_slide_pop_horizontal_close_in, R.anim.activity_slide_pop_horizontal_close_out)),
        TYPE_NONE(new a(0, 0, 0, 0));
        
        final a animations;

        private c(a aVar) {
            this.animations = aVar;
        }
    }

    /* compiled from: AppTransitionActivity.kt */
    public static final class b {
        private b() {
        }

        public /* synthetic */ b(byte b2) {
            this();
        }
    }

    /* compiled from: AppTransitionActivity.kt */
    public static final class a {
        final int vN;
        final int vO;
        final int vP;
        final int vQ;

        public a(@AnimRes int i, @AnimRes int i2, @AnimRes int i3, @AnimRes int i4) {
            this.vN = i;
            this.vO = i2;
            this.vP = i3;
            this.vQ = i4;
        }
    }
}
