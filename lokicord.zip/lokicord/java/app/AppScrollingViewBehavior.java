package com.discord.app;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.discord.R;
import com.google.android.material.appbar.AppBarLayout;
import kotlin.jvm.internal.k;

/* compiled from: AppScrollingViewBehavior.kt */
public final class AppScrollingViewBehavior extends AppBarLayout.ScrollingViewBehavior {
    private AppBarLayout appBarLayout;
    private final float uR;
    private boolean uS;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppScrollingViewBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        k.h(context, "context");
        k.h(attributeSet, "attrs");
        this.uR = context.getResources().getDimension(R.dimen.app_elevation);
    }

    public final boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout, View view, View view2, View view3, int i, int i2) {
        k.h(coordinatorLayout, "coordinatorLayout");
        k.h(view, "child");
        k.h(view2, "directTargetChild");
        k.h(view3, "target");
        if (this.appBarLayout == null) {
            this.appBarLayout = (AppBarLayout) coordinatorLayout.findViewById(R.id.action_bar_toolbar_layout);
        }
        return i == 2;
    }

    public final void onNestedScroll(CoordinatorLayout coordinatorLayout, View view, View view2, int i, int i2, int i3, int i4, int i5) {
        k.h(coordinatorLayout, "coordinatorLayout");
        k.h(view, "child");
        k.h(view2, "target");
        super.onNestedScroll(coordinatorLayout, view, view2, i, i2, i3, i4, i5);
        a(view2);
    }

    private final void y(int i) {
        float min = Math.min(this.uR, ((float) i) / 16.0f);
        AppBarLayout appBarLayout2 = this.appBarLayout;
        if (appBarLayout2 != null) {
            ViewCompat.setElevation(appBarLayout2, min);
        }
    }

    /* access modifiers changed from: private */
    public final void a(View view) {
        this.uS = true;
        y(b(view));
        if (c(view)) {
            view.postDelayed(new a(this, view), 20);
        } else {
            this.uS = false;
        }
    }

    /* compiled from: AppScrollingViewBehavior.kt */
    static final class a implements Runnable {
        final /* synthetic */ AppScrollingViewBehavior uT;
        final /* synthetic */ View uU;

        a(AppScrollingViewBehavior appScrollingViewBehavior, View view) {
            this.uT = appScrollingViewBehavior;
            this.uU = view;
        }

        public final void run() {
            this.uT.a(this.uU);
        }
    }

    private static int b(View view) {
        if (!(view instanceof RecyclerView)) {
            return view.getScrollY();
        }
        RecyclerView recyclerView = (RecyclerView) view;
        return recyclerView.computeVerticalScrollOffset() + recyclerView.computeHorizontalScrollExtent();
    }

    private static boolean c(View view) {
        return (view instanceof RecyclerView) && ((RecyclerView) view).getScrollState() != 0;
    }
}
