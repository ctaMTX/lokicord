package com.discord.app;

import android.app.Application;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.work.WorkRequest;
import com.discord.R;
import com.discord.app.AppActivity;
import com.discord.models.domain.ModelPermission;
import com.discord.stores.StoreStream;
import com.discord.utilities.analytics.AnalyticsTracker;
import com.discord.utilities.analytics.AnalyticsUtils;
import com.discord.utilities.error.Error;
import com.discord.utilities.fcm.NotificationData;
import com.discord.utilities.intent.IntentUtils;
import com.discord.utilities.intent.RouteHandlers;
import com.discord.utilities.logging.Logger;
import com.discord.utilities.rx.ObservableExtensionsKt;
import com.discord.utilities.voice.DiscordOverlayService;
import java.util.List;
import kotlin.Unit;
import kotlin.a.m;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.l;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import rx.Observable;

/* compiled from: DiscordConnectService.kt */
public final class DiscordConnectService extends Service {
    private static final boolean vZ = com.discord.samsung.a.en();
    public static final a wa = new a((byte) 0);

    /* compiled from: DiscordConnectService.kt */
    static final class b<T, R> implements rx.functions.b<Boolean, Boolean> {
        public static final b wb = new b();

        b() {
        }

        public final /* bridge */ /* synthetic */ Object call(Object obj) {
            return (Boolean) obj;
        }
    }

    /* compiled from: DiscordConnectService.kt */
    static final class d extends l implements Function1<Object, Unit> {
        public static final d we = new d();

        d() {
            super(1);
        }

        public final /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return Unit.bjE;
        }
    }

    /* compiled from: DiscordConnectService.kt */
    static final class f extends l implements Function1<Error, Unit> {
        final /* synthetic */ int $startId;
        final /* synthetic */ DiscordConnectService this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        f(DiscordConnectService discordConnectService, int i) {
            super(1);
            this.this$0 = discordConnectService;
            this.$startId = i;
        }

        public final /* synthetic */ Object invoke(Object obj) {
            Error error = (Error) obj;
            k.h(error, "it");
            a aVar = DiscordConnectService.wa;
            a.log("Request timeout[" + this.$startId + "]: " + error);
            this.this$0.z(this.$startId);
            return Unit.bjE;
        }
    }

    public final void onCreate() {
        super.onCreate();
        if (vZ) {
            a.log("onCreate");
        } else {
            a.log("onCreate: device " + Build.DEVICE + '@' + Build.VERSION.SDK_INT);
        }
        g.uX.u(this);
        Context context = this;
        startForeground(100, new NotificationCompat.Builder(context, NotificationData.NOTIF_CHANNEL_SOCIAL).setAutoCancel(true).setOnlyAlertOnce(true).setLocalOnly(true).setSmallIcon(R.drawable.ic_notification_24dp).setColor(ContextCompat.getColor(context, R.color.brand_500)).setContentTitle(getString(R.string.connecting)).setContentText(getString(R.string.connection_status_awaiting_endpoint)).build());
        StoreStream.Companion companion = StoreStream.Companion;
        Application application = getApplication();
        k.g(application, "application");
        companion.initialize(application);
        AnalyticsUtils analyticsUtils = AnalyticsUtils.INSTANCE;
        Application application2 = getApplication();
        k.g(application2, "application");
        analyticsUtils.initAppOpen(application2);
    }

    public final int onStartCommand(Intent intent, int i, int i2) {
        Observable G;
        List<String> Ew;
        String str;
        int i3 = i2;
        a.log("onStartCommand: ".concat(String.valueOf(i2)));
        Long l = null;
        Uri data = intent != null ? intent.getData() : null;
        if (!vZ || data == null || !IntentUtils.INSTANCE.isDiscordAppUri(data)) {
            a.log("Invalid request ".concat(String.valueOf(data)));
            z(i3);
            return 2;
        }
        CharSequence authToken$app_productionDiscordExternalRelease = StoreStream.Companion.getAuthentication().getAuthToken$app_productionDiscordExternalRelease();
        if (authToken$app_productionDiscordExternalRelease == null || kotlin.text.l.j(authToken$app_productionDiscordExternalRelease)) {
            h.a((Context) this, (int) R.string.overlay_mobile_unauthed, 0);
            G = Observable.G(new IllegalStateException("UNAUTHED"));
            k.g(G, "Observable.error(Illegal…ateException(\"UNAUTHED\"))");
        } else {
            com.discord.app.a.a aVar = com.discord.app.a.a.wu;
            Regex dK = com.discord.app.a.a.dK();
            String path = data.getPath();
            if (path == null) {
                path = "";
            }
            MatchResult i4 = dK.i(path);
            if (!(i4 == null || (Ew = i4.Ew()) == null || (str = (String) m.d(Ew, 1)) == null)) {
                l = kotlin.text.l.dW(str);
            }
            if (i4 != null) {
                AnalyticsTracker.INSTANCE.deepLinkReceived(intent == null ? new Intent() : intent, new RouteHandlers.AnalyticsMetadata("connect", (Long) null, l, 2, (DefaultConstructorMarker) null));
            }
            if (l != null) {
                Context context = this;
                if (ContextCompat.checkSelfPermission(context, "android.permission.RECORD_AUDIO") != 0) {
                    Uri build = data.buildUpon().appendQueryParameter("service_denied", "true").build();
                    k.g(build, "uri.buildUpon()\n        …))\n              .build()");
                    Intent intent2 = new Intent("android.intent.action.VIEW", build, context, AppActivity.Main.class);
                    intent2.addFlags(ModelPermission.MANAGE_ROLES);
                    startActivity(intent2);
                    G = Observable.G(new IllegalStateException("Do not have microphone permissions, go to main app"));
                    k.g(G, "Observable.error(Illegal…ssions, go to main app\"))");
                } else {
                    long longValue = l.longValue();
                    a.log("Try joining voice channel");
                    StoreStream.Companion.getVoiceChannelSelected().set(longValue);
                    Observable<Boolean> b2 = StoreStream.Companion.getConnectivity().getConnectionOpen().b(b.wb);
                    k.g(b2, "StoreStream\n        .get…en\n        .filter { it }");
                    G = ObservableExtensionsKt.takeSingleUntilTimeout$default(b2, WorkRequest.MIN_BACKOFF_MILLIS, false, 2, (Object) null).g(c.wc);
                    k.g(G, "isConnectedObs.switchMap…nnected\n          }\n    }");
                }
            } else if (i4 != null) {
                DiscordOverlayService.Companion.launchForConnect(this);
                G = Observable.bI(Unit.bjE);
                k.g(G, "Observable.just(Unit)");
            } else {
                G = Observable.G(new IllegalArgumentException("Invalid Request: ".concat(String.valueOf(data))));
                k.g(G, "Observable.error(Illegal…\"Invalid Request: $uri\"))");
            }
        }
        ObservableExtensionsKt.appSubscribe$default(ObservableExtensionsKt.takeSingleUntilTimeout$default(G, WorkRequest.MIN_BACKOFF_MILLIS, false, 2, (Object) null), (Class) getClass(), (Context) null, (Function1) null, new f(this, i3), new e(this, i3), (Function1) d.we, 6, (Object) null);
        return 2;
    }

    public final IBinder onBind(Intent intent) {
        throw new IllegalStateException("All my bases are belong to me!");
    }

    /* access modifiers changed from: private */
    public final void z(int i) {
        stopForeground(true);
        stopSelf(i);
    }

    /* compiled from: DiscordConnectService.kt */
    public static final class a {
        private a() {
        }

        public /* synthetic */ a(byte b2) {
            this();
        }

        static void log(String str) {
            AppLog appLog = AppLog.uB;
            String simpleName = DiscordConnectService.class.getSimpleName();
            k.g(simpleName, "DiscordConnectService::class.java.simpleName");
            Logger.i$default(appLog, simpleName, str, (Throwable) null, 4, (Object) null);
        }
    }

    static {
        com.discord.samsung.a aVar = com.discord.samsung.a.zN;
    }

    /* compiled from: DiscordConnectService.kt */
    static final class e extends l implements Function0<Unit> {
        final /* synthetic */ int $startId;
        final /* synthetic */ DiscordConnectService this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        e(DiscordConnectService discordConnectService, int i) {
            super(0);
            this.this$0 = discordConnectService;
            this.$startId = i;
        }

        public final /* synthetic */ Object invoke() {
            a aVar = DiscordConnectService.wa;
            a.log("Success[" + this.$startId + ']');
            this.this$0.z(this.$startId);
            return Unit.bjE;
        }
    }

    /* compiled from: DiscordConnectService.kt */
    static final class c<T, R> implements rx.functions.b<T, Observable<? extends R>> {
        public static final c wc = new c();

        c() {
        }

        public final /* synthetic */ Object call(Object obj) {
            return StoreStream.Companion.getRtcConnection().getConnectionState().b(AnonymousClass1.wd);
        }
    }

    public final void onDestroy() {
        a.log("onDestroy");
        g.uX.v(this);
        super.onDestroy();
    }
}
