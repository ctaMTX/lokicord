package com.discord.app.a;

import android.net.Uri;
import com.discord.BuildConfig;
import kotlin.text.Regex;
import kotlin.text.k;
import kotlin.text.l;

/* compiled from: RoutingPatterns.kt */
public final class a {
    private static final String HOST = af(BuildConfig.HOST);
    private static final String HOST_GIFT = af(BuildConfig.HOST_GIFT);
    private static final String HOST_INVITE = af(BuildConfig.HOST_INVITE);
    private static final String wf = l.c(HOST, ".", "\\.", false);
    private static final String wg = l.c(HOST_GIFT, ".", "\\.", false);
    private static final String wh = l.c(HOST_INVITE, ".", "\\.", false);
    private static final Regex wi = new Regex("^/(?:(invite|gift)/)?([\\w-]+)/?$", k.IGNORE_CASE);
    private static final Regex wj = new Regex("^/(?:invite\\\\/)?([\\w-]+)/?$", k.IGNORE_CASE);
    public static final Regex wk = new Regex("(?:https?://(?:(?:" + wf + "/invite)|(?:" + wh + "))|(?:" + wh + "))/([\\w-]+)/?", k.IGNORE_CASE);
    public static final Regex wl;
    private static final Regex wm = new Regex("^/connect(?:/(\\d+))?/?$", k.IGNORE_CASE);
    private static final Regex wn = new Regex("^/channels/((?:@me)|(?:\\d+))/(\\d+)(?:/(\\d+))?/?$", k.IGNORE_CASE);
    private static final Regex wo = new Regex("^/lurk/(\\d+)(?:/(\\d+))?/?$", k.IGNORE_CASE);
    private static final Regex wp = new Regex("^/channels/@me/user/(\\d+)/?$", k.IGNORE_CASE);
    private static final Regex wq = new Regex("^/profile/(\\d+)/?$", k.IGNORE_CASE);
    private static final Regex wr = new Regex("^(?:ptb|canary)." + wf + '$', k.IGNORE_CASE);
    private static final Regex ws = new Regex("^/settings(/\\w+)*/?$", k.IGNORE_CASE);
    private static final Regex wt = new Regex("^/oauth2/authorize/?$", k.IGNORE_CASE);
    public static final a wu = new a();

    static {
        StringBuilder sb = new StringBuilder("(?:https?://)?(?:(?:");
        sb.append(wf);
        sb.append("/gifts)|(?:");
        sb.append(wg);
        sb.append("))/([\\w-]+)/?");
        wl = new Regex(sb.toString(), k.IGNORE_CASE);
    }

    private a() {
    }

    public static String dG() {
        return HOST;
    }

    public static String dH() {
        return HOST_INVITE;
    }

    public static Regex dI() {
        return wi;
    }

    public static Regex dJ() {
        return wj;
    }

    public static Regex dK() {
        return wm;
    }

    public static Regex dL() {
        return wn;
    }

    public static Regex dM() {
        return wo;
    }

    public static Regex dN() {
        return wp;
    }

    public static Regex dO() {
        return wq;
    }

    public static Regex dP() {
        return ws;
    }

    public static Regex dQ() {
        return wt;
    }

    public static boolean ae(String str) {
        if (str == null) {
            return false;
        }
        if (kotlin.jvm.internal.k.n(str, HOST) || kotlin.jvm.internal.k.n(str, HOST_GIFT) || kotlin.jvm.internal.k.n(str, HOST_INVITE)) {
            return true;
        }
        return wr.g(str);
    }

    public static boolean a(Uri uri) {
        String path;
        kotlin.jvm.internal.k.h(uri, "$this$isInviteLink");
        if (!l.af(uri.getHost(), HOST_INVITE)) {
            if (!l.af(uri.getHost(), HOST) || (path = uri.getPath()) == null) {
                return false;
            }
            if (wj.g(path)) {
                return true;
            }
            return false;
        }
        return true;
    }

    private static String af(String str) {
        Uri parse = Uri.parse(str);
        kotlin.jvm.internal.k.g(parse, "Uri.parse(this)");
        String host = parse.getHost();
        return host == null ? "" : host;
    }
}
