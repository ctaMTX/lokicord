package com.discord.app;

import com.discord.utilities.logging.Logger;
import java.util.ArrayList;
import kotlin.jvm.internal.k;
import rx.Observable;
import rx.functions.b;
import rx.subjects.BehaviorSubject;

/* compiled from: AppState.kt */
public final class g {
    private static final ArrayList<Object> uV = new ArrayList<>(4);
    private static final BehaviorSubject<Integer> uW = BehaviorSubject.bT(0);
    public static final g uX = new g();

    /* compiled from: AppState.kt */
    static final class a<T, R> implements b<T, R> {
        public static final a uY = new a();

        a() {
        }

        public final /* synthetic */ Object call(Object obj) {
            boolean z = false;
            if (k.compare(((Integer) obj).intValue(), 0) > 0) {
                z = true;
            }
            return Boolean.valueOf(z);
        }
    }

    private g() {
    }

    public final synchronized void u(Object obj) {
        k.h(obj, "consumer");
        uV.add(obj);
        Logger.d$default(AppLog.uB, "Gateway Connection consumer add ".concat(String.valueOf(obj)), (Throwable) null, 2, (Object) null);
        uW.onNext(Integer.valueOf(uV.size()));
    }

    public final synchronized void v(Object obj) {
        k.h(obj, "consumer");
        uV.remove(obj);
        Logger.d$default(AppLog.uB, "Gateway Connection consumer rm ".concat(String.valueOf(obj)), (Throwable) null, 2, (Object) null);
        uW.onNext(Integer.valueOf(uV.size()));
    }

    public static Observable<Boolean> dy() {
        Observable<R> Kb = uW.e(a.uY).Kb();
        k.g(Kb, "numGatewayConnectionCons…  .distinctUntilChanged()");
        return Kb;
    }
}
