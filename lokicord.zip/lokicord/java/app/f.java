package com.discord.app;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.discord.widgets.auth.WidgetAuthCaptcha;
import com.discord.widgets.auth.WidgetAuthLanding;
import com.discord.widgets.auth.WidgetAuthLogin;
import com.discord.widgets.auth.WidgetAuthMfa;
import com.discord.widgets.auth.WidgetAuthRegister;
import com.discord.widgets.auth.WidgetAuthUndeleteAccount;
import com.discord.widgets.auth.WidgetOauth2Authorize;
import com.discord.widgets.channels.WidgetChannelSettingsEditPermissions;
import com.discord.widgets.channels.WidgetChannelSettingsPermissionsOverview;
import com.discord.widgets.main.WidgetMain;
import com.discord.widgets.servers.WidgetServerNotifications;
import com.discord.widgets.servers.WidgetServerSettingsBans;
import com.discord.widgets.servers.WidgetServerSettingsChannels;
import com.discord.widgets.servers.WidgetServerSettingsEditRole;
import com.discord.widgets.servers.WidgetServerSettingsEmojis;
import com.discord.widgets.servers.WidgetServerSettingsEmojisEdit;
import com.discord.widgets.servers.WidgetServerSettingsInstantInvites;
import com.discord.widgets.servers.WidgetServerSettingsIntegrations;
import com.discord.widgets.servers.WidgetServerSettingsMembers;
import com.discord.widgets.servers.WidgetServerSettingsModeration;
import com.discord.widgets.servers.WidgetServerSettingsOverview;
import com.discord.widgets.servers.WidgetServerSettingsRolesList;
import com.discord.widgets.servers.WidgetServerSettingsSecurity;
import com.discord.widgets.servers.WidgetServerSettingsVanityUrl;
import com.discord.widgets.settings.WidgetSettingsAppearance;
import com.discord.widgets.settings.WidgetSettingsBehavior;
import com.discord.widgets.settings.WidgetSettingsLanguage;
import com.discord.widgets.settings.WidgetSettingsMedia;
import com.discord.widgets.settings.WidgetSettingsNotifications;
import com.discord.widgets.settings.WidgetSettingsPrivacy;
import com.discord.widgets.settings.WidgetSettingsUserConnections;
import com.discord.widgets.settings.WidgetSettingsVoice;
import com.discord.widgets.settings.account.WidgetSettingsAccount;
import com.discord.widgets.settings.account.WidgetSettingsAccountBackupCodes;
import com.discord.widgets.settings.account.WidgetSettingsAccountChangePassword;
import com.discord.widgets.settings.account.WidgetSettingsAccountEdit;
import com.discord.widgets.settings.account.mfa.WidgetEnableMFASteps;
import com.discord.widgets.settings.billing.WidgetSettingsBilling;
import com.discord.widgets.settings.nitro.WidgetSettingsPremium;
import com.discord.widgets.user.account.WidgetUserAccountVerify;
import com.discord.widgets.user.account.WidgetUserAccountVerifyBase;
import com.discord.widgets.user.captcha.WidgetUserCaptchaVerify;
import com.discord.widgets.user.email.WidgetUserEmailUpdate;
import com.discord.widgets.user.email.WidgetUserEmailVerify;
import com.discord.widgets.user.phone.WidgetUserPhoneAdd;
import com.discord.widgets.user.phone.WidgetUserPhoneVerify;
import java.util.List;
import kotlin.a.m;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.w;
import kotlin.reflect.b;

/* compiled from: AppScreen.kt */
public final class f {
    private static final List<b<? extends AppFragment>> uL = m.l(w.Q(WidgetAuthLanding.class), w.Q(WidgetAuthLogin.class), w.Q(WidgetAuthRegister.class), w.Q(WidgetAuthUndeleteAccount.class), w.Q(WidgetAuthCaptcha.class), w.Q(WidgetAuthMfa.class));
    private static final List<b<? extends AppFragment>> uM = m.l(w.Q(WidgetSettingsAccount.class), w.Q(WidgetSettingsAccountBackupCodes.class), w.Q(WidgetSettingsAccountChangePassword.class), w.Q(WidgetSettingsAccountEdit.class), w.Q(WidgetEnableMFASteps.class), w.Q(WidgetSettingsAppearance.class), w.Q(WidgetSettingsBehavior.class), w.Q(WidgetSettingsBilling.class), w.Q(WidgetSettingsLanguage.class), w.Q(WidgetSettingsMedia.class), w.Q(WidgetSettingsPremium.class), w.Q(WidgetSettingsNotifications.class), w.Q(WidgetSettingsUserConnections.class), w.Q(WidgetSettingsVoice.class), w.Q(WidgetSettingsPrivacy.class), w.Q(WidgetServerNotifications.class), w.Q(WidgetServerSettingsOverview.class), w.Q(WidgetServerSettingsChannels.class), w.Q(WidgetServerSettingsEditRole.class), w.Q(WidgetServerSettingsIntegrations.class), w.Q(WidgetServerSettingsModeration.class), w.Q(WidgetServerSettingsVanityUrl.class), w.Q(WidgetServerSettingsSecurity.class), w.Q(WidgetServerSettingsMembers.class), w.Q(WidgetServerSettingsEmojis.class), w.Q(WidgetServerSettingsEmojisEdit.class), w.Q(WidgetServerSettingsRolesList.class), w.Q(WidgetServerSettingsInstantInvites.class), w.Q(WidgetServerSettingsBans.class), w.Q(WidgetChannelSettingsEditPermissions.class), w.Q(WidgetChannelSettingsPermissionsOverview.class), w.Q(WidgetAuthRegister.class), w.Q(WidgetAuthLogin.class));
    private static final List<b<? extends WidgetUserAccountVerifyBase>> uN = m.l(w.Q(WidgetUserAccountVerify.class), w.Q(WidgetUserEmailVerify.class), w.Q(WidgetUserEmailUpdate.class), w.Q(WidgetUserPhoneAdd.class), w.Q(WidgetUserPhoneVerify.class), w.Q(WidgetUserCaptchaVerify.class));
    private static final List<b<? extends AppFragment>> uO = m.l(w.Q(WidgetOauth2Authorize.class), w.Q(WidgetSettingsBilling.class));
    public static final f uP = new f();

    public static final void start(Context context) {
        a(context, false, (Intent) null, 6);
    }

    private f() {
    }

    public static List<b<? extends AppFragment>> du() {
        return uL;
    }

    public static List<b<? extends AppFragment>> dv() {
        return uM;
    }

    public static List<b<? extends WidgetUserAccountVerifyBase>> dw() {
        return uN;
    }

    public static List<b<? extends AppFragment>> dx() {
        return uO;
    }

    public static /* synthetic */ void a(Context context, boolean z, Intent intent, int i) {
        if ((i & 2) != 0) {
            z = true;
        }
        if ((i & 4) != 0) {
            intent = null;
        }
        a(context, z, intent);
    }

    public static final void a(Context context, boolean z, Intent intent) {
        k.h(context, "context");
        a(context, (Class<? extends AppComponent>) z ? WidgetMain.class : WidgetAuthLanding.class, intent);
    }

    public static final void a(Context context, Class<? extends AppComponent> cls, Intent intent) {
        k.h(context, "context");
        k.h(cls, "screen");
        context.startActivity(b(context, cls, intent));
    }

    public static final void a(Fragment fragment, Class<? extends AppComponent> cls, Intent intent, int i) {
        k.h(fragment, "fragment");
        k.h(cls, "screen");
        Context context = fragment.getContext();
        if (context != null) {
            fragment.startActivityForResult(b(context, cls, intent), i);
        }
    }

    public static /* synthetic */ void a(FragmentManager fragmentManager, Context context, Class cls) {
        k.h(cls, "screen");
        if (fragmentManager != null) {
            FragmentTransaction beginTransaction = fragmentManager.beginTransaction();
            k.g(beginTransaction, "fragmentManager.beginTransaction()");
            beginTransaction.replace(16908290, Fragment.instantiate(context, cls.getName()), cls.getName());
            beginTransaction.commit();
        }
    }

    public static boolean c(AppActivity appActivity) {
        k.h(appActivity, "activity");
        boolean booleanExtra = appActivity.getMostRecentIntent().getBooleanExtra("INTENT_RECREATE", false);
        if (booleanExtra) {
            appActivity.getMostRecentIntent().removeExtra("INTENT_RECREATE");
            new Handler().post(new a(appActivity));
        }
        return booleanExtra;
    }

    /* compiled from: AppScreen.kt */
    static final class a implements Runnable {
        final /* synthetic */ AppActivity uQ;

        a(AppActivity appActivity) {
            this.uQ = appActivity;
        }

        public final void run() {
            this.uQ.recreate();
        }
    }

    private static Intent b(Context context, Class<? extends AppComponent> cls, Intent intent) {
        String simpleName = context.getClass().getSimpleName();
        k.g(simpleName, "javaClass.simpleName");
        String simpleName2 = cls.getSimpleName();
        k.g(simpleName2, "screen.simpleName");
        AppLog.n(simpleName, simpleName2);
        Intent intent2 = new Intent(context, AppActivity.class);
        intent2.setFlags(intent != null ? intent.getFlags() : 0);
        intent2.putExtra("com.discord.intent.extra.EXTRA_SCREEN", cls);
        if (intent != null) {
            intent2.putExtras(intent);
            intent2.setData(intent.getData());
        }
        return intent2;
    }

    public static final void c(Context context, Class<? extends AppComponent> cls) {
        a(context, cls, (Intent) null);
    }
}
