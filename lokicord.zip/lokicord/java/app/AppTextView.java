package com.discord.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.SpannableStringBuilder;
import android.util.AttributeSet;
import androidx.annotation.StringRes;
import androidx.appcompat.widget.AppCompatTextView;
import com.discord.R;
import com.discord.simpleast.core.a.b;
import java.util.Arrays;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.z;

/* compiled from: AppTextView.kt */
public final class AppTextView extends AppCompatTextView {
    private int uZ;
    private int va;
    private String vb;

    public AppTextView(Context context) {
        this(context, (AttributeSet) null, 0, 6, (DefaultConstructorMarker) null);
    }

    public AppTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, (DefaultConstructorMarker) null);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        int i2;
        k.h(context, "context");
        this.va = -1;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.a.AppTextView, i, 0);
            this.vb = obtainStyledAttributes.getString(0);
            this.va = obtainStyledAttributes.getInt(3, -1);
            this.uZ = obtainStyledAttributes.getResourceId(2, -1);
            boolean z = obtainStyledAttributes.getBoolean(1, false);
            obtainStyledAttributes.recycle();
            if (this.uZ > 0 && (i2 = this.va) > 0) {
                Object[] copyOf = Arrays.copyOf(new Object[0], 0);
                String quantityString = getResources().getQuantityString(this.uZ, i2, new Object[]{Integer.valueOf(i2)});
                z zVar = z.bkH;
                k.g(quantityString, "quantityString");
                Object[] copyOf2 = Arrays.copyOf(copyOf, copyOf.length);
                String format = String.format(quantityString, Arrays.copyOf(copyOf2, copyOf2.length));
                k.g(format, "java.lang.String.format(format, *args)");
                setText(format);
            }
            if (z) {
                g(this.vb, new Object[0]);
            }
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ AppTextView(Context context, AttributeSet attributeSet, int i, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, (i2 & 2) != 0 ? null : attributeSet, (i2 & 4) != 0 ? 0 : i);
    }

    public final String getAttrText() {
        return this.vb;
    }

    public final void setAttrText(String str) {
        this.vb = str;
    }

    public final void g(String str, Object... objArr) {
        SpannableStringBuilder spannableStringBuilder;
        k.h(objArr, "formatArgs");
        if (str != null) {
            if (!(objArr.length == 0)) {
                Object[] copyOf = Arrays.copyOf(objArr, objArr.length);
                str = String.format(str, Arrays.copyOf(copyOf, copyOf.length));
                k.g(str, "java.lang.String.format(this, *args)");
            }
            spannableStringBuilder = b.a(str);
        } else {
            spannableStringBuilder = null;
        }
        setText(spannableStringBuilder);
    }

    public final void a(@StringRes int i, Object... objArr) {
        k.h(objArr, "formatArgs");
        g(getResources().getString(i), Arrays.copyOf(objArr, objArr.length));
    }

    public final void setTextFormatArgs(Object... objArr) {
        k.h(objArr, "formatArgs");
        z zVar = z.bkH;
        String str = this.vb;
        if (str == null) {
            str = "";
        }
        Object[] copyOf = Arrays.copyOf(objArr, objArr.length);
        String format = String.format(str, Arrays.copyOf(copyOf, copyOf.length));
        k.g(format, "java.lang.String.format(format, *args)");
        setText(format);
    }
}
