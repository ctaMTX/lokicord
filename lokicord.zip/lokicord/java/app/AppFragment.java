package com.discord.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.CallSuper;
import androidx.annotation.DrawableRes;
import androidx.annotation.LayoutRes;
import androidx.annotation.MenuRes;
import androidx.annotation.StringRes;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.discord.R;
import com.discord.app.AppActivity;
import com.discord.app.AppPermissions;
import com.discord.utilities.attachments.AttachmentUtilsKt;
import com.discord.utilities.drawable.DrawableCompat;
import com.discord.utilities.view.text.TextWatcher;
import com.discord.views.ToolbarTitleLayout;
import com.lytefast.flexinput.managers.FileManager;
import com.miguelgaeta.media_picker.MediaPicker;
import com.miguelgaeta.media_picker.RequestType;
import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import kotlin.Lazy;
import kotlin.Unit;
import kotlin.f;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.u;
import kotlin.jvm.internal.v;
import kotlin.jvm.internal.w;
import kotlin.reflect.KProperty;
import rx.functions.Action0;
import rx.functions.Action1;
import rx.functions.Action2;
import rx.functions.Func0;
import rx.subjects.PublishSubject;
import rx.subjects.Subject;

/* compiled from: AppFragment.kt */
public abstract class AppFragment extends Fragment implements AppComponent, AppPermissions.Requests, MediaPicker.Provider {
    static final /* synthetic */ KProperty[] $$delegatedProperties = {w.a((u) new v(w.Q(AppFragment.class), "appPermissions", "getAppPermissions()Lcom/discord/app/AppPermissions;")), w.a((u) new v(w.Q(AppFragment.class), "fileManager", "getFileManager()Lcom/lytefast/flexinput/managers/FileManager;"))};
    private final Lazy appPermissions$delegate = f.b(new a(this));
    private final Lazy fileManager$delegate = f.b(new b(this));
    private boolean isRecreated;
    private boolean onViewBoundOrOnResumeInvoked;
    private final Subject<Void, Void> paused;

    private final AppPermissions getAppPermissions() {
        return (AppPermissions) this.appPermissions$delegate.getValue();
    }

    @LayoutRes
    public abstract int getContentViewResId();

    public final FileManager getFileManager() {
        return (FileManager) this.fileManager$delegate.getValue();
    }

    public void hideKeyboard() {
        hideKeyboard$default(this, (View) null, 1, (Object) null);
    }

    public void onImageChosen(Uri uri, String str) {
        k.h(uri, "uri");
        k.h(str, "mimeType");
    }

    public void onImageCropped(Uri uri, String str) {
        k.h(uri, "uri");
        k.h(str, "mimeType");
    }

    @CallSuper
    public void onViewBound(View view) {
        k.h(view, "view");
    }

    @CallSuper
    public void onViewBoundOrOnResume() {
    }

    public final Toolbar setActionBarDisplayHomeAsUpEnabled() {
        return setActionBarDisplayHomeAsUpEnabled$default(this, false, (Integer) null, 3, (Object) null);
    }

    public final Toolbar setActionBarDisplayHomeAsUpEnabled(boolean z) {
        return setActionBarDisplayHomeAsUpEnabled$default(this, z, (Integer) null, 2, (Object) null);
    }

    public final Toolbar setActionBarOptionsMenu(@MenuRes int i, Action2<MenuItem, Context> action2) {
        return setActionBarOptionsMenu$default(this, i, action2, (Action1) null, 4, (Object) null);
    }

    public final void setOnBackPressed(Func0<Boolean> func0) {
        setOnBackPressed$default(this, func0, 0, 2, (Object) null);
    }

    public void showKeyboard() {
        showKeyboard$default(this, (View) null, 1, (Object) null);
    }

    public AppFragment() {
        PublishSubject LJ = PublishSubject.LJ();
        k.g(LJ, "PublishSubject.create()");
        this.paused = LJ;
    }

    public Subject<Void, Void> getPaused() {
        return this.paused;
    }

    /* access modifiers changed from: protected */
    public final boolean isRecreated() {
        return this.isRecreated;
    }

    public final AppActivity getAppActivity() {
        return (AppActivity) getActivity();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r0.getMostRecentIntent();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.content.Intent getMostRecentIntent() {
        /*
            r1 = this;
            com.discord.app.AppActivity r0 = r1.getAppActivity()
            if (r0 == 0) goto L_0x000c
            android.content.Intent r0 = r0.getMostRecentIntent()
            if (r0 != 0) goto L_0x0011
        L_0x000c:
            android.content.Intent r0 = new android.content.Intent
            r0.<init>()
        L_0x0011:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.discord.app.AppFragment.getMostRecentIntent():android.content.Intent");
    }

    public void requestVideoCallPermissions(Action0 action0) {
        getAppPermissions().requestVideoCallPermissions(action0);
    }

    public void requestMedia(Action0 action0) {
        getAppPermissions().requestMedia(action0);
    }

    public void requestMicrophone(Action0 action0) {
        getAppPermissions().requestMicrophone(action0);
    }

    public void requestMediaDownload(Action0 action0) {
        getAppPermissions().requestMediaDownload(action0);
    }

    /* access modifiers changed from: protected */
    @CallSuper
    public Unit bindToolbar() {
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            return bindToolbar(appActivity, getView());
        }
        return null;
    }

    public final ToolbarTitleLayout getActionBarTitleLayout() {
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            return appActivity.dn();
        }
        return null;
    }

    public final Unit setActionBarTitle(CharSequence charSequence) {
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            return appActivity.setActionBarTitle(charSequence);
        }
        return null;
    }

    public final Unit setActionBarTitle(@StringRes int i) {
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            return appActivity.setActionBarTitle(getString(i));
        }
        return null;
    }

    public final Unit setActionBarSubtitle(CharSequence charSequence) {
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            return appActivity.setActionBarSubtitle(charSequence);
        }
        return null;
    }

    public final Unit setActionBarSubtitle(@StringRes int i) {
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            return appActivity.setActionBarSubtitle(getString(i));
        }
        return null;
    }

    public final Unit setActionBarTitleClick(View.OnClickListener onClickListener) {
        k.h(onClickListener, "onClickListener");
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            k.h(onClickListener, "onClickListener");
            ToolbarTitleLayout dn = appActivity.dn();
            if (dn != null) {
                dn.setOnClickListener(onClickListener);
                return Unit.bjE;
            }
        }
        return null;
    }

    public static /* synthetic */ Toolbar setActionBarOptionsMenu$default(AppFragment appFragment, int i, Action2 action2, Action1 action1, int i2, Object obj) {
        if (obj == null) {
            if ((i2 & 4) != 0) {
                action1 = null;
            }
            return appFragment.setActionBarOptionsMenu(i, action2, action1);
        }
        throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: setActionBarOptionsMenu");
    }

    public final Toolbar setActionBarOptionsMenu(@MenuRes int i, Action2<MenuItem, Context> action2, Action1<Menu> action1) {
        Toolbar toolbar;
        AppActivity appActivity = getAppActivity();
        if (appActivity == null || (toolbar = appActivity.toolbar) == null) {
            return null;
        }
        Menu menu = toolbar.getMenu();
        if (menu != null) {
            menu.clear();
        }
        toolbar.inflateMenu(i);
        toolbar.setOnMenuItemClickListener(new AppActivity.j(toolbar, i, action2, action1));
        Menu menu2 = toolbar.getMenu();
        if (!(menu2 == null || action1 == null)) {
            action1.call(menu2);
        }
        return toolbar;
    }

    public static /* synthetic */ Toolbar setActionBarDisplayHomeAsUpEnabled$default(AppFragment appFragment, boolean z, Integer num, int i, Object obj) {
        if (obj == null) {
            if ((i & 1) != 0) {
                z = true;
            }
            if ((i & 2) != 0) {
                num = null;
            }
            return appFragment.setActionBarDisplayHomeAsUpEnabled(z, num);
        }
        throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: setActionBarDisplayHomeAsUpEnabled");
    }

    public final Toolbar setActionBarDisplayHomeAsUpEnabled(boolean z, @DrawableRes Integer num) {
        Toolbar toolbar;
        AppActivity appActivity = getAppActivity();
        Drawable drawable = null;
        if (appActivity == null || (toolbar = appActivity.toolbar) == null) {
            return null;
        }
        if (z) {
            int themedDrawableRes$default = DrawableCompat.getThemedDrawableRes$default((View) toolbar, (int) R.attr.ic_action_bar_back, 0, 2, (Object) null);
            Context context = toolbar.getContext();
            if (num != null) {
                themedDrawableRes$default = num.intValue();
            }
            drawable = ContextCompat.getDrawable(context, themedDrawableRes$default);
        }
        toolbar.setNavigationIcon(drawable);
        return toolbar;
    }

    public final void setOnNewIntentListener(Function1<? super Intent, Unit> function1) {
        k.h(function1, "action");
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            Fragment fragment = this;
            k.h(fragment, "fragmentOwner");
            k.h(function1, "action");
            appActivity.tN.put(fragment, function1);
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        k.h(layoutInflater, "inflater");
        return layoutInflater.inflate(getContentViewResId(), viewGroup, false);
    }

    public void onViewCreated(View view, Bundle bundle) {
        k.h(view, "view");
        super.onViewCreated(view, bundle);
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            bindToolbar(appActivity, view);
        }
        this.isRecreated = bundle != null;
        onViewBound(view);
        onViewBoundOrOnResume();
        this.onViewBoundOrOnResumeInvoked = true;
    }

    public void onResume() {
        super.onResume();
        if (this.onViewBoundOrOnResumeInvoked) {
            this.onViewBoundOrOnResumeInvoked = false;
        } else {
            onViewBoundOrOnResume();
        }
    }

    public void onPause() {
        getPaused().onNext(null);
        super.onPause();
    }

    public void onDestroyView() {
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            String name = getClass().getName();
            k.g(name, "javaClass.name");
            k.h(name, "key");
            Collection<HashMap<String, Function0<Boolean>>> values = appActivity.uk.values();
            k.g(values, "backPressHandlers\n        .values");
            for (HashMap remove : values) {
                remove.remove(name);
            }
        }
        kotterknife.a aVar = kotterknife.a.bpG;
        kotterknife.a.reset(this);
        TextWatcher.Companion.reset(this);
        super.onDestroyView();
    }

    public void onDetach() {
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            Fragment fragment = this;
            k.h(fragment, "fragmentOwner");
            appActivity.tN.remove(fragment);
        }
        super.onDetach();
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        k.h(strArr, "permissions");
        k.h(iArr, "grantResults");
        super.onRequestPermissionsResult(i, strArr, iArr);
        getAppPermissions().a(i, iArr);
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        MediaPicker.handleActivityResult(getContext(), i, i2, intent, new c(this));
    }

    /* compiled from: AppFragment.kt */
    public static final class c implements MediaPicker.OnResult {
        final /* synthetic */ AppFragment this$0;

        public final void onCancelled() {
        }

        c(AppFragment appFragment) {
            this.this$0 = appFragment;
        }

        public final void onSuccess(Uri uri, RequestType requestType) {
            k.h(uri, "uri");
            k.h(requestType, "request");
            Context context = this.this$0.getContext();
            String mimeType$default = AttachmentUtilsKt.getMimeType$default(context != null ? context.getContentResolver() : null, uri, (String) null, 4, (Object) null);
            if (d.$EnumSwitchMapping$0[requestType.ordinal()] != 1) {
                this.this$0.onImageChosen(uri, mimeType$default);
            } else {
                this.this$0.onImageCropped(uri, mimeType$default);
            }
        }

        public final void onError(IOException iOException) {
            k.h(iOException, "e");
            h.a(this.this$0.getContext(), (CharSequence) this.this$0.getString(R.string.upload_open_file_failed, iOException.getMessage()), 0);
        }
    }

    public File getImageFile() {
        return getFileManager().Cp();
    }

    public static /* synthetic */ void setOnBackPressed$default(AppFragment appFragment, Func0 func0, int i, int i2, Object obj) {
        if (obj == null) {
            if ((i2 & 2) != 0) {
                i = 1;
            }
            appFragment.setOnBackPressed(func0, i);
            return;
        }
        throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: setOnBackPressed");
    }

    public final void setOnBackPressed(Func0<Boolean> func0, int i) {
        k.h(func0, "onBackAction");
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            Function0 dVar = new d(func0);
            String name = getClass().getName();
            k.g(name, "javaClass.name");
            k.h(dVar, "handler");
            k.h(name, "key");
            HashMap hashMap = appActivity.uk.get(Integer.valueOf(i));
            if (hashMap == null) {
                hashMap = new HashMap();
            }
            k.g(hashMap, "backPressHandlers[priority] ?: HashMap()");
            hashMap.put(name, dVar);
            appActivity.uk.put(Integer.valueOf(i), hashMap);
        }
    }

    public static /* synthetic */ void showKeyboard$default(AppFragment appFragment, View view, int i, Object obj) {
        if (obj == null) {
            if ((i & 1) != 0) {
                view = null;
            }
            appFragment.showKeyboard(view);
            return;
        }
        throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: showKeyboard");
    }

    public void showKeyboard(View view) {
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            appActivity.showKeyboard(view);
        }
    }

    public static /* synthetic */ void hideKeyboard$default(AppFragment appFragment, View view, int i, Object obj) {
        if (obj == null) {
            if ((i & 1) != 0) {
                view = null;
            }
            appFragment.hideKeyboard(view);
            return;
        }
        throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: hideKeyboard");
    }

    public void hideKeyboard(View view) {
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            appActivity.hideKeyboard(view);
        }
    }

    private final Unit bindToolbar(AppActivity appActivity, View view) {
        Toolbar toolbar;
        if (view == null || (toolbar = (Toolbar) view.findViewById(R.id.action_bar_toolbar)) == null) {
            return null;
        }
        if (!k.n(appActivity.toolbar, toolbar)) {
            appActivity.a(toolbar);
        }
        return Unit.bjE;
    }

    /* compiled from: AppFragment.kt */
    static final class a extends l implements Function0<AppPermissions> {
        final /* synthetic */ AppFragment this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(AppFragment appFragment) {
            super(0);
            this.this$0 = appFragment;
        }

        public final /* synthetic */ Object invoke() {
            return new AppPermissions(this.this$0);
        }
    }

    /* compiled from: AppFragment.kt */
    static final class b extends l implements Function0<com.lytefast.flexinput.managers.b> {
        final /* synthetic */ AppFragment this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        b(AppFragment appFragment) {
            super(0);
            this.this$0 = appFragment;
        }

        public final /* synthetic */ Object invoke() {
            StringBuilder sb = new StringBuilder();
            Context context = this.this$0.getContext();
            sb.append(context != null ? context.getPackageName() : null);
            sb.append(".file-provider");
            String sb2 = sb.toString();
            String string = this.this$0.getString(R.string.discord);
            k.g(string, "getString(R.string.discord)");
            return new com.lytefast.flexinput.managers.b(sb2, string);
        }
    }

    /* compiled from: AppFragment.kt */
    static final class d extends l implements Function0<Boolean> {
        final /* synthetic */ Func0 $onBackAction;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        d(Func0 func0) {
            super(0);
            this.$onBackAction = func0;
        }

        public final /* synthetic */ Object invoke() {
            Object call = this.$onBackAction.call();
            k.g(call, "onBackAction.call()");
            return (Boolean) call;
        }
    }
}
