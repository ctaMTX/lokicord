package com.discord.app;

import android.app.Activity;
import android.app.Application;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Display;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.discord.R;
import com.discord.app.j;
import com.discord.models.domain.ModelUserSettings;
import com.discord.stores.StoreStream;
import com.discord.stores.StoreUserSettings;
import com.discord.utilities.analytics.AnalyticsUtils;
import com.discord.utilities.color.ColorCompat;
import com.discord.utilities.font.FontUtils;
import com.discord.utilities.intent.IntentUtils;
import com.discord.utilities.keyboard.Keyboard;
import com.discord.views.ToolbarTitleLayout;
import com.discord.widgets.debugging.WidgetFatalCrash;
import com.discord.widgets.main.WidgetMain;
import com.discord.widgets.share.WidgetIncomingShare;
import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Lazy;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.u;
import kotlin.jvm.internal.v;
import kotlin.jvm.internal.w;
import kotlin.o;
import kotlin.p;
import kotlin.reflect.KDeclarationContainer;
import kotlin.reflect.KProperty;
import rx.functions.Action1;
import rx.functions.Action2;
import rx.subjects.PublishSubject;
import rx.subjects.Subject;

/* compiled from: AppActivity.kt */
public class AppActivity extends c implements AppComponent {
    static final /* synthetic */ KProperty[] $$delegatedProperties = {w.a((u) new v(w.Q(AppActivity.class), "userSettings", "getUserSettings()Lcom/discord/stores/StoreUserSettings;")), w.a((u) new v(w.Q(AppActivity.class), "screen", "getScreen()Ljava/lang/Class;"))};
    static boolean tT;
    private static final Intent tU = new Intent();
    /* access modifiers changed from: private */
    public static boolean tV = true;
    public static final a tW = new a((byte) 0);
    private final Subject<Void, Void> paused;
    final LinkedHashMap<Fragment, Function1<Intent, Unit>> tN = new LinkedHashMap<>();
    /* access modifiers changed from: private */
    public int tO = -1;
    private String tP = "";
    private final Lazy tQ;
    private final Lazy tR;
    private Intent tS;
    public Toolbar toolbar;

    /* compiled from: AppActivity.kt */
    public static final class Main extends AppActivity {
    }

    /* access modifiers changed from: private */
    public final StoreUserSettings getUserSettings() {
        return (StoreUserSettings) this.tQ.getValue();
    }

    /* access modifiers changed from: protected */
    public Class<? extends AppComponent> getScreen() {
        return (Class) this.tR.getValue();
    }

    /* compiled from: AppActivity.kt */
    static final class g extends kotlin.jvm.internal.l implements Function1<Context, Unit> {
        final /* synthetic */ AppActivity this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        g(AppActivity appActivity) {
            super(1);
            this.this$0 = appActivity;
        }

        public final /* synthetic */ Object invoke(Object obj) {
            w((Context) obj);
            return Unit.bjE;
        }

        public final void w(Context context) {
            Display defaultDisplay;
            kotlin.jvm.internal.k.h(context, "context");
            DisplayMetrics displayMetrics = new DisplayMetrics();
            Resources resources = context.getResources();
            kotlin.jvm.internal.k.g(resources, "context.resources");
            Configuration configuration = resources.getConfiguration();
            configuration.fontScale = FontUtils.INSTANCE.getTargetFontScaleFloat(context);
            WindowManager windowManager = this.this$0.getWindowManager();
            if (!(windowManager == null || (defaultDisplay = windowManager.getDefaultDisplay()) == null)) {
                defaultDisplay.getMetrics(displayMetrics);
            }
            displayMetrics.scaledDensity = configuration.fontScale * displayMetrics.density;
            this.this$0.tO = kotlin.e.a.D(configuration.fontScale * 100.0f);
            context.getResources().updateConfiguration(configuration, displayMetrics);
        }
    }

    /* compiled from: AppActivity.kt */
    static final class h extends kotlin.jvm.internal.l implements Function1<b, Unit> {
        final /* synthetic */ AppActivity this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        h(AppActivity appActivity) {
            super(1);
            this.this$0 = appActivity;
        }

        public final /* synthetic */ Object invoke(Object obj) {
            b bVar = (b) obj;
            kotlin.jvm.internal.k.h(bVar, "it");
            if (AppActivity.a(this.this$0, bVar)) {
                this.this$0.p(true);
            }
            return Unit.bjE;
        }
    }

    /* compiled from: AppActivity.kt */
    static final class k extends kotlin.jvm.internal.l implements Function2<Integer, Boolean, TypedValue> {
        final /* synthetic */ AppActivity this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        k(AppActivity appActivity) {
            super(2);
            this.this$0 = appActivity;
        }

        public final /* synthetic */ Object invoke(Object obj, Object obj2) {
            return b(((Number) obj).intValue(), ((Boolean) obj2).booleanValue());
        }

        public final TypedValue b(int i, boolean z) {
            TypedValue typedValue = new TypedValue();
            this.this$0.getTheme().resolveAttribute(i, typedValue, z);
            return typedValue;
        }
    }

    public AppActivity() {
        Lazy lazy;
        PublishSubject LJ = PublishSubject.LJ();
        kotlin.jvm.internal.k.g(LJ, "PublishSubject.create()");
        this.paused = LJ;
        kotlin.j jVar = kotlin.j.NONE;
        Function0 function0 = m.uf;
        kotlin.jvm.internal.k.h(jVar, "mode");
        kotlin.jvm.internal.k.h(function0, "initializer");
        int i2 = kotlin.g.$EnumSwitchMapping$0[jVar.ordinal()];
        if (i2 == 1) {
            lazy = new p(function0);
        } else if (i2 == 2) {
            lazy = new o(function0);
        } else if (i2 == 3) {
            lazy = new kotlin.u(function0);
        } else {
            throw new kotlin.k();
        }
        this.tQ = lazy;
        this.tR = kotlin.f.b(new i(this));
        this.tS = tU;
    }

    public Subject<Void, Void> getPaused() {
        return this.paused;
    }

    public final void a(Toolbar toolbar2) {
        this.toolbar = toolbar2;
        if (dn() == null) {
            Toolbar toolbar3 = this.toolbar;
            if (toolbar3 != null) {
                toolbar3.addView(new ToolbarTitleLayout(this));
            }
            Toolbar toolbar4 = this.toolbar;
            if (toolbar4 != null) {
                toolbar4.setNavigationOnClickListener(new l(this));
            }
        }
    }

    /* compiled from: AppActivity.kt */
    static final class l implements View.OnClickListener {
        final /* synthetic */ AppActivity this$0;

        l(AppActivity appActivity) {
            this.this$0 = appActivity;
        }

        public final void onClick(View view) {
            if (Keyboard.isOpened()) {
                Keyboard.setKeyboardOpen$default(this.this$0, false, (View) null, 4, (Object) null);
            }
            this.this$0.onBackPressed();
        }
    }

    /* access modifiers changed from: package-private */
    public final ToolbarTitleLayout dn() {
        Toolbar toolbar2 = this.toolbar;
        View childAt = toolbar2 != null ? toolbar2.getChildAt(0) : null;
        if (!(childAt instanceof ToolbarTitleLayout)) {
            childAt = null;
        }
        return (ToolbarTitleLayout) childAt;
    }

    public final Intent getMostRecentIntent() {
        Intent intent = this.tS;
        if (intent != tU) {
            return intent;
        }
        Intent intent2 = getIntent();
        return intent2 == null ? new Intent(tU) : intent2;
    }

    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent == null) {
            intent = tU;
        }
        this.tS = intent;
        a(getMostRecentIntent());
        Intent mostRecentIntent = getMostRecentIntent();
        for (Map.Entry value : this.tN.entrySet()) {
            ((Function1) value.getValue()).invoke(mostRecentIntent);
        }
    }

    /* compiled from: AppActivity.kt */
    static final class c extends kotlin.jvm.internal.l implements Function0<Unit> {
        final /* synthetic */ AppActivity this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        c(AppActivity appActivity) {
            super(0);
            this.this$0 = appActivity;
        }

        public final void invoke() {
            if (AppActivity.tV) {
                AppActivity.tV = false;
                AppLog.i("Application activity initialized.");
                StoreStream.Companion companion = StoreStream.Companion;
                Application application = this.this$0.getApplication();
                kotlin.jvm.internal.k.g(application, "application");
                companion.initialize(application);
                AnalyticsUtils analyticsUtils = AnalyticsUtils.INSTANCE;
                Application application2 = this.this$0.getApplication();
                kotlin.jvm.internal.k.g(application2, "application");
                analyticsUtils.initAppOpen(application2);
                Keyboard keyboard = Keyboard.INSTANCE;
                Application application3 = this.this$0.getApplication();
                kotlin.jvm.internal.k.g(application3, "application");
                keyboard.init(application3);
            }
        }
    }

    public void onCreate(Bundle bundle) {
        c cVar = new c(this);
        d dVar = new d(this);
        e eVar = new e(this);
        f fVar = new f(this);
        g gVar = new g(this);
        try {
            cVar.invoke();
            dVar.invoke();
            super.onCreate(bundle);
            eVar.invoke();
            fVar.invoke();
            if (Build.VERSION.SDK_INT <= 16) {
                gVar.w(this);
            }
            if (!a((kotlin.reflect.b<? extends AppComponent>) w.Q(WidgetMain.class))) {
                StoreStream.Companion.getAnalytics().appUiViewed(getScreen());
            }
        } catch (Exception e2) {
            if (!a((kotlin.reflect.b<? extends AppComponent>) w.Q(WidgetFatalCrash.class))) {
                String name = getScreen().getName();
                kotlin.jvm.internal.k.g(name, "screen.name");
                WidgetFatalCrash.Companion.launch(this, e2, name);
            }
            finish();
        }
    }

    /* compiled from: AppActivity.kt */
    static final class d extends kotlin.jvm.internal.l implements Function0<Unit> {
        final /* synthetic */ AppActivity this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        d(AppActivity appActivity) {
            super(0);
            this.this$0 = appActivity;
        }

        public final void invoke() {
            AppActivity appActivity = this.this$0;
            String theme = appActivity.getUserSettings().getTheme();
            kotlin.jvm.internal.k.g(theme, "userSettings.theme");
            AppActivity.a(appActivity, theme);
            AppActivity appActivity2 = this.this$0;
            String locale = appActivity2.getUserSettings().getLocale();
            kotlin.jvm.internal.k.g(locale, "userSettings.locale");
            appActivity2.b(locale, false);
            if (this.this$0.a((kotlin.reflect.b<? extends AppComponent>) w.Q(WidgetMain.class))) {
                ColorCompat.setStatusBarColorResourceId((Activity) this.this$0, (int) R.color.transparent);
            }
        }
    }

    /* compiled from: AppActivity.kt */
    static final class e extends kotlin.jvm.internal.l implements Function0<Unit> {
        final /* synthetic */ AppActivity this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        e(AppActivity appActivity) {
            super(0);
            this.this$0 = appActivity;
        }

        public final void invoke() {
            AppActivity appActivity = this.this$0;
            appActivity.a(appActivity.getMostRecentIntent());
            Intent mostRecentIntent = this.this$0.getMostRecentIntent();
            AppActivity appActivity2 = this.this$0;
            appActivity2.vK = AppActivity.b(appActivity2, mostRecentIntent);
            if (!(this.this$0.getSupportFragmentManager().findFragmentByTag(this.this$0.getScreen().getName()) != null)) {
                f fVar = f.uP;
                FragmentManager supportFragmentManager = this.this$0.getSupportFragmentManager();
                AppActivity appActivity3 = this.this$0;
                f.a(supportFragmentManager, (Context) appActivity3, (Class) appActivity3.getScreen());
            }
        }
    }

    /* compiled from: AppActivity.kt */
    static final class f extends kotlin.jvm.internal.l implements Function0<Unit> {
        final /* synthetic */ AppActivity this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        f(AppActivity appActivity) {
            super(0);
            this.this$0 = appActivity;
        }

        public final void invoke() {
            if (this.this$0.toolbar == null) {
                AppActivity appActivity = this.this$0;
                appActivity.a((Toolbar) appActivity.findViewById(R.id.action_bar_toolbar));
            }
        }
    }

    /* JADX WARNING: type inference failed for: r4v1, types: [com.discord.app.b] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onResume() {
        /*
            r13 = this;
            super.onResume()
            com.discord.app.f r0 = com.discord.app.f.uP
            boolean r0 = com.discord.app.f.c(r13)
            if (r0 == 0) goto L_0x000c
            return
        L_0x000c:
            com.discord.stores.StoreUserSettings r0 = r13.getUserSettings()
            java.lang.String r0 = r0.getLocale()
            java.lang.String r1 = r13.tP
            boolean r0 = kotlin.jvm.internal.k.n(r0, r1)
            r1 = 1
            r0 = r0 ^ r1
            if (r0 == 0) goto L_0x002d
            java.lang.String r0 = r13.tP
            java.lang.String r2 = ""
            boolean r0 = kotlin.jvm.internal.k.n(r0, r2)
            r0 = r0 ^ r1
            if (r0 == 0) goto L_0x002d
            r13.p(r1)
            return
        L_0x002d:
            com.discord.stores.StoreUserSettings r0 = r13.getUserSettings()
            java.lang.String r0 = r0.getLocale()
            java.lang.String r2 = "userSettings.locale"
            kotlin.jvm.internal.k.g(r0, r2)
            r13.tP = r0
            com.discord.app.AppActivity$b$a r0 = com.discord.app.AppActivity.b.tZ
            com.discord.stores.StoreStream$Companion r0 = com.discord.stores.StoreStream.Companion
            com.discord.stores.StoreUserSettings r0 = r0.getUserSettings()
            rx.Observable r0 = r0.getThemeObservable(r1)
            com.discord.stores.StoreStream$Companion r1 = com.discord.stores.StoreStream.Companion
            com.discord.stores.StoreUserSettings r1 = r1.getUserSettings()
            rx.Observable r1 = r1.getLocaleObservable()
            com.discord.stores.StoreStream$Companion r2 = com.discord.stores.StoreStream.Companion
            com.discord.stores.StoreUserSettings r2 = r2.getUserSettings()
            rx.Observable r2 = r2.getFontScaleObs()
            com.discord.app.AppActivity$b$a$a r3 = com.discord.app.AppActivity.b.a.C0035a.ua
            kotlin.jvm.functions.Function3 r3 = (kotlin.jvm.functions.Function3) r3
            if (r3 == 0) goto L_0x0068
            com.discord.app.b r4 = new com.discord.app.b
            r4.<init>(r3)
            r3 = r4
        L_0x0068:
            rx.functions.Func3 r3 = (rx.functions.Func3) r3
            rx.Observable r0 = rx.Observable.a(r0, r1, r2, r3)
            java.lang.String r1 = "Observable.combineLatest…Obs,\n            ::Model)"
            kotlin.jvm.internal.k.g(r0, r1)
            r1 = r13
            com.discord.app.AppComponent r1 = (com.discord.app.AppComponent) r1
            r2 = 2
            r3 = 0
            rx.Observable r4 = com.discord.utilities.rx.ObservableExtensionsKt.ui$default(r0, r1, r3, r2, r3)
            java.lang.Class r5 = r13.getClass()
            r6 = 0
            r7 = 0
            r8 = 0
            r9 = 0
            com.discord.app.AppActivity$h r0 = new com.discord.app.AppActivity$h
            r0.<init>(r13)
            r10 = r0
            kotlin.jvm.functions.Function1 r10 = (kotlin.jvm.functions.Function1) r10
            r11 = 30
            r12 = 0
            com.discord.utilities.rx.ObservableExtensionsKt.appSubscribe$default((rx.Observable) r4, (java.lang.Class) r5, (android.content.Context) r6, (kotlin.jvm.functions.Function1) r7, (kotlin.jvm.functions.Function1) r8, (kotlin.jvm.functions.Function0) r9, (kotlin.jvm.functions.Function1) r10, (int) r11, (java.lang.Object) r12)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.discord.app.AppActivity.onResume():void");
    }

    public void onPause() {
        super.onPause();
        getPaused().onNext(null);
    }

    public void onDestroy() {
        this.tN.clear();
        super.onDestroy();
    }

    /* access modifiers changed from: protected */
    public void attachBaseContext(Context context) {
        if (Build.VERSION.SDK_INT > 16) {
            if (context == null) {
                context = this;
            }
            Resources resources = context.getResources();
            kotlin.jvm.internal.k.g(resources, "oldContext.resources");
            Configuration configuration = resources.getConfiguration();
            float targetFontScaleFloat = FontUtils.INSTANCE.getTargetFontScaleFloat(context);
            configuration.fontScale = targetFontScaleFloat;
            this.tO = kotlin.e.a.D(targetFontScaleFloat * 100.0f);
            if (Build.VERSION.SDK_INT >= 17) {
                context = context.createConfigurationContext(configuration);
                kotlin.jvm.internal.k.g(context, "oldContext.createConfigurationContext(config)");
            }
        }
        super.attachBaseContext(context);
    }

    public final boolean i(List<? extends kotlin.reflect.b<? extends AppComponent>> list) {
        Object obj;
        kotlin.jvm.internal.k.h(list, "screens");
        Iterator it = list.iterator();
        while (true) {
            if (!it.hasNext()) {
                obj = null;
                break;
            }
            obj = it.next();
            if (kotlin.jvm.internal.k.n(kotlin.jvm.a.b((kotlin.reflect.b) obj), getScreen())) {
                break;
            }
        }
        return obj != null;
    }

    public final boolean a(kotlin.reflect.b<? extends AppComponent> bVar) {
        kotlin.jvm.internal.k.h(bVar, "screen");
        return kotlin.jvm.internal.k.n(kotlin.jvm.a.b(bVar), getScreen());
    }

    public final Unit setActionBarTitle(CharSequence charSequence) {
        ToolbarTitleLayout dn = dn();
        if (dn == null) {
            return null;
        }
        dn.setTitle(charSequence);
        return Unit.bjE;
    }

    public final Unit setActionBarSubtitle(CharSequence charSequence) {
        ToolbarTitleLayout dn = dn();
        if (dn == null) {
            return null;
        }
        dn.setSubtitle(charSequence);
        return Unit.bjE;
    }

    /* compiled from: AppActivity.kt */
    static final class j implements Toolbar.OnMenuItemClickListener {
        final /* synthetic */ Toolbar ub;
        final /* synthetic */ int uc;
        final /* synthetic */ Action2 ud;
        final /* synthetic */ Action1 ue;

        j(Toolbar toolbar, int i, Action2 action2, Action1 action1) {
            this.ub = toolbar;
            this.uc = i;
            this.ud = action2;
            this.ue = action1;
        }

        public final boolean onMenuItemClick(MenuItem menuItem) {
            Action2 action2 = this.ud;
            if (action2 == null) {
                return true;
            }
            action2.call(menuItem, this.ub.getContext());
            Unit unit = Unit.bjE;
            return true;
        }
    }

    public final void showKeyboard(View view) {
        Keyboard.setKeyboardOpen(this, true, view);
    }

    public final void hideKeyboard(View view) {
        Keyboard.setKeyboardOpen(this, false, view);
    }

    /* access modifiers changed from: private */
    public final void p(boolean z) {
        getIntent().putExtra("transition", j.c.TYPE_FADE);
        f.a((Context) this, getScreen(), getIntent());
        finish();
    }

    /* access modifiers changed from: private */
    public final void b(String str, boolean z) {
        Locale localeObject = ModelUserSettings.getLocaleObject(str);
        kotlin.jvm.internal.k.g(localeObject, "locale");
        if (a(localeObject)) {
            Locale.setDefault(localeObject);
            if (Build.VERSION.SDK_INT >= 24) {
                Resources resources = getResources();
                kotlin.jvm.internal.k.g(resources, "resources");
                resources.getConfiguration().setLocale(localeObject);
            } else {
                Resources resources2 = getResources();
                kotlin.jvm.internal.k.g(resources2, "resources");
                resources2.getConfiguration().locale = localeObject;
            }
            Resources resources3 = getResources();
            Resources resources4 = getResources();
            kotlin.jvm.internal.k.g(resources4, "resources");
            Configuration configuration = resources4.getConfiguration();
            Resources resources5 = getResources();
            kotlin.jvm.internal.k.g(resources5, "resources");
            resources3.updateConfiguration(configuration, resources5.getDisplayMetrics());
            if (z) {
                p(true);
            }
        }
    }

    private final boolean a(Locale locale) {
        if (Build.VERSION.SDK_INT >= 24) {
            Resources resources = getResources();
            kotlin.jvm.internal.k.g(resources, "resources");
            Configuration configuration = resources.getConfiguration();
            kotlin.jvm.internal.k.g(configuration, "resources.configuration");
            LocaleList locales = configuration.getLocales();
            kotlin.jvm.internal.k.g(locales, "resources.configuration.locales");
            if (!locales.isEmpty()) {
                Resources resources2 = getResources();
                kotlin.jvm.internal.k.g(resources2, "resources");
                Configuration configuration2 = resources2.getConfiguration();
                kotlin.jvm.internal.k.g(configuration2, "resources.configuration");
                return kotlin.jvm.internal.k.n(configuration2.getLocales().get(0), locale) ^ true;
            }
        }
        Resources resources3 = getResources();
        kotlin.jvm.internal.k.g(resources3, "resources");
        if (resources3.getConfiguration().locale != null) {
            Resources resources4 = getResources();
            kotlin.jvm.internal.k.g(resources4, "resources");
            return kotlin.jvm.internal.k.n(resources4.getConfiguration().locale, locale) ^ true;
        }
    }

    /* access modifiers changed from: private */
    public final void a(Intent intent) {
        tT = IntentUtils.INSTANCE.consumeExternalRoutingIntent(intent, this);
    }

    /* compiled from: AppActivity.kt */
    public static final class AppAction extends AppActivity {
        static final /* synthetic */ KProperty[] $$delegatedProperties = {w.a((u) new v(w.Q(AppAction.class), "screen", "getScreen()Ljava/lang/Class;"))};
        private final Lazy tR = kotlin.f.b(new a(this));

        /* access modifiers changed from: protected */
        public final Class<? extends AppComponent> getScreen() {
            return (Class) this.tR.getValue();
        }

        public final void onCreate(Bundle bundle) {
            AppActivity.super.onCreate(bundle);
            if (AppActivity.tT) {
                finish();
            }
        }

        /* compiled from: AppActivity.kt */
        static final class a extends kotlin.jvm.internal.l implements Function0<Class<? extends AppFragment>> {
            final /* synthetic */ AppAction this$0;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            a(AppAction appAction) {
                super(0);
                this.this$0 = appAction;
            }

            public final /* synthetic */ Object invoke() {
                String action = this.this$0.getMostRecentIntent().getAction();
                if (action == null) {
                    return WidgetMain.class;
                }
                int hashCode = action.hashCode();
                if (hashCode != -1173264947) {
                    if (hashCode == -58484670 && action.equals("android.intent.action.SEND_MULTIPLE")) {
                        return WidgetIncomingShare.class;
                    }
                    return WidgetMain.class;
                } else if (action.equals("android.intent.action.SEND")) {
                    return WidgetIncomingShare.class;
                } else {
                    return WidgetMain.class;
                }
            }
        }
    }

    /* compiled from: AppActivity.kt */
    public static final class b {
        public static final a tZ = new a((byte) 0);
        final int fontScale;
        final String tX;
        final String tY;

        public final boolean equals(Object obj) {
            if (this != obj) {
                if (obj instanceof b) {
                    b bVar = (b) obj;
                    if (kotlin.jvm.internal.k.n(this.tX, bVar.tX) && kotlin.jvm.internal.k.n(this.tY, bVar.tY)) {
                        if (this.fontScale == bVar.fontScale) {
                            return true;
                        }
                    }
                }
                return false;
            }
            return true;
        }

        public final int hashCode() {
            String str = this.tX;
            int i = 0;
            int hashCode = (str != null ? str.hashCode() : 0) * 31;
            String str2 = this.tY;
            if (str2 != null) {
                i = str2.hashCode();
            }
            return ((hashCode + i) * 31) + this.fontScale;
        }

        public final String toString() {
            return "Model(themeName=" + this.tX + ", localeString=" + this.tY + ", fontScale=" + this.fontScale + ")";
        }

        public b(String str, String str2, int i) {
            kotlin.jvm.internal.k.h(str, "themeName");
            kotlin.jvm.internal.k.h(str2, "localeString");
            this.tX = str;
            this.tY = str2;
            this.fontScale = i;
        }

        /* compiled from: AppActivity.kt */
        public static final class a {

            /* renamed from: com.discord.app.AppActivity$b$a$a  reason: collision with other inner class name */
            /* compiled from: AppActivity.kt */
            static final /* synthetic */ class C0035a extends kotlin.jvm.internal.j implements Function3<String, String, Integer, b> {
                public static final C0035a ua = new C0035a();

                C0035a() {
                    super(3);
                }

                public final String getName() {
                    return "<init>";
                }

                public final KDeclarationContainer getOwner() {
                    return w.Q(b.class);
                }

                public final String getSignature() {
                    return "<init>(Ljava/lang/String;Ljava/lang/String;I)V";
                }

                public final /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
                    String str = (String) obj;
                    String str2 = (String) obj2;
                    int intValue = ((Number) obj3).intValue();
                    kotlin.jvm.internal.k.h(str, "p1");
                    kotlin.jvm.internal.k.h(str2, "p2");
                    return new b(str, str2, intValue);
                }
            }

            private a() {
            }

            public /* synthetic */ a(byte b2) {
                this();
            }
        }
    }

    /* compiled from: AppActivity.kt */
    public static final class a {
        private a() {
        }

        public /* synthetic */ a(byte b2) {
            this();
        }
    }

    /* compiled from: AppActivity.kt */
    static final class m extends kotlin.jvm.internal.l implements Function0<StoreUserSettings> {
        public static final m uf = new m();

        m() {
            super(0);
        }

        public final /* synthetic */ Object invoke() {
            return StoreStream.Companion.getUserSettings();
        }
    }

    /* compiled from: AppActivity.kt */
    static final class i extends kotlin.jvm.internal.l implements Function0<Class<? extends AppComponent>> {
        final /* synthetic */ AppActivity this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        i(AppActivity appActivity) {
            super(0);
            this.this$0 = appActivity;
        }

        public final /* synthetic */ Object invoke() {
            Intent intent = this.this$0.getIntent();
            Class cls = (Class) (intent != null ? intent.getSerializableExtra("com.discord.intent.extra.EXTRA_SCREEN") : null);
            return cls == null ? WidgetMain.class : cls;
        }
    }

    public static final /* synthetic */ void a(AppActivity appActivity, String str) {
        int i2;
        f fVar = f.uP;
        if (!appActivity.i(f.dx())) {
            if (kotlin.jvm.internal.k.n(str, ModelUserSettings.THEME_LIGHT)) {
                i2 = 2131951646;
            } else if (!kotlin.jvm.internal.k.n(str, "dark") && kotlin.jvm.internal.k.n(str, ModelUserSettings.THEME_PURE_EVIL)) {
                i2 = 2131951641;
            }
            appActivity.setTheme(i2);
        }
        i2 = 2131951638;
        appActivity.setTheme(i2);
    }

    public static final /* synthetic */ j.a b(AppActivity appActivity, Intent intent) {
        j.c cVar;
        Serializable serializableExtra = intent != null ? intent.getSerializableExtra("transition") : null;
        if (!(serializableExtra instanceof j.c)) {
            serializableExtra = null;
        }
        j.c cVar2 = (j.c) serializableExtra;
        if (cVar2 != null) {
            cVar = cVar2;
        } else {
            f fVar = f.uP;
            cVar = appActivity.i(f.dv()) ? j.c.TYPE_SLIDE_HORIZONTAL : null;
        }
        if (cVar != null) {
            return cVar.animations;
        }
        return null;
    }

    public static final /* synthetic */ boolean a(AppActivity appActivity, b bVar) {
        boolean z;
        Locale localeObject = ModelUserSettings.getLocaleObject(bVar.tY);
        kotlin.jvm.internal.k.g(localeObject, "ModelUserSettings.getLoc…bject(model.localeString)");
        if (appActivity.a(localeObject)) {
            appActivity.b(bVar.tY, true);
            return true;
        }
        String str = bVar.tX;
        f fVar = f.uP;
        if (appActivity.i(f.dx())) {
            z = false;
        } else {
            z = !kotlin.jvm.internal.k.n(new k(appActivity).b(R.attr.theme_name, true).string, str);
        }
        if (!z) {
            int i2 = bVar.fontScale;
            FontUtils fontUtils = FontUtils.INSTANCE;
            ContentResolver contentResolver = appActivity.getContentResolver();
            kotlin.jvm.internal.k.g(contentResolver, "contentResolver");
            if ((i2 == -1 && appActivity.tO != fontUtils.getSystemFontScaleInt(contentResolver)) || !(i2 == -1 || appActivity.tO == i2)) {
                return true;
            }
            return false;
        }
        return true;
    }
}
