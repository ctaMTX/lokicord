package com.discord.app;

import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.k;
import rx.functions.Action4;

/* compiled from: App.kt */
final class a implements Action4 {
    private final /* synthetic */ Function4 function;

    a(Function4 function4) {
        this.function = function4;
    }

    public final /* synthetic */ void a(Object obj, Object obj2, Object obj3) {
        k.g(this.function.invoke(obj, obj2, obj3, null), "invoke(...)");
    }
}
