package com.discord.app;

import android.content.Context;
import android.text.Editable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import androidx.appcompat.widget.AppCompatEditText;
import kotlin.r;
import kotlin.text.l;

/* compiled from: AppEditText.kt */
public final class AppEditText extends AppCompatEditText {
    private boolean uj;

    public AppEditText(Context context) {
        super(context);
    }

    public AppEditText(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public AppEditText(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public final boolean onKeyPreIme(int i, KeyEvent keyEvent) {
        if (this.uj && keyEvent != null && keyEvent.getKeyCode() == 4) {
            clearFocus();
        }
        return super.onKeyPreIme(i, keyEvent);
    }

    public final void setOnBackClearFocus(boolean z) {
        this.uj = z;
    }

    public final String getTrimmedText() {
        Editable text = getText();
        CharSequence trim = text != null ? l.trim(text) : null;
        if (trim != null) {
            setText((Editable) trim);
            return String.valueOf(getText());
        }
        throw new r("null cannot be cast to non-null type android.text.Editable");
    }
}
