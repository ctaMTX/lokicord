package com.discord.app;

import android.content.Context;
import androidx.core.app.NotificationCompat;
import com.discord.utilities.dimmer.DimmerView;
import com.discord.utilities.error.Error;
import com.discord.utilities.mg_recycler.MGRecyclerAdapterSimple;
import com.discord.utilities.rx.ObservableExtensionsKt;
import com.discord.utilities.rx.OnDelayedEmissionHandler;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import kotlin.Unit;
import kotlin.a.ad;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.reflect.KDeclarationContainer;
import rx.Observable;
import rx.Scheduler;
import rx.Subscription;
import rx.functions.Action1;

/* compiled from: AppTransformers.kt */
public final class i {
    public static final i vd = new i();

    public static final <T> Observable.c<T, T> a(Action1<? super T> action1, Class<?> cls) {
        return a(action1, cls, (Action1) null, (Action1) null, 28);
    }

    public static final <T> Observable.c<T, T> a(Action1<? super T> action1, Class<?> cls, Action1<Subscription> action12) {
        return a(action1, cls, (Action1) null, action12, 16);
    }

    public static final <T> Observable.c<T, T> ad(String str) {
        return kotlin.jvm.internal.k.h(str, NotificationCompat.CATEGORY_ERROR);
    }

    /* compiled from: AppTransformers.kt */
    static final /* synthetic */ class h extends kotlin.jvm.internal.j implements Function1<T, Unit> {
        h(Action1 action1) {
            super(1, action1);
        }

        public final String getName() {
            return NotificationCompat.CATEGORY_CALL;
        }

        public final KDeclarationContainer getOwner() {
            return kotlin.jvm.internal.w.Q(Action1.class);
        }

        public final String getSignature() {
            return "call(Ljava/lang/Object;)V";
        }

        public final /* synthetic */ Object invoke(Object obj) {
            ((Action1) this.receiver).call(obj);
            return Unit.bjE;
        }
    }

    /* renamed from: com.discord.app.i$i  reason: collision with other inner class name */
    /* compiled from: AppTransformers.kt */
    static final /* synthetic */ class C0036i extends kotlin.jvm.internal.j implements Function1<T, Unit> {
        C0036i(Action1 action1) {
            super(1, action1);
        }

        public final String getName() {
            return NotificationCompat.CATEGORY_CALL;
        }

        public final KDeclarationContainer getOwner() {
            return kotlin.jvm.internal.w.Q(Action1.class);
        }

        public final String getSignature() {
            return "call(Ljava/lang/Object;)V";
        }

        public final /* synthetic */ Object invoke(Object obj) {
            ((Action1) this.receiver).call(obj);
            return Unit.bjE;
        }
    }

    /* compiled from: AppTransformers.kt */
    static final class l extends kotlin.jvm.internal.l implements Function1<T, Unit> {
        public static final l vz = new l();

        l() {
            super(1);
        }

        public final /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return Unit.bjE;
        }
    }

    /* compiled from: AppTransformers.kt */
    static final class m extends kotlin.jvm.internal.l implements Function1<T, Unit> {
        public static final m vA = new m();

        m() {
            super(1);
        }

        public final /* bridge */ /* synthetic */ Object invoke(Object obj) {
            return Unit.bjE;
        }
    }

    /* compiled from: AppTransformers.kt */
    static final /* synthetic */ class n extends kotlin.jvm.internal.j implements Function1<T, Unit> {
        n(Action1 action1) {
            super(1, action1);
        }

        public final String getName() {
            return NotificationCompat.CATEGORY_CALL;
        }

        public final KDeclarationContainer getOwner() {
            return kotlin.jvm.internal.w.Q(Action1.class);
        }

        public final String getSignature() {
            return "call(Ljava/lang/Object;)V";
        }

        public final /* synthetic */ Object invoke(Object obj) {
            ((Action1) this.receiver).call(obj);
            return Unit.bjE;
        }
    }

    /* compiled from: AppTransformers.kt */
    static final /* synthetic */ class o extends kotlin.jvm.internal.j implements Function1<T, Unit> {
        o(Action1 action1) {
            super(1, action1);
        }

        public final String getName() {
            return NotificationCompat.CATEGORY_CALL;
        }

        public final KDeclarationContainer getOwner() {
            return kotlin.jvm.internal.w.Q(Action1.class);
        }

        public final String getSignature() {
            return "call(Ljava/lang/Object;)V";
        }

        public final /* synthetic */ Object invoke(Object obj) {
            ((Action1) this.receiver).call(obj);
            return Unit.bjE;
        }
    }

    /* compiled from: AppTransformers.kt */
    static final /* synthetic */ class p extends kotlin.jvm.internal.j implements Function1<T, Unit> {
        p(Action1 action1) {
            super(1, action1);
        }

        public final String getName() {
            return NotificationCompat.CATEGORY_CALL;
        }

        public final KDeclarationContainer getOwner() {
            return kotlin.jvm.internal.w.Q(Action1.class);
        }

        public final String getSignature() {
            return "call(Ljava/lang/Object;)V";
        }

        public final /* synthetic */ Object invoke(Object obj) {
            ((Action1) this.receiver).call(obj);
            return Unit.bjE;
        }
    }

    /* compiled from: AppTransformers.kt */
    static final class r extends kotlin.jvm.internal.l implements Function1<Boolean, Boolean> {
        public static final r vF = new r();

        r() {
            super(1);
        }

        public final /* synthetic */ Object invoke(Object obj) {
            return Boolean.valueOf(((Boolean) obj).booleanValue());
        }
    }

    /* compiled from: AppTransformers.kt */
    static final class s extends kotlin.jvm.internal.l implements Function1<Boolean, Observable<R>> {
        final /* synthetic */ Observable $defaultValue;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        s(Observable observable) {
            super(1);
            this.$defaultValue = observable;
        }

        public final /* synthetic */ Object invoke(Object obj) {
            ((Boolean) obj).booleanValue();
            return this.$defaultValue;
        }
    }

    private i() {
    }

    /* compiled from: AppTransformers.kt */
    static final class v<T, R> implements Observable.c<T, T> {
        public static final v vH = new v();

        v() {
        }

        public final /* synthetic */ Object call(Object obj) {
            return ((Observable) obj).a(rx.android.b.a.Ko());
        }
    }

    public static final <T> Observable.c<T, T> dz() {
        return v.vH;
    }

    /* compiled from: AppTransformers.kt */
    static final class w<T, R> implements Observable.c<T, T> {
        final /* synthetic */ MGRecyclerAdapterSimple $adapter;
        final /* synthetic */ AppComponent vI;

        w(AppComponent appComponent, MGRecyclerAdapterSimple mGRecyclerAdapterSimple) {
            this.vI = appComponent;
            this.$adapter = mGRecyclerAdapterSimple;
        }

        public final /* synthetic */ Object call(Object obj) {
            Observable observable = (Observable) obj;
            kotlin.jvm.internal.k.g(observable, "it");
            return ObservableExtensionsKt.ui(observable, this.vI, this.$adapter);
        }
    }

    public static final <T> Observable.c<T, T> a(AppComponent appComponent, MGRecyclerAdapterSimple<?> mGRecyclerAdapterSimple) {
        kotlin.jvm.internal.k.h(appComponent, "appComponent");
        return new w<>(appComponent, mGRecyclerAdapterSimple);
    }

    /* compiled from: AppTransformers.kt */
    static final class g<T, R> implements Observable.c<T, T> {
        final /* synthetic */ boolean vs;

        g(boolean z) {
            this.vs = z;
        }

        public final /* synthetic */ Object call(Object obj) {
            Observable observable = (Observable) obj;
            kotlin.jvm.internal.k.g(observable, "it");
            return ObservableExtensionsKt.restSubscribeOn(observable, this.vs);
        }
    }

    public static final <T> Observable.c<T, T> q(boolean z) {
        return new g<>(z);
    }

    /* compiled from: AppTransformers.kt */
    static final class x<T, R> implements Observable.c<T, T> {
        final /* synthetic */ long $delay;
        final /* synthetic */ DimmerView vJ;

        x(DimmerView dimmerView, long j) {
            this.vJ = dimmerView;
            this.$delay = j;
        }

        public final /* synthetic */ Object call(Object obj) {
            return ((Observable) obj).a(new OnDelayedEmissionHandler(new Function1<Boolean, Unit>(this) {
                final /* synthetic */ x this$0;

                {
                    this.this$0 = r1;
                }

                public final /* synthetic */ Object invoke(Object obj) {
                    boolean booleanValue = ((Boolean) obj).booleanValue();
                    DimmerView dimmerView = this.this$0.vJ;
                    if (dimmerView != null) {
                        DimmerView.setDimmed$default(dimmerView, booleanValue, false, 2, (Object) null);
                    }
                    return Unit.bjE;
                }
            }, this.$delay, TimeUnit.MILLISECONDS, (Scheduler) null, 8, (DefaultConstructorMarker) null));
        }
    }

    public static final <T> Observable.c<T, T> a(DimmerView dimmerView, long j2) {
        return new x<>(dimmerView, j2);
    }

    /* compiled from: AppTransformers.kt */
    static final class a<T, R> implements Observable.c<T, T> {
        public static final a ve = new a();

        a() {
        }

        public final /* synthetic */ Object call(Object obj) {
            Observable observable = (Observable) obj;
            kotlin.jvm.internal.k.g(observable, "observable");
            return ObservableExtensionsKt.computationBuffered(observable);
        }
    }

    public static final <T> Observable.c<T, T> dC() {
        return a.ve;
    }

    /* compiled from: AppTransformers.kt */
    static final class b<T, R> implements Observable.c<T, T> {
        public static final b vf = new b();

        b() {
        }

        public final /* synthetic */ Object call(Object obj) {
            Observable observable = (Observable) obj;
            kotlin.jvm.internal.k.g(observable, "observable");
            return ObservableExtensionsKt.computationBuffered(observable).Kb();
        }
    }

    public static final <T> Observable.c<T, T> dD() {
        return b.vf;
    }

    public static /* synthetic */ Observable.c a(Action1 action1, Class cls, Action1 action12, Action1 action13, int i) {
        int i2 = i & 8;
        Function1 function1 = null;
        if (i2 != 0) {
            action13 = null;
        }
        kotlin.jvm.internal.k.h(action1, "onNext");
        kotlin.jvm.internal.k.h(cls, "errorClass");
        Function1 iVar = new C0036i(action1);
        if (action13 != null) {
            function1 = new y(action13);
        }
        return a(iVar, cls, (Action1) null, function1, (Context) null, 32);
    }

    /* compiled from: AppTransformers.kt */
    static final class j<T, R> implements Observable.c<T, T> {
        final /* synthetic */ Context $context;
        final /* synthetic */ Function1 $onNext;
        final /* synthetic */ Class vt;
        final /* synthetic */ Function1 vu;
        final /* synthetic */ Action1 vv;
        final /* synthetic */ Function0 vw;

        j(Context context, Class cls, Function1 function1, Function1 function12, Action1 action1, Function0 function0) {
            this.$context = context;
            this.vt = cls;
            this.vu = function1;
            this.$onNext = function12;
            this.vv = action1;
            this.vw = function0;
        }

        public final /* synthetic */ Object call(Object obj) {
            Function1 function1;
            Observable observable = (Observable) obj;
            kotlin.jvm.internal.k.g(observable, "observable");
            Context context = this.$context;
            String simpleName = this.vt.getSimpleName();
            kotlin.jvm.internal.k.g(simpleName, "errorClass.simpleName");
            Function1 function12 = this.vu;
            Function1 function13 = this.$onNext;
            Action1 action1 = this.vv;
            if (action1 != null) {
                i iVar = i.vd;
                function1 = new y(action1);
            } else {
                function1 = null;
            }
            Function0 function0 = this.vw;
            if (function0 == null) {
                function0 = AnonymousClass1.vx;
            }
            ObservableExtensionsKt.appSubscribe(observable, context, simpleName, (Function1<? super Subscription, Unit>) function12, function13, (Function1<? super Error, Unit>) function1, (Function0<Unit>) function0);
            return null;
        }
    }

    public static /* synthetic */ Observable.c a(Function1 function1, Class cls, Action1 action1, Function1 function12, Context context, int i) {
        return a(function1, (Class<?>) cls, (Action1<Error>) (i & 4) != 0 ? null : action1, (Function1<? super Subscription, Unit>) (i & 8) != 0 ? null : function12, (Context) null, (Function0<Unit>) null);
    }

    private static <T> Observable.c<T, T> a(Function1<? super T, Unit> function1, Class<?> cls, Action1<Error> action1, Function1<? super Subscription, Unit> function12, Context context, Function0<Unit> function0) {
        kotlin.jvm.internal.k.h(function1, "onNext");
        kotlin.jvm.internal.k.h(cls, "errorClass");
        return new j<>(context, cls, function12, function1, action1, (Function0) null);
    }

    /* compiled from: AppTransformers.kt */
    static final class k<T, R> implements Observable.c<T, T> {
        final /* synthetic */ Context $context;
        final /* synthetic */ Function1 $errorHandler;
        final /* synthetic */ String $errorTag;
        final /* synthetic */ Function1 $onNext;
        final /* synthetic */ Function1 vu;
        final /* synthetic */ Function0 vw;

        k(Context context, String str, Function1 function1, Function1 function12, Function1 function13, Function0 function0) {
            this.$context = context;
            this.$errorTag = str;
            this.vu = function1;
            this.$onNext = function12;
            this.$errorHandler = function13;
            this.vw = function0;
        }

        public final /* synthetic */ Object call(Object obj) {
            Observable observable = (Observable) obj;
            kotlin.jvm.internal.k.g(observable, "observable");
            Context context = this.$context;
            String str = this.$errorTag;
            Function1 function1 = this.vu;
            Function1 function12 = this.$onNext;
            Function1 function13 = this.$errorHandler;
            Function0 function0 = this.vw;
            if (function0 == null) {
                function0 = AnonymousClass1.vy;
            }
            ObservableExtensionsKt.appSubscribe(observable, context, str, (Function1<? super Subscription, Unit>) function1, function12, (Function1<? super Error, Unit>) function13, (Function0<Unit>) function0);
            return null;
        }
    }

    public static /* synthetic */ Observable.c a(Function1 function1, String str, Function1 function12, Function1 function13, Context context, int i) {
        return a(function1, str, (Function1<? super Error, Unit>) (i & 4) != 0 ? null : function12, (Function1<? super Subscription, Unit>) (i & 8) != 0 ? null : function13, (i & 16) != 0 ? null : context, (Function0<Unit>) null);
    }

    private static <T> Observable.c<T, T> a(Function1<? super T, Unit> function1, String str, Function1<? super Error, Unit> function12, Function1<? super Subscription, Unit> function13, Context context, Function0<Unit> function0) {
        kotlin.jvm.internal.k.h(function1, "onNext");
        kotlin.jvm.internal.k.h(str, "errorTag");
        return new k<>(context, str, function13, function1, function12, (Function0) null);
    }

    public static final <T> Observable.c<T, T> a(Action1<? super T> action1, Context context, Action1<Error> action12) {
        kotlin.jvm.internal.k.h(action1, "onNext");
        return a(new n(action1), "restClient", action12 != null ? new y(action12) : null, (Function1) null, context, 40);
    }

    public static final <T> Observable.c<T, T> a(Action1<? super T> action1, AppFragment appFragment) {
        kotlin.jvm.internal.k.h(action1, "onNext");
        kotlin.jvm.internal.k.h(appFragment, "fragment");
        return vd.a(appFragment.getContext(), new o(action1), (Action1<Error>) null);
    }

    public static final <T> Observable.c<T, T> a(Action1<? super T> action1, AppDialog appDialog) {
        kotlin.jvm.internal.k.h(action1, "onNext");
        kotlin.jvm.internal.k.h(appDialog, "dialog");
        return vd.a(appDialog.getContext(), new p(action1), (Action1<Error>) null);
    }

    /* compiled from: AppTransformers.kt */
    static final class f<T, R> implements Observable.c<T, T> {
        final /* synthetic */ long $timeout;
        final /* synthetic */ Function1 vo;
        final /* synthetic */ Object vp;
        final /* synthetic */ TimeUnit vq;

        f(Function1 function1, Object obj, long j, TimeUnit timeUnit) {
            this.vo = function1;
            this.vp = obj;
            this.$timeout = j;
            this.vq = timeUnit;
        }

        public final /* synthetic */ Object call(Object obj) {
            return ((Observable) obj).g(new rx.functions.b<T, Observable<? extends R>>(this) {
                final /* synthetic */ f vr;

                {
                    this.vr = r1;
                }

                public final /* synthetic */ Object call(Object obj) {
                    if (((Boolean) this.vr.vo.invoke(obj)).booleanValue()) {
                        return Observable.bI(obj);
                    }
                    return Observable.bI(this.vr.vp).j(this.vr.$timeout, this.vr.vq);
                }
            });
        }
    }

    public static final <T> Observable.c<T, T> a(Function1<? super T, Boolean> function1, T t2, long j2, TimeUnit timeUnit) {
        kotlin.jvm.internal.k.h(function1, "predicate");
        kotlin.jvm.internal.k.h(timeUnit, "timeUnit");
        return new f<>(function1, t2, j2, timeUnit);
    }

    /* compiled from: AppTransformers.kt */
    static final class u<T, R> implements Observable.c<T, T> {
        final /* synthetic */ long vG = 5000;

        u(long j) {
        }

        public final /* synthetic */ Object call(Object obj) {
            Observable observable = (Observable) obj;
            kotlin.jvm.internal.k.g(observable, "observable");
            return ObservableExtensionsKt.takeSingleUntilTimeout$default(observable, this.vG, false, 2, (Object) null);
        }
    }

    /* compiled from: AppTransformers.kt */
    static final class c extends kotlin.jvm.internal.l implements Function1<T, T> {
        public static final c vg = new c();

        c() {
            super(1);
        }

        public final T invoke(T t) {
            if (t == null) {
                kotlin.jvm.internal.k.Em();
            }
            return t;
        }
    }

    public static final <K, T> Observable.c<Map<K, T>, Map<K, T>> a(Collection<? extends K> collection) {
        kotlin.jvm.internal.k.h(collection, "filterKeys");
        return a(collection, c.vg);
    }

    public static final <K, V, V1> Observable.c<Map<K, V>, Map<K, V1>> a(Collection<? extends K> collection, Function1<? super V, ? extends V1> function1) {
        kotlin.jvm.internal.k.h(function1, "valueMapper");
        if (collection == null || collection.isEmpty()) {
            return d.vh;
        }
        return new e<>(collection, function1);
    }

    /* compiled from: AppTransformers.kt */
    static final class e<T, R> implements Observable.c<Map<K, ? extends V>, Map<K, ? extends V1>> {
        final /* synthetic */ Collection vi;
        final /* synthetic */ Function1 vj;

        e(Collection collection, Function1 function1) {
            this.vi = collection;
            this.vj = function1;
        }

        public final /* synthetic */ Object call(Object obj) {
            return ((Observable) obj).g(new rx.functions.b<T, Observable<? extends R>>(this) {
                final /* synthetic */ e vk;

                {
                    this.vk = r1;
                }

                public final /* synthetic */ Object call(Object obj) {
                    final Map map = (Map) obj;
                    return Observable.D(this.vk.vi).b(new rx.functions.b<K, Boolean>() {
                        public final /* synthetic */ Object call(Object obj) {
                            return Boolean.valueOf(map.containsKey(obj));
                        }
                    }).a(AnonymousClass2.vm, new rx.functions.b<T, V>(this) {
                        final /* synthetic */ AnonymousClass1 vn;

                        {
                            this.vn = r1;
                        }

                        public final V1 call(K k) {
                            return this.vn.vk.vj.invoke(map.get(k));
                        }
                    });
                }
            }).Kb();
        }
    }

    /* compiled from: AppTransformers.kt */
    static final class q<T, R> implements Observable.c<T, R> {
        final /* synthetic */ Function1 vB;
        final /* synthetic */ Function1 vC;
        final /* synthetic */ Function1 vD;

        q(Function1 function1, Function1 function12, Function1 function13) {
            this.vB = function1;
            this.vC = function12;
            this.vD = function13;
        }

        public final /* synthetic */ Object call(Object obj) {
            return ((Observable) obj).g(new rx.functions.b<T, Observable<? extends R>>(this) {
                final /* synthetic */ q vE;

                {
                    this.vE = r1;
                }

                public final /* synthetic */ Object call(Object obj) {
                    if (((Boolean) this.vE.vB.invoke(obj)).booleanValue()) {
                        return (Observable) this.vE.vC.invoke(obj);
                    }
                    return (Observable) this.vE.vD.invoke(obj);
                }
            });
        }
    }

    private static <T, R> Observable.c<T, R> a(Function1<? super T, Boolean> function1, Function1<? super T, ? extends Observable<R>> function12, Function1<? super T, ? extends Observable<R>> function13) {
        kotlin.jvm.internal.k.h(function1, "observableCondition");
        kotlin.jvm.internal.k.h(function12, "switchedObservableFunc");
        kotlin.jvm.internal.k.h(function13, "defaultObservableFunc");
        return new q<>(function1, function12, function13);
    }

    public static final <R> Observable.c<Boolean, R> a(R r2, Observable<R> observable) {
        kotlin.jvm.internal.k.h(observable, "defaultValue");
        return a(r.vF, r2, new s(observable));
    }

    public static final <T, R> Observable.c<T, R> a(Function1<? super T, Boolean> function1, R r2, Function1<? super T, ? extends Observable<R>> function12) {
        kotlin.jvm.internal.k.h(function1, "observableCondition");
        kotlin.jvm.internal.k.h(function12, "defaultObservableFunc");
        return a(function1, new t(r2), (t) function12);
    }

    public final <T> Observable.c<T, T> a(Context context, Function1<? super T, Unit> function1, Action1<Error> action1) {
        kotlin.jvm.internal.k.h(function1, "onNext");
        return a((Function1) function1, "restClient", action1 != null ? new y(action1) : null, (Function1) null, context, 40);
    }

    public static final <T> Observable.c<T, T> b(AppComponent appComponent) {
        return a(appComponent, (MGRecyclerAdapterSimple<?>) null);
    }

    public static final <T> Observable.c<T, T> dB() {
        return q(true);
    }

    public static final <T> Observable.c<T, T> b(DimmerView dimmerView) {
        return a(dimmerView, 450);
    }

    public static final <T> Observable.c<T, T> a(Action1<? super T> action1, String str) {
        kotlin.jvm.internal.k.h(action1, "onNext");
        kotlin.jvm.internal.k.h(str, "errorTag");
        return a((Function1) new h(action1), str, (Function1) null, (Function1) null, (Context) null, 32);
    }

    /* compiled from: AppTransformers.kt */
    static final class d<T, R> implements Observable.c<Map<K, ? extends V>, Map<K, ? extends V1>> {
        public static final d vh = new d();

        d() {
        }

        public final /* synthetic */ Object call(Object obj) {
            return Observable.bI(ad.emptyMap());
        }
    }

    /* compiled from: AppTransformers.kt */
    static final class t extends kotlin.jvm.internal.l implements Function1<T, Observable<R>> {
        final /* synthetic */ Object $switchedValue;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        t(Object obj) {
            super(1);
            this.$switchedValue = obj;
        }

        public final /* synthetic */ Object invoke(Object obj) {
            Observable bI = Observable.bI(this.$switchedValue);
            kotlin.jvm.internal.k.g(bI, "Observable.just(switchedValue)");
            return bI;
        }
    }

    /* compiled from: AppTransformers.kt */
    public static final class y extends kotlin.jvm.internal.l implements Function1<T, Unit> {
        final /* synthetic */ Action1 $action;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public y(Action1 action1) {
            super(1);
            this.$action = action1;
        }

        public final /* synthetic */ Object invoke(Object obj) {
            this.$action.call(obj);
            return Unit.bjE;
        }
    }

    public static final <T> Observable.c<T, T> b(Action1<? super T> action1, Context context) {
        return a(action1, context, (Action1<Error>) null);
    }

    public static final <T> Observable.c<T, T> dE() {
        return new u<>(5000);
    }
}
