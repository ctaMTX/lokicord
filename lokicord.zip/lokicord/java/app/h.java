package com.discord.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.ContextThemeWrapper;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import com.discord.R;
import kotlin.jvm.internal.k;

/* compiled from: AppToast.kt */
public final class h {
    public static final h vc = new h();

    public static final void b(Fragment fragment, @StringRes int i) {
        a(fragment, i);
    }

    private h() {
    }

    public static final void a(Context context, @StringRes int i, int i2) {
        a(context, (CharSequence) context != null ? context.getString(i) : null, i2);
    }

    /* access modifiers changed from: private */
    public static void a(Fragment fragment, CharSequence charSequence, int i) {
        a(fragment != null ? fragment.getContext() : null, charSequence, 0);
    }

    public static final void b(Context context, CharSequence charSequence, int i) {
        k.h(context, "context");
        k.h(charSequence, "text");
        Object systemService = context.getSystemService("clipboard");
        if (!(systemService instanceof ClipboardManager)) {
            systemService = null;
        }
        ClipboardManager clipboardManager = (ClipboardManager) systemService;
        ClipData newPlainText = ClipData.newPlainText("", charSequence);
        if (clipboardManager != null) {
            clipboardManager.setPrimaryClip(newPlainText);
        }
        a(context, i, 0);
    }

    public static final void a(Context context, CharSequence charSequence, int i) {
        if (context != null) {
            Toast toast = new Toast(context);
            TextView textView = new TextView(new ContextThemeWrapper(context, 2131952270));
            textView.setText(charSequence);
            toast.setView(textView);
            toast.setDuration(i);
            toast.show();
        }
    }

    public static final void b(Context context, CharSequence charSequence) {
        a(context, charSequence, 0);
    }

    public static final void d(Context context, @StringRes int i) {
        a(context, i, 0);
    }

    public static final void b(Fragment fragment, CharSequence charSequence) {
        a(fragment, charSequence, 0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:1:0x0002, code lost:
        r0 = r1.getContext();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static /* synthetic */ void a(androidx.fragment.app.Fragment r1, int r2) {
        /*
            if (r1 == 0) goto L_0x000d
            android.content.Context r0 = r1.getContext()
            if (r0 == 0) goto L_0x000d
            java.lang.String r2 = r0.getString(r2)
            goto L_0x000e
        L_0x000d:
            r2 = 0
        L_0x000e:
            java.lang.CharSequence r2 = (java.lang.CharSequence) r2
            r0 = 0
            a((androidx.fragment.app.Fragment) r1, (java.lang.CharSequence) r2, (int) r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.discord.app.h.a(androidx.fragment.app.Fragment, int):void");
    }

    public static final void d(Context context, CharSequence charSequence) {
        b(context, charSequence, R.string.copied_text);
    }
}
