package com.discord.app;

import android.net.Uri;
import com.discord.stores.StoreStream;
import kotlin.jvm.internal.k;
import kotlin.r;

/* compiled from: AppHelpDesk.kt */
public final class e {
    public static final String um = um;
    public static final String un = un;
    public static final String uo = uo;
    public static final String uq = uq;
    public static final long ur = ur;
    public static final long us = us;
    public static final long ut = ut;
    public static final long uu = uu;
    public static final long uv = uv;
    public static final long uw = uw;
    public static final long ux = ux;
    public static final e uy = new e();

    private e() {
    }

    private static String getLocale() {
        String locale = StoreStream.Companion.getUserSettings().getLocale();
        k.g(locale, "StoreStream.getUserSettings().locale");
        if (locale != null) {
            String lowerCase = locale.toLowerCase();
            k.g(lowerCase, "(this as java.lang.String).toLowerCase()");
            return lowerCase;
        }
        throw new r("null cannot be cast to non-null type java.lang.String");
    }

    public static final String dq() {
        String str = un + "/hc/" + getLocale() + "/requests/new";
        String authToken$app_productionDiscordExternalRelease = StoreStream.Companion.getAuthentication().getAuthToken$app_productionDiscordExternalRelease();
        if (authToken$app_productionDiscordExternalRelease == null) {
            return str;
        }
        String str2 = "https://discordapp.com/api//sso?service=zendesk&token=" + authToken$app_productionDiscordExternalRelease + "&return_to=" + Uri.encode(str);
        return str2 == null ? str : str2;
    }

    public static String k(long j) {
        return un + "/hc/" + getLocale() + "/articles/" + j;
    }
}
