package com.discord.app;

import kotlin.jvm.functions.Function3;
import rx.functions.Func3;

/* compiled from: AppActivity.kt */
final class b implements Func3 {
    private final /* synthetic */ Function3 function;

    b(Function3 function3) {
        this.function = function3;
    }

    public final /* synthetic */ Object call(Object obj, Object obj2, Object obj3) {
        return this.function.invoke(obj, obj2, obj3);
    }
}
