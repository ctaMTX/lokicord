package com.discord.app;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.k;

/* compiled from: AppEventHandlerActivity.kt */
public abstract class c extends j {
    public static final a ul = new a((byte) 0);
    final TreeMap<Integer, HashMap<String, Function0<Boolean>>> uk = new TreeMap<>();

    /* compiled from: AppEventHandlerActivity.kt */
    public static final class a {
        private a() {
        }

        public /* synthetic */ a(byte b2) {
            this();
        }
    }

    public void onBackPressed() {
        boolean z;
        Collection<HashMap<String, Function0<Boolean>>> values = this.uk.values();
        k.g(values, "backPressHandlers\n        .values");
        Iterator it = values.iterator();
        loop0:
        while (true) {
            if (!it.hasNext()) {
                z = false;
                break;
            }
            Collection values2 = ((HashMap) it.next()).values();
            k.g(values2, "handlers\n              .values");
            Iterator it2 = values2.iterator();
            while (true) {
                if (it2.hasNext()) {
                    if (((Boolean) ((Function0) it2.next()).invoke()).booleanValue()) {
                        z = true;
                        break loop0;
                    }
                }
            }
        }
        if (!z && !isFinishing()) {
            try {
                super.onBackPressed();
            } catch (Exception e) {
                if (!(e instanceof IllegalArgumentException) && !(e instanceof IllegalStateException)) {
                    throw e;
                }
            }
        }
    }
}
