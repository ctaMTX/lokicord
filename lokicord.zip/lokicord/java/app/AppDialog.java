package com.discord.app;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.CallSuper;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.discord.utilities.logging.Logger;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;
import rx.subjects.PublishSubject;
import rx.subjects.Subject;

/* compiled from: AppDialog.kt */
public abstract class AppDialog extends DialogFragment implements AppComponent {
    private boolean isRecreated;
    private boolean onViewBoundOrOnResumeInvoked;
    private final Subject<Void, Void> paused;

    @LayoutRes
    public abstract int getContentViewResId();

    public final void hideKeyboard() {
        hideKeyboard$default(this, (View) null, 1, (Object) null);
    }

    @CallSuper
    public void onViewBound(View view) {
        k.h(view, "view");
    }

    @CallSuper
    public void onViewBoundOrOnResume() {
    }

    public final void showKeyboard() {
        showKeyboard$default(this, (View) null, 1, (Object) null);
    }

    public AppDialog() {
        PublishSubject LJ = PublishSubject.LJ();
        k.g(LJ, "PublishSubject.create<Void>()");
        this.paused = LJ;
    }

    public Subject<Void, Void> getPaused() {
        return this.paused;
    }

    /* access modifiers changed from: protected */
    public final boolean isRecreated() {
        return this.isRecreated;
    }

    public final AppActivity getAppActivity() {
        return (AppActivity) getActivity();
    }

    public final Bundle getArgumentsOrDefault() {
        Bundle arguments = getArguments();
        if (arguments == null) {
            arguments = new Bundle();
        }
        k.g(arguments, "arguments ?: Bundle()");
        return arguments;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        k.h(layoutInflater, "inflater");
        return layoutInflater.inflate(getContentViewResId(), viewGroup, false);
    }

    public Dialog onCreateDialog(Bundle bundle) {
        Dialog onCreateDialog = super.onCreateDialog(bundle);
        onCreateDialog.requestWindowFeature(1);
        k.g(onCreateDialog, "super.onCreateDialog(sav…FEATURE_NO_TITLE)\n      }");
        return onCreateDialog;
    }

    public void onViewCreated(View view, Bundle bundle) {
        k.h(view, "view");
        super.onViewCreated(view, bundle);
        this.isRecreated = bundle != null;
        onViewBound(view);
        onViewBoundOrOnResume();
        this.onViewBoundOrOnResumeInvoked = true;
    }

    public void show(FragmentManager fragmentManager, String str) {
        k.h(str, "tag");
        if (fragmentManager == null) {
            return;
        }
        if (!fragmentManager.isDestroyed()) {
            try {
                super.show(fragmentManager, str);
            } catch (Exception unused) {
            }
        } else {
            AppLog appLog = AppLog.uB;
            Logger.d$default(appLog, "Could not show " + fragmentManager.getClass().getName() + ": FragmentManager destroyed", (Throwable) null, 2, (Object) null);
        }
    }

    public int show(FragmentTransaction fragmentTransaction, String str) {
        k.h(fragmentTransaction, "transaction");
        k.h(str, "tag");
        try {
            return super.show(fragmentTransaction, str);
        } catch (Exception unused) {
            return -1;
        }
    }

    public void dismiss() {
        try {
            super.dismiss();
        } catch (Exception unused) {
        }
    }

    public void onPause() {
        super.onPause();
        getPaused().onNext(null);
    }

    public void onResume() {
        super.onResume();
        if (this.onViewBoundOrOnResumeInvoked) {
            this.onViewBoundOrOnResumeInvoked = false;
        } else {
            onViewBoundOrOnResume();
        }
    }

    public static /* synthetic */ void showKeyboard$default(AppDialog appDialog, View view, int i, Object obj) {
        if (obj == null) {
            if ((i & 1) != 0) {
                view = null;
            }
            appDialog.showKeyboard(view);
            return;
        }
        throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: showKeyboard");
    }

    public final void showKeyboard(View view) {
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            appActivity.showKeyboard(view);
        }
    }

    public static /* synthetic */ void hideKeyboard$default(AppDialog appDialog, View view, int i, Object obj) {
        if (obj == null) {
            if ((i & 1) != 0) {
                view = null;
            }
            appDialog.hideKeyboard(view);
            return;
        }
        throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: hideKeyboard");
    }

    public final void hideKeyboard(View view) {
        AppActivity appActivity = getAppActivity();
        if (appActivity != null) {
            appActivity.hideKeyboard(view);
        }
    }

    /* compiled from: AppDialog.kt */
    static final class a implements View.OnClickListener {
        final /* synthetic */ View ug;
        final /* synthetic */ Function1 uh;
        final /* synthetic */ AppDialog ui;

        a(AppDialog appDialog, View view, Function1 function1) {
            this.ui = appDialog;
            this.ug = view;
            this.uh = function1;
        }

        public final void onClick(View view) {
            this.uh.invoke(this.ug);
            this.ui.dismiss();
        }
    }

    /* access modifiers changed from: protected */
    public final void setOnClickAndDismissListener(View view, Function1<? super View, Unit> function1) {
        k.h(view, "$this$setOnClickAndDismissListener");
        k.h(function1, "onClickListener");
        view.setOnClickListener(new a(this, view, function1));
    }
}
