package com.discord.app;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ViewFlipper;

public class AppViewFlipper extends ViewFlipper {
    public AppViewFlipper(Context context) {
        super(context);
    }

    public AppViewFlipper(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public void setDisplayedChild(int i) {
        if (getDisplayedChild() != i) {
            super.setDisplayedChild(i);
        }
    }
}
