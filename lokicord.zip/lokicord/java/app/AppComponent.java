package com.discord.app;

import rx.subjects.Subject;

/* compiled from: AppComponent.kt */
public interface AppComponent {
    Subject<Void, Void> getPaused();
}
