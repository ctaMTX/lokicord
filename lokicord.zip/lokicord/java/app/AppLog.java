package com.discord.app;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;
import androidx.appcompat.widget.ActivityChooserView;
import androidx.core.app.NotificationCompat;
import com.discord.utilities.cache.SharedPreferenceExtensionsKt;
import com.discord.utilities.logging.Logger;
import com.discord.utilities.mg_recycler.MGRecyclerDataPayload;
import com.discord.utilities.rx.ObservableExtensionsKt;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import kotlin.Lazy;
import kotlin.Unit;
import kotlin.a.ad;
import kotlin.a.m;
import kotlin.f;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.j;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.u;
import kotlin.jvm.internal.v;
import kotlin.jvm.internal.w;
import kotlin.q;
import kotlin.reflect.KDeclarationContainer;
import kotlin.reflect.KProperty;
import rx.Observable;
import rx.subjects.SerializedSubject;

/* compiled from: AppLog.kt */
public final class AppLog extends Logger {
    private static final SerializedSubject<LoggedItem, LoggedItem> uA = new SerializedSubject<>(rx.subjects.a.LK());
    public static final AppLog uB = new AppLog();
    private static SharedPreferences uz;

    /* compiled from: AppLog.kt */
    static final class a extends l implements Function3<Integer, String, Exception, Unit> {
        final /* synthetic */ String $tag;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(String str) {
            super(3);
            this.$tag = str;
        }

        public final /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
            int intValue = ((Number) obj).intValue();
            String str = (String) obj2;
            Exception exc = (Exception) obj3;
            k.h(str, "message");
            if (intValue == 4) {
                AppLog appLog = AppLog.uB;
                appLog.i(this.$tag + ' ' + str, exc);
            } else if (intValue == 5) {
                AppLog appLog2 = AppLog.uB;
                appLog2.w(this.$tag + ' ' + str, exc);
            } else if (intValue == 6 || intValue == 7) {
                AppLog appLog3 = AppLog.uB;
                Logger.e$default(appLog3, this.$tag + ' ' + str, exc, (Map) null, 4, (Object) null);
            }
            return Unit.bjE;
        }
    }

    /* compiled from: AppLog.kt */
    static final class b extends l implements Function2<String, Integer, Unit> {
        final /* synthetic */ int $priority;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        b(int i) {
            super(2);
            this.$priority = i;
        }

        public final /* synthetic */ Object invoke(Object obj, Object obj2) {
            invoke((String) obj, ((Number) obj2).intValue());
            return Unit.bjE;
        }

        public final void invoke(String str, int i) {
            k.h(str, NotificationCompat.CATEGORY_MESSAGE);
            for (String println : kotlin.text.l.b(str, i)) {
                Log.println(this.$priority, AppLog.uB.getDefaultTag(), println);
            }
        }
    }

    /* compiled from: AppLog.kt */
    static final /* synthetic */ class c extends j implements Function2<String, Throwable, Unit> {
        c(AppLog appLog) {
            super(2, appLog);
        }

        public final String getName() {
            return "v";
        }

        public final KDeclarationContainer getOwner() {
            return w.Q(AppLog.class);
        }

        public final String getSignature() {
            return "v(Ljava/lang/String;Ljava/lang/Throwable;)V";
        }

        public final /* synthetic */ Object invoke(Object obj, Object obj2) {
            String str = (String) obj;
            k.h(str, "p1");
            ((AppLog) this.receiver).v(str, (Throwable) obj2);
            return Unit.bjE;
        }
    }

    /* compiled from: AppLog.kt */
    static final class d extends l implements Function1<SharedPreferences.Editor, Unit> {
        final /* synthetic */ String $userEmail;
        final /* synthetic */ Long $userId;
        final /* synthetic */ String $username;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        d(Long l, String str, String str2) {
            super(1);
            this.$userId = l;
            this.$userEmail = str;
            this.$username = str2;
        }

        public final /* synthetic */ Object invoke(Object obj) {
            SharedPreferences.Editor editor = (SharedPreferences.Editor) obj;
            k.h(editor, "it");
            Long l = this.$userId;
            if (l != null) {
                l.longValue();
                editor.putString("LOG_CACHE_KEY_USER_ID", String.valueOf(this.$userId));
            }
            String str = this.$userEmail;
            if (str != null) {
                editor.putString("LOG_CACHE_KEY_USER_EMAIL", str);
            }
            String str2 = this.$username;
            if (str2 != null) {
                editor.putString("LOG_CACHE_KEY_USER_NAME", str2);
            }
            return Unit.bjE;
        }
    }

    private AppLog() {
        super("Discord");
    }

    public static final Observable<LoggedItem> dr() {
        Observable<LoggedItem> Kb = ObservableExtensionsKt.computationBuffered(uA).Kb();
        k.g(Kb, "logsSubject\n          .c…  .distinctUntilChanged()");
        return Kb;
    }

    public static Function3<Integer, String, Exception, Unit> ab(String str) {
        k.h(str, "tag");
        return new a(str);
    }

    public static final void init(Application application) {
        k.h(application, "application");
        Context context = application;
        uz = PreferenceManager.getDefaultSharedPreferences(context);
        io.fabric.sdk.android.c.a(context, new com.crashlytics.android.a(), new com.crashlytics.android.ndk.c());
    }

    public final void w(String str, Throwable th) {
        k.h(str, "message");
        a(str, 5, th, (Map<String, String>) null);
    }

    public final void w(String str, String str2, Throwable th) {
        k.h(str, "tag");
        k.h(str2, "message");
        w(str + " -> " + str2, th);
    }

    public final void i(String str, Throwable th) {
        k.h(str, "message");
        a(str, 4, th, (Map<String, String>) null);
    }

    public final void i(String str, String str2, Throwable th) {
        k.h(str, "tag");
        k.h(str2, "message");
        i(str + " -> " + str2, th);
    }

    public static final void i(String str) {
        k.h(str, "message");
        uB.i(str, (Throwable) null);
    }

    public final void d(String str, Throwable th) {
        k.h(str, "message");
        a(str, 3, th, (Map<String, String>) null);
    }

    public final void d(String str, String str2, Throwable th) {
        k.h(str, "tag");
        k.h(str2, "message");
        d(str + " -> " + str2, th);
    }

    public final void v(String str, Throwable th) {
        k.h(str, "message");
        a(str, 2, th, (Map<String, String>) null);
    }

    public final void a(String str, Throwable th, Map<String, String> map) {
        k.h(str, "message");
        a(str, 6, th, map);
    }

    public final void e(String str, Throwable th, Map<String, String> map) {
        k.h(str, "message");
        a(str, th, map);
    }

    public final void e(String str, String str2, Throwable th, Map<String, String> map) {
        k.h(str, "tag");
        k.h(str2, "message");
        e(str + " -> " + str2, th, map);
    }

    public static final void a(Long l, String str, String str2) {
        String str3;
        SharedPreferences sharedPreferences = uz;
        if (sharedPreferences != null) {
            SharedPreferenceExtensionsKt.edit(sharedPreferences, new d(l, str, str2));
        }
        com.crashlytics.android.a.C(str);
        com.crashlytics.android.a.B(str2);
        if (l == null || (str3 = String.valueOf(l.longValue())) == null) {
            str3 = "";
        }
        com.crashlytics.android.a.A(str3);
    }

    public static void a(String str, String str2, Throwable th, Function2<? super String, ? super Throwable, Unit> function2) {
        k.h(str, "category");
        k.h(str2, "message");
        k.h(function2, "loggingFn");
        String str3 = "[" + str + "]: " + str2;
        function2.invoke("Breadcrumb".concat(String.valueOf(str3)), th);
        com.crashlytics.android.a.log(str3);
    }

    public static final void n(String str, String str2) {
        k.h(str, "from");
        k.h(str2, "to");
        AppLog appLog = uB;
        appLog.recordBreadcrumb("Navigation [" + str + "] > [" + str2 + ']', NotificationCompat.CATEGORY_NAVIGATION, ad.a(q.m("from", str), q.m("to", str2)));
    }

    public final void recordBreadcrumb(String str, String str2, Map<String, String> map) {
        k.h(str, "message");
        k.h(str2, "category");
        a(str2, str, (Throwable) null, (Function2<? super String, ? super Throwable, Unit>) new c(this));
    }

    /* access modifiers changed from: private */
    public final void a(String str, int i, Throwable th, Map<String, String> map) {
        Set<Map.Entry<String, String>> entrySet;
        String a2;
        uA.onNext(new LoggedItem(i, str, th));
        if (i == 6) {
            try {
                com.crashlytics.android.a.log("Exception Message: ".concat(String.valueOf(str)));
                if (map != null && (!map.isEmpty())) {
                    com.crashlytics.android.a.log("Metadata:\n" + m.a((Iterable) map.entrySet(), (CharSequence) "\n", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (Function1) null, 62));
                }
                com.crashlytics.android.a.b(th);
            } catch (Exception e) {
                i("Unable to notify error logging.", e);
            }
        } else {
            b bVar = new b(i);
            bVar.invoke(str, 1000);
            if (!(map == null || (entrySet = map.entrySet()) == null || (a2 = m.a((Iterable) entrySet, (CharSequence) "\n\t", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (Function1) null, 62)) == null)) {
                bVar.invoke("Metadata: ".concat(String.valueOf(a2)), (int) ActivityChooserView.ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED);
            }
            String stackTraceString = Log.getStackTraceString(th);
            k.g(stackTraceString, "Log.getStackTraceString(throwable)");
            bVar.invoke(stackTraceString, 1000);
        }
    }

    /* compiled from: AppLog.kt */
    public static final class LoggedItem implements MGRecyclerDataPayload {
        private final String key;
        public final String message;
        public final int priority;
        public final Throwable throwable;

        public final boolean equals(Object obj) {
            if (this != obj) {
                if (obj instanceof LoggedItem) {
                    LoggedItem loggedItem = (LoggedItem) obj;
                    if (!(this.priority == loggedItem.priority) || !k.n(this.message, loggedItem.message) || !k.n(this.throwable, loggedItem.throwable)) {
                        return false;
                    }
                }
                return false;
            }
            return true;
        }

        public final int getType() {
            return 0;
        }

        public final int hashCode() {
            int i = this.priority * 31;
            String str = this.message;
            int i2 = 0;
            int hashCode = (i + (str != null ? str.hashCode() : 0)) * 31;
            Throwable th = this.throwable;
            if (th != null) {
                i2 = th.hashCode();
            }
            return hashCode + i2;
        }

        public final String toString() {
            return "LoggedItem(priority=" + this.priority + ", message=" + this.message + ", throwable=" + this.throwable + ")";
        }

        public LoggedItem(int i, String str, Throwable th) {
            k.h(str, "message");
            this.priority = i;
            this.message = str;
            this.throwable = th;
            String uuid = UUID.randomUUID().toString();
            k.g(uuid, "UUID.randomUUID().toString()");
            this.key = uuid;
        }

        public final String getKey() {
            return this.key;
        }
    }

    /* compiled from: AppLog.kt */
    public static final class Elapsed {
        static final /* synthetic */ KProperty[] $$delegatedProperties = {w.a((u) new v(w.Q(Elapsed.class), "milliseconds", "getMilliseconds()J")), w.a((u) new v(w.Q(Elapsed.class), "seconds", "getSeconds()F"))};
        /* access modifiers changed from: private */
        public final long startTime = System.currentTimeMillis();
        private final Lazy uC = f.b(new a(this));
        private final Lazy uD = f.b(new b(this));

        public final long ds() {
            return ((Number) this.uC.getValue()).longValue();
        }

        public final float dt() {
            return ((Number) this.uD.getValue()).floatValue();
        }

        /* compiled from: AppLog.kt */
        static final class a extends l implements Function0<Long> {
            final /* synthetic */ Elapsed this$0;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            a(Elapsed elapsed) {
                super(0);
                this.this$0 = elapsed;
            }

            public final /* synthetic */ Object invoke() {
                return Long.valueOf(System.currentTimeMillis() - this.this$0.startTime);
            }
        }

        /* compiled from: AppLog.kt */
        static final class b extends l implements Function0<Float> {
            final /* synthetic */ Elapsed this$0;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            b(Elapsed elapsed) {
                super(0);
                this.this$0 = elapsed;
            }

            public final /* synthetic */ Object invoke() {
                return Float.valueOf(((float) this.this$0.ds()) / 1000.0f);
            }
        }
    }
}
