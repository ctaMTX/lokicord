package com.discord.app;

import com.miguelgaeta.media_picker.RequestType;

public final /* synthetic */ class d {
    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

    static {
        int[] iArr = new int[RequestType.values().length];
        $EnumSwitchMapping$0 = iArr;
        iArr[RequestType.CROP.ordinal()] = 1;
    }
}
