package com.discord.app;

import android.app.Application;
import android.content.Context;
import android.view.View;
import androidx.multidex.MultiDex;
import com.discord.BuildConfig;
import com.discord.models.domain.emoji.ModelEmojiCustom;
import com.discord.utilities.analytics.AdjustConfig;
import com.discord.utilities.error.Error;
import com.discord.utilities.fcm.NotificationClient;
import com.discord.utilities.images.MGImagesConfig;
import com.discord.utilities.logging.Logger;
import com.discord.utilities.persister.PersisterConfig;
import com.discord.utilities.rest.RestAPI;
import com.discord.utilities.rest.RestAPIAbortMessages;
import com.discord.utilities.rx.ObservableExtensionsKt;
import com.discord.utilities.ssl.SecureSocketsLayerUtils;
import com.discord.utilities.surveys.SurveyUtils;
import com.discord.utilities.uri.UriHandler;
import com.discord.utilities.view.text.LinkifiedTextView;
import com.miguelgaeta.backgrounded.Backgrounded;
import java.util.Map;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.j;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.w;
import kotlin.reflect.KDeclarationContainer;
import kotlin.text.l;
import rx.Observable;
import rx.functions.Action1;

/* compiled from: App.kt */
public class App extends Application {
    /* access modifiers changed from: private */
    public static final boolean tJ = l.a((CharSequence) BuildConfig.FLAVOR, (CharSequence) "local", false);
    public static final a tK = new a((byte) 0);
    private final boolean tI;

    /* compiled from: App.kt */
    static final class b<T> implements Action1<Boolean> {
        public static final b tL = new b();

        b() {
        }

        public final /* synthetic */ void call(Object obj) {
            Logger.recordBreadcrumb$default(AppLog.uB, "Backgrounded=".concat(String.valueOf((Boolean) obj)), "App State", (Map) null, 4, (Object) null);
        }
    }

    /* compiled from: App.kt */
    static final /* synthetic */ class c extends j implements Function4<String, Throwable, Map<String, ? extends String>, Map<String, ? extends String>, Unit> {
        c(AppLog appLog) {
            super(4, appLog);
        }

        public final String getName() {
            return "e";
        }

        public final KDeclarationContainer getOwner() {
            return w.Q(AppLog.class);
        }

        public final String getSignature() {
            return "e(Ljava/lang/String;Ljava/lang/Throwable;Ljava/util/Map;Ljava/util/Map;)V";
        }

        public final /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
            String str = (String) obj;
            k.h(str, "p1");
            ((AppLog) this.receiver).a(str, (Throwable) obj2, (Map<String, String>) (Map) obj3);
            return Unit.bjE;
        }
    }

    /* compiled from: App.kt */
    static final class d extends kotlin.jvm.internal.l implements Function2<View, String, Unit> {
        public static final d tM = new d();

        d() {
            super(2);
        }

        public final /* synthetic */ Object invoke(Object obj, Object obj2) {
            View view = (View) obj;
            String str = (String) obj2;
            k.h(view, "textView");
            k.h(str, "url");
            Context context = view.getContext();
            k.g(context, "textView.context");
            UriHandler.handle$default(context, str, (Function0) null, 4, (Object) null);
            return Unit.bjE;
        }
    }

    public void onCreate() {
        super.onCreate();
        Application application = this;
        AppLog.init(application);
        AdjustConfig.INSTANCE.init(application, this.tI);
        Backgrounded.init(application);
        Context context = this;
        PersisterConfig.INSTANCE.init(context);
        Observable<Boolean> observable = Backgrounded.get();
        k.g(observable, "Backgrounded\n        .get()");
        ObservableExtensionsKt.computationBuffered(observable).Kb().b(b.tL);
        SecureSocketsLayerUtils.INSTANCE.init(application);
        RestAPI.Companion.init(context);
        NotificationClient.INSTANCE.init(application);
        MGImagesConfig.INSTANCE.init(application);
        Error.init(new a(new c(AppLog.uB)), RestAPIAbortMessages.INSTANCE.getMESSAGES());
        LinkifiedTextView.Companion.init(d.tM);
        ModelEmojiCustom.setCdnUri(BuildConfig.HOST_CDN);
        SurveyUtils.INSTANCE.init(application);
        AppLog.i("Application initialized.");
    }

    public void onTrimMemory(int i) {
        super.onTrimMemory(i);
        MGImagesConfig.INSTANCE.onTrimMemory(i);
    }

    /* access modifiers changed from: protected */
    public void attachBaseContext(Context context) {
        k.h(context, "base");
        super.attachBaseContext(context);
        if (!this.tI) {
            MultiDex.install(this);
        }
    }

    /* compiled from: App.kt */
    public static final class a {
        private a() {
        }

        public /* synthetic */ a(byte b2) {
            this();
        }
    }
}
