package com.discord.app_models;

public final class R {
    private R() {
    }
}
