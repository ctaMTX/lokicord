package kotlin;

/* compiled from: Lazy.kt */
public enum j {
    SYNCHRONIZED,
    PUBLICATION,
    NONE
}
