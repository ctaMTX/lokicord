package kotlin.jvm;

import kotlin.jvm.internal.d;
import kotlin.jvm.internal.k;
import kotlin.r;
import kotlin.reflect.b;

/* compiled from: JvmClassMapping.kt */
public final class a {
    public static final <T> Class<T> b(b<T> bVar) {
        k.h(bVar, "$this$java");
        Class<?> Ej = ((d) bVar).Ej();
        if (Ej != null) {
            return Ej;
        }
        throw new r("null cannot be cast to non-null type java.lang.Class<T>");
    }

    public static final <T> Class<T> c(b<T> bVar) {
        k.h(bVar, "$this$javaObjectType");
        Class Ej = ((d) bVar).Ej();
        if (Ej.isPrimitive()) {
            String name = Ej.getName();
            if (name != null) {
                switch (name.hashCode()) {
                    case -1325958191:
                        if (name.equals("double")) {
                            Ej = Double.class;
                            break;
                        }
                        break;
                    case 104431:
                        if (name.equals("int")) {
                            Ej = Integer.class;
                            break;
                        }
                        break;
                    case 3039496:
                        if (name.equals("byte")) {
                            Ej = Byte.class;
                            break;
                        }
                        break;
                    case 3052374:
                        if (name.equals("char")) {
                            Ej = Character.class;
                            break;
                        }
                        break;
                    case 3327612:
                        if (name.equals("long")) {
                            Ej = Long.class;
                            break;
                        }
                        break;
                    case 3625364:
                        if (name.equals("void")) {
                            Ej = Void.class;
                            break;
                        }
                        break;
                    case 64711720:
                        if (name.equals("boolean")) {
                            Ej = Boolean.class;
                            break;
                        }
                        break;
                    case 97526364:
                        if (name.equals("float")) {
                            Ej = Float.class;
                            break;
                        }
                        break;
                    case 109413500:
                        if (name.equals("short")) {
                            Ej = Short.class;
                            break;
                        }
                        break;
                }
            }
            if (Ej != null) {
                return Ej;
            }
            throw new r("null cannot be cast to non-null type java.lang.Class<T>");
        } else if (Ej != null) {
            return Ej;
        } else {
            throw new r("null cannot be cast to non-null type java.lang.Class<T>");
        }
    }
}
