package kotlin.jvm.internal;

import kotlin.reflect.KCallable;
import kotlin.reflect.d;

/* compiled from: PropertyReference1 */
public abstract class u extends r implements d {
    /* access modifiers changed from: protected */
    public KCallable computeReflected() {
        return w.a(this);
    }

    public Object invoke(Object obj) {
        return get(obj);
    }

    public final d.a Eq() {
        return ((d) getReflected()).Eq();
    }
}
