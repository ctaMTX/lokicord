package kotlin.jvm.internal;

/* compiled from: PrimitiveCompanionObjects.kt */
public final class h {
    private static final float MAX_VALUE = Float.MAX_VALUE;
    private static final float MIN_VALUE = MIN_VALUE;
    private static final float NEGATIVE_INFINITY = NEGATIVE_INFINITY;
    private static final float NaN = NaN;
    private static final float POSITIVE_INFINITY = POSITIVE_INFINITY;
    public static final h bkC = new h();

    private h() {
    }

    public static float El() {
        return MAX_VALUE;
    }
}
