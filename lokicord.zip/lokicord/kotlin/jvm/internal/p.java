package kotlin.jvm.internal;

import kotlin.reflect.KDeclarationContainer;

/* compiled from: MutablePropertyReference1Impl */
public final class p extends o {
    private final String name;
    private final KDeclarationContainer owner;
    private final String signature;

    public p(KDeclarationContainer kDeclarationContainer, String str, String str2) {
        this.owner = kDeclarationContainer;
        this.name = str;
        this.signature = str2;
    }

    public final KDeclarationContainer getOwner() {
        return this.owner;
    }

    public final String getName() {
        return this.name;
    }

    public final String getSignature() {
        return this.signature;
    }

    public final Object get(Object obj) {
        return Eq().call(obj);
    }
}
