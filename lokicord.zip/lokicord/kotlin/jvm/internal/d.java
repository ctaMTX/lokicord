package kotlin.jvm.internal;

import kotlin.reflect.KDeclarationContainer;

/* compiled from: ClassBasedDeclarationContainer.kt */
public interface d extends KDeclarationContainer {
    Class<?> Ej();
}
