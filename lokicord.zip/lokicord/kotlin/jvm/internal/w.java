package kotlin.jvm.internal;

import kotlin.reflect.KDeclarationContainer;
import kotlin.reflect.KFunction;
import kotlin.reflect.KMutableProperty0;
import kotlin.reflect.KProperty0;
import kotlin.reflect.b;
import kotlin.reflect.c;
import kotlin.reflect.d;

/* compiled from: Reflection */
public final class w {
    private static final x bkE;
    private static final b[] bkF = new b[0];

    public static KFunction a(j jVar) {
        return jVar;
    }

    public static KMutableProperty0 a(n nVar) {
        return nVar;
    }

    public static KProperty0 a(s sVar) {
        return sVar;
    }

    public static c a(o oVar) {
        return oVar;
    }

    public static d a(u uVar) {
        return uVar;
    }

    static {
        x xVar = null;
        try {
            xVar = (x) Class.forName("kotlin.reflect.jvm.internal.ReflectionFactoryImpl").newInstance();
        } catch (ClassCastException | ClassNotFoundException | IllegalAccessException | InstantiationException unused) {
        }
        if (xVar == null) {
            xVar = new x();
        }
        bkE = xVar;
    }

    public static String a(i iVar) {
        return x.a(iVar);
    }

    public static KDeclarationContainer f(Class cls, String str) {
        return new q(cls, str);
    }

    public static b Q(Class cls) {
        return new e(cls);
    }

    public static String a(l lVar) {
        return x.a(lVar);
    }
}
