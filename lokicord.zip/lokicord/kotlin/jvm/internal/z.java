package kotlin.jvm.internal;

/* compiled from: PrimitiveCompanionObjects.kt */
public final class z {
    public static final z bkH = new z();

    private z() {
    }
}
