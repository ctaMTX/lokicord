package kotlin.jvm.internal;

/* compiled from: PrimitiveCompanionObjects.kt */
public final class g {
    private static final double MAX_VALUE = MAX_VALUE;
    private static final double MIN_VALUE = MIN_VALUE;
    private static final double NEGATIVE_INFINITY = NEGATIVE_INFINITY;
    private static final double NaN = NaN;
    private static final double POSITIVE_INFINITY = POSITIVE_INFINITY;
    public static final g bkB = new g();

    private g() {
    }

    public static double Ek() {
        return NaN;
    }
}
