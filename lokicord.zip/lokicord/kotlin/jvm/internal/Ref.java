package kotlin.jvm.internal;

import java.io.Serializable;

public final class Ref {

    public static final class ObjectRef<T> implements Serializable {
        public T element;

        public final String toString() {
            return String.valueOf(this.element);
        }
    }

    public static final class IntRef implements Serializable {
        public int element;

        public final String toString() {
            return String.valueOf(this.element);
        }
    }

    public static final class LongRef implements Serializable {
        public long element;

        public final String toString() {
            return String.valueOf(this.element);
        }
    }
}
