package kotlin.jvm.internal;

import java.io.Serializable;

/* compiled from: Lambda.kt */
public abstract class l<R> implements Serializable, i<R> {
    private final int arity;

    public l(int i) {
        this.arity = i;
    }

    public int getArity() {
        return this.arity;
    }

    public String toString() {
        String a2 = w.a(this);
        k.g(a2, "Reflection.renderLambdaToString(this)");
        return a2;
    }
}
