package kotlin.jvm.internal;

import java.util.Collection;
import java.util.Map;
import kotlin.jvm.internal.a.a;
import kotlin.jvm.internal.a.b;
import kotlin.jvm.internal.a.c;
import kotlin.jvm.internal.a.g;

/* compiled from: TypeIntrinsics */
public class aa {
    private static <T extends Throwable> T p(T t) {
        return k.a(t, aa.class.getName());
    }

    private static void i(Object obj, String str) {
        String name = obj == null ? "null" : obj.getClass().getName();
        throw ((ClassCastException) p(new ClassCastException(name + " cannot be cast to " + str)));
    }

    public static Iterable bc(Object obj) {
        if ((obj instanceof a) && !(obj instanceof c)) {
            i(obj, "kotlin.collections.MutableIterable");
        }
        return bd(obj);
    }

    private static Iterable bd(Object obj) {
        try {
            return (Iterable) obj;
        } catch (ClassCastException e) {
            throw ((ClassCastException) p(e));
        }
    }

    public static Collection be(Object obj) {
        if ((obj instanceof a) && !(obj instanceof b)) {
            i(obj, "kotlin.collections.MutableCollection");
        }
        return bf(obj);
    }

    private static Collection bf(Object obj) {
        try {
            return (Collection) obj;
        } catch (ClassCastException e) {
            throw ((ClassCastException) p(e));
        }
    }

    public static Map bg(Object obj) {
        if ((obj instanceof a) && !(obj instanceof g)) {
            i(obj, "kotlin.collections.MutableMap");
        }
        return bh(obj);
    }

    private static Map bh(Object obj) {
        try {
            return (Map) obj;
        } catch (ClassCastException e) {
            throw ((ClassCastException) p(e));
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:76:0x00ba, code lost:
        if (r0 == 2) goto L_0x00be;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Object bi(java.lang.Object r4) {
        /*
            if (r4 == 0) goto L_0x00ce
            boolean r0 = r4 instanceof kotlin.c
            r1 = 1
            r2 = 0
            if (r0 == 0) goto L_0x00bd
            boolean r0 = r4 instanceof kotlin.jvm.internal.i
            r3 = 2
            if (r0 == 0) goto L_0x0016
            r0 = r4
            kotlin.jvm.internal.i r0 = (kotlin.jvm.internal.i) r0
            int r0 = r0.getArity()
            goto L_0x00ba
        L_0x0016:
            boolean r0 = r4 instanceof kotlin.jvm.functions.Function0
            if (r0 == 0) goto L_0x001d
            r0 = 0
            goto L_0x00ba
        L_0x001d:
            boolean r0 = r4 instanceof kotlin.jvm.functions.Function1
            if (r0 == 0) goto L_0x0024
            r0 = 1
            goto L_0x00ba
        L_0x0024:
            boolean r0 = r4 instanceof kotlin.jvm.functions.Function2
            if (r0 == 0) goto L_0x002b
            r0 = 2
            goto L_0x00ba
        L_0x002b:
            boolean r0 = r4 instanceof kotlin.jvm.functions.Function3
            if (r0 == 0) goto L_0x0032
            r0 = 3
            goto L_0x00ba
        L_0x0032:
            boolean r0 = r4 instanceof kotlin.jvm.functions.Function4
            if (r0 == 0) goto L_0x0039
            r0 = 4
            goto L_0x00ba
        L_0x0039:
            boolean r0 = r4 instanceof kotlin.jvm.functions.Function5
            if (r0 == 0) goto L_0x0040
            r0 = 5
            goto L_0x00ba
        L_0x0040:
            boolean r0 = r4 instanceof kotlin.jvm.functions.Function6
            if (r0 == 0) goto L_0x0047
            r0 = 6
            goto L_0x00ba
        L_0x0047:
            boolean r0 = r4 instanceof kotlin.jvm.functions.Function7
            if (r0 == 0) goto L_0x004e
            r0 = 7
            goto L_0x00ba
        L_0x004e:
            boolean r0 = r4 instanceof kotlin.jvm.functions.n
            if (r0 == 0) goto L_0x0056
            r0 = 8
            goto L_0x00ba
        L_0x0056:
            boolean r0 = r4 instanceof kotlin.jvm.functions.Function9
            if (r0 == 0) goto L_0x005e
            r0 = 9
            goto L_0x00ba
        L_0x005e:
            boolean r0 = r4 instanceof kotlin.jvm.functions.a
            if (r0 == 0) goto L_0x0065
            r0 = 10
            goto L_0x00ba
        L_0x0065:
            boolean r0 = r4 instanceof kotlin.jvm.functions.b
            if (r0 == 0) goto L_0x006c
            r0 = 11
            goto L_0x00ba
        L_0x006c:
            boolean r0 = r4 instanceof kotlin.jvm.functions.c
            if (r0 == 0) goto L_0x0073
            r0 = 12
            goto L_0x00ba
        L_0x0073:
            boolean r0 = r4 instanceof kotlin.jvm.functions.d
            if (r0 == 0) goto L_0x007a
            r0 = 13
            goto L_0x00ba
        L_0x007a:
            boolean r0 = r4 instanceof kotlin.jvm.functions.e
            if (r0 == 0) goto L_0x0081
            r0 = 14
            goto L_0x00ba
        L_0x0081:
            boolean r0 = r4 instanceof kotlin.jvm.functions.f
            if (r0 == 0) goto L_0x0088
            r0 = 15
            goto L_0x00ba
        L_0x0088:
            boolean r0 = r4 instanceof kotlin.jvm.functions.g
            if (r0 == 0) goto L_0x008f
            r0 = 16
            goto L_0x00ba
        L_0x008f:
            boolean r0 = r4 instanceof kotlin.jvm.functions.h
            if (r0 == 0) goto L_0x0096
            r0 = 17
            goto L_0x00ba
        L_0x0096:
            boolean r0 = r4 instanceof kotlin.jvm.functions.i
            if (r0 == 0) goto L_0x009d
            r0 = 18
            goto L_0x00ba
        L_0x009d:
            boolean r0 = r4 instanceof kotlin.jvm.functions.j
            if (r0 == 0) goto L_0x00a4
            r0 = 19
            goto L_0x00ba
        L_0x00a4:
            boolean r0 = r4 instanceof kotlin.jvm.functions.k
            if (r0 == 0) goto L_0x00ab
            r0 = 20
            goto L_0x00ba
        L_0x00ab:
            boolean r0 = r4 instanceof kotlin.jvm.functions.l
            if (r0 == 0) goto L_0x00b2
            r0 = 21
            goto L_0x00ba
        L_0x00b2:
            boolean r0 = r4 instanceof kotlin.jvm.functions.m
            if (r0 == 0) goto L_0x00b9
            r0 = 22
            goto L_0x00ba
        L_0x00b9:
            r0 = -1
        L_0x00ba:
            if (r0 != r3) goto L_0x00bd
            goto L_0x00be
        L_0x00bd:
            r1 = 0
        L_0x00be:
            if (r1 != 0) goto L_0x00ce
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "kotlin.jvm.functions.Function2"
            r0.<init>(r1)
            java.lang.String r0 = r0.toString()
            i(r4, r0)
        L_0x00ce:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlin.jvm.internal.aa.bi(java.lang.Object):java.lang.Object");
    }
}
