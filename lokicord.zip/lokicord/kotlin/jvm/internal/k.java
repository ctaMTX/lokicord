package kotlin.jvm.internal;

import java.util.Arrays;
import kotlin.e;
import kotlin.t;

/* compiled from: Intrinsics */
public class k {
    public static int compare(int i, int i2) {
        if (i < i2) {
            return -1;
        }
        return i == i2 ? 0 : 1;
    }

    private k() {
    }

    public static String s(String str, Object obj) {
        return str + obj;
    }

    public static void Em() {
        throw ((e) p(new e()));
    }

    public static void dT(String str) {
        throw ((t) p(new t("lateinit property " + str + " has not been initialized")));
    }

    public static void g(Object obj, String str) {
        if (obj == null) {
            throw ((IllegalStateException) p(new IllegalStateException(str + " must not be null")));
        }
    }

    public static boolean n(Object obj, Object obj2) {
        if (obj == null) {
            return obj2 == null;
        }
        return obj.equals(obj2);
    }

    public static void Eo() {
        En();
    }

    public static void Ep() {
        En();
    }

    private static <T extends Throwable> T p(T t) {
        return a(t, k.class.getName());
    }

    static <T extends Throwable> T a(T t, String str) {
        StackTraceElement[] stackTrace = t.getStackTrace();
        int length = stackTrace.length;
        int i = -1;
        for (int i2 = 0; i2 < length; i2++) {
            if (str.equals(stackTrace[i2].getClassName())) {
                i = i2;
            }
        }
        t.setStackTrace((StackTraceElement[]) Arrays.copyOfRange(stackTrace, i + 1, length));
        return t;
    }

    public static void h(Object obj, String str) {
        if (obj == null) {
            StackTraceElement stackTraceElement = Thread.currentThread().getStackTrace()[3];
            String className = stackTraceElement.getClassName();
            String methodName = stackTraceElement.getMethodName();
            throw ((IllegalArgumentException) p(new IllegalArgumentException("Parameter specified as non-null is null: method " + className + "." + methodName + ", parameter " + str)));
        }
    }

    private static void En() {
        throw new UnsupportedOperationException("This function has a reified type parameter and thus can only be inlined at compilation time, not called directly.");
    }
}
