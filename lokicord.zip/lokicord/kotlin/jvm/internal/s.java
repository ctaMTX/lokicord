package kotlin.jvm.internal;

import kotlin.reflect.KCallable;
import kotlin.reflect.KProperty0;

/* compiled from: PropertyReference0 */
public abstract class s extends r implements KProperty0 {
    /* access modifiers changed from: protected */
    public KCallable computeReflected() {
        return w.a(this);
    }

    public Object invoke() {
        return get();
    }

    public KProperty0.Getter getGetter() {
        return ((KProperty0) getReflected()).getGetter();
    }

    public Object getDelegate() {
        return ((KProperty0) getReflected()).getDelegate();
    }
}
