package kotlin.jvm.internal;

import kotlin.reflect.KCallable;
import kotlin.reflect.c;
import kotlin.reflect.d;

/* compiled from: MutablePropertyReference1 */
public abstract class o extends m implements c {
    /* access modifiers changed from: protected */
    public KCallable computeReflected() {
        return w.a(this);
    }

    public Object invoke(Object obj) {
        return get(obj);
    }

    public final d.a Eq() {
        return ((c) getReflected()).Eq();
    }
}
