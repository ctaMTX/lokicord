package kotlin.jvm.internal;

import kotlin.c;

/* compiled from: FunctionBase.kt */
public interface i<R> extends c<R> {
    int getArity();
}
