package kotlin.jvm.internal;

import java.lang.annotation.Annotation;
import java.util.List;
import kotlin.jvm.a;
import kotlin.reflect.b;

/* compiled from: ClassReference.kt */
public final class e implements d, b<Object> {
    private final Class<?> bkz;

    public e(Class<?> cls) {
        k.h(cls, "jClass");
        this.bkz = cls;
    }

    public final Class<?> Ej() {
        return this.bkz;
    }

    public final boolean equals(Object obj) {
        return (obj instanceof e) && k.n(a.c(this), a.c((b) obj));
    }

    public final int hashCode() {
        return a.c(this).hashCode();
    }

    public final String toString() {
        return this.bkz.toString() + " (Kotlin reflection is not available)";
    }

    public final List<Annotation> getAnnotations() {
        throw new kotlin.jvm.b();
    }
}
