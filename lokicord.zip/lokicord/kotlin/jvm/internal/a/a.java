package kotlin.jvm.internal.a;

/* compiled from: KMarkers.kt */
public interface a {
}
