package kotlin.jvm.internal.a;

/* compiled from: KMarkers.kt */
public interface b extends c {
}
