package kotlin.jvm.internal.a;

public interface h extends b {
}
