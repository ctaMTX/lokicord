package kotlin.jvm.internal.a;

/* compiled from: KMarkers.kt */
public interface g extends a {
}
