package kotlin.jvm.internal.a;

public interface f extends d {
}
