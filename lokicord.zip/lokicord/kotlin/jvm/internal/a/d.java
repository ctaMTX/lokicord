package kotlin.jvm.internal.a;

public interface d extends a {
}
