package kotlin.jvm.internal.a;

public interface e extends b {
}
