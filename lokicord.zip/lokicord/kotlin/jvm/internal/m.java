package kotlin.jvm.internal;

import kotlin.reflect.KMutableProperty;

/* compiled from: MutablePropertyReference */
public abstract class m extends r implements KMutableProperty {
    public m() {
    }

    public m(Object obj) {
        super(obj);
    }
}
