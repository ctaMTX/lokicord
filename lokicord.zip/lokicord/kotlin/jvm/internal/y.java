package kotlin.jvm.internal;

import java.util.ArrayList;

/* compiled from: SpreadBuilder */
public final class y {
    public final ArrayList<Object> bkG = new ArrayList<>(2);
}
