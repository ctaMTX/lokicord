package kotlin.jvm.internal;

import kotlin.reflect.KDeclarationContainer;

/* compiled from: PropertyReference0Impl */
public final class t extends s {
    private final String name;
    private final KDeclarationContainer owner;
    private final String signature;

    public t(KDeclarationContainer kDeclarationContainer, String str, String str2) {
        this.owner = kDeclarationContainer;
        this.name = str;
        this.signature = str2;
    }

    public final KDeclarationContainer getOwner() {
        return this.owner;
    }

    public final String getName() {
        return this.name;
    }

    public final String getSignature() {
        return this.signature;
    }

    public final Object get() {
        return getGetter().call(new Object[0]);
    }
}
