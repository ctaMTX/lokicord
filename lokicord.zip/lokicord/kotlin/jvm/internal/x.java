package kotlin.jvm.internal;

/* compiled from: ReflectionFactory */
public final class x {
    public static String a(i iVar) {
        String obj = iVar.getClass().getGenericInterfaces()[0].toString();
        return obj.startsWith("kotlin.jvm.functions.") ? obj.substring(21) : obj;
    }
}
