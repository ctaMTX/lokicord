package kotlin.jvm.internal;

/* compiled from: PackageReference.kt */
public final class q implements d {
    private final String bkD;
    private final Class<?> bkz;

    public q(Class<?> cls, String str) {
        k.h(cls, "jClass");
        k.h(str, "moduleName");
        this.bkz = cls;
        this.bkD = str;
    }

    public final Class<?> Ej() {
        return this.bkz;
    }

    public final boolean equals(Object obj) {
        return (obj instanceof q) && k.n(this.bkz, ((q) obj).bkz);
    }

    public final String toString() {
        return this.bkz.toString() + " (Kotlin reflection is not available)";
    }

    public final int hashCode() {
        return this.bkz.hashCode();
    }
}
