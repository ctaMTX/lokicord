package kotlin.jvm.functions;

import kotlin.c;

/* compiled from: Functions.kt */
public interface Function0<R> extends c<R> {
    R invoke();
}
