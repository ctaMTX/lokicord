package kotlin.jvm.functions;

import kotlin.c;

/* compiled from: Functions.kt */
public interface n<P1, P2, P3, P4, P5, P6, P7, P8, R> extends c<R> {
}
