package kotlin.jvm;

/* compiled from: KotlinReflectionNotSupportedError.kt */
public final class b extends Error {
    public b() {
        super("Kotlin reflection implementation is not found at runtime. Make sure you have kotlin-reflect.jar in the classpath");
    }
}
