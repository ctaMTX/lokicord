package kotlin;

/* compiled from: AssertionsJVM.kt */
public final class v {
    public static final boolean bjF;
    public static final v bjG;

    static {
        v vVar = new v();
        bjG = vVar;
        bjF = vVar.getClass().desiredAssertionStatus();
    }

    private v() {
    }
}
