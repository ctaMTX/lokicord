package kotlin;

/* compiled from: Tuples.kt */
public final class q {
    public static final <A, B> Pair<A, B> m(A a2, B b2) {
        return new Pair<>(a2, b2);
    }
}
