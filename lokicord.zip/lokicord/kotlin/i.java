package kotlin;

/* compiled from: Lazy.kt */
class i extends h {
}
