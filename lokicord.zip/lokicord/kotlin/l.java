package kotlin;

import kotlin.jvm.internal.k;

/* compiled from: Standard.kt */
public final class l extends Error {
    private /* synthetic */ l() {
        this("An operation is not implemented.");
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public l(String str) {
        super(str);
        k.h(str, "message");
    }
}
