package kotlin;

public final class f extends i {
}
