package kotlin;

import java.io.Serializable;
import kotlin.jvm.internal.k;

/* compiled from: Tuples.kt */
public final class Pair<A, B> implements Serializable {
    public final A first;
    public final B second;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Pair)) {
            return false;
        }
        Pair pair = (Pair) obj;
        return k.n(this.first, pair.first) && k.n(this.second, pair.second);
    }

    public final int hashCode() {
        A a2 = this.first;
        int i = 0;
        int hashCode = (a2 != null ? a2.hashCode() : 0) * 31;
        B b2 = this.second;
        if (b2 != null) {
            i = b2.hashCode();
        }
        return hashCode + i;
    }

    public Pair(A a2, B b2) {
        this.first = a2;
        this.second = b2;
    }

    public final String toString() {
        return "(" + this.first + ", " + this.second + ')';
    }
}
