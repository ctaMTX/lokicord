package kotlin.sequences;

import java.util.Iterator;
import kotlin.a.x;

/* compiled from: Sequences.kt */
public final class e implements Sequence, d {
    public static final e bli = new e();

    private e() {
    }

    public final Iterator iterator() {
        return x.bjS;
    }

    public final /* bridge */ /* synthetic */ Sequence dp(int i) {
        return bli;
    }

    public final /* bridge */ /* synthetic */ Sequence dq(int i) {
        return bli;
    }
}
