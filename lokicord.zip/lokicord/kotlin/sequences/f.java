package kotlin.sequences;

import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;

/* compiled from: Sequences.kt */
public final class f<T> implements Sequence<T> {
    /* access modifiers changed from: private */
    public final Sequence<T> blg;
    /* access modifiers changed from: private */
    public final boolean blj;
    /* access modifiers changed from: private */
    public final Function1<T, Boolean> blk;

    public f(Sequence<? extends T> sequence, boolean z, Function1<? super T, Boolean> function1) {
        k.h(sequence, "sequence");
        k.h(function1, "predicate");
        this.blg = sequence;
        this.blj = z;
        this.blk = function1;
    }

    /* compiled from: Sequences.kt */
    public static final class a implements Iterator<T>, kotlin.jvm.internal.a.a {
        private final Iterator<T> aaP;
        private int bll = -1;
        private T blm;
        final /* synthetic */ f bln;

        public final void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }

        a(f fVar) {
            this.bln = fVar;
            this.aaP = fVar.blg.iterator();
        }

        private final void Eu() {
            while (this.aaP.hasNext()) {
                T next = this.aaP.next();
                if (((Boolean) this.bln.blk.invoke(next)).booleanValue() == this.bln.blj) {
                    this.blm = next;
                    this.bll = 1;
                    return;
                }
            }
            this.bll = 0;
        }

        public final T next() {
            if (this.bll == -1) {
                Eu();
            }
            if (this.bll != 0) {
                T t = this.blm;
                this.blm = null;
                this.bll = -1;
                return t;
            }
            throw new NoSuchElementException();
        }

        public final boolean hasNext() {
            if (this.bll == -1) {
                Eu();
            }
            return this.bll == 1;
        }
    }

    public final Iterator<T> iterator() {
        return new a(this);
    }
}
