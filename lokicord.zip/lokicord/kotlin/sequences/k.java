package kotlin.sequences;

/* compiled from: SequencesJVM.kt */
class k extends j {
}
