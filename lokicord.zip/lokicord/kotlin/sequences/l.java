package kotlin.sequences;

import java.util.Iterator;
import kotlin.a.g;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;

/* compiled from: Sequences.kt */
public class l extends k {

    /* compiled from: Sequences.kt */
    static final class c extends kotlin.jvm.internal.l implements Function1<T, T> {
        public static final c blx = new c();

        c() {
            super(1);
        }

        public final T invoke(T t) {
            return t;
        }
    }

    public static final <T> Sequence<T> r(T... tArr) {
        k.h(tArr, "elements");
        if (tArr.length == 0) {
            return e.bli;
        }
        return g.j(tArr);
    }

    public static final <T> Sequence<T> a(Sequence<? extends Sequence<? extends T>> sequence) {
        k.h(sequence, "$this$flatten");
        return a(sequence, a.blv);
    }

    public static final <T> Sequence<T> b(Sequence<? extends Iterable<? extends T>> sequence) {
        k.h(sequence, "$this$flatten");
        return a(sequence, b.blw);
    }

    private static final <T, R> Sequence<R> a(Sequence<? extends T> sequence, Function1<? super T, ? extends Iterator<? extends R>> function1) {
        if (sequence instanceof q) {
            return ((q) sequence).h(function1);
        }
        return new g<>(sequence, c.blx, function1);
    }

    public static final <T> Sequence<T> a(Function0<? extends T> function0, Function1<? super T, ? extends T> function1) {
        k.h(function0, "seedFunction");
        k.h(function1, "nextFunction");
        return new h<>(function0, function1);
    }

    /* compiled from: Sequences.kt */
    static final class a extends kotlin.jvm.internal.l implements Function1<Sequence<? extends T>, Iterator<? extends T>> {
        public static final a blv = new a();

        a() {
            super(1);
        }

        public final /* synthetic */ Object invoke(Object obj) {
            Sequence sequence = (Sequence) obj;
            k.h(sequence, "it");
            return sequence.iterator();
        }
    }

    /* compiled from: Sequences.kt */
    static final class b extends kotlin.jvm.internal.l implements Function1<Iterable<? extends T>, Iterator<? extends T>> {
        public static final b blw = new b();

        b() {
            super(1);
        }

        public final /* synthetic */ Object invoke(Object obj) {
            Iterable iterable = (Iterable) obj;
            k.h(iterable, "it");
            return iterable.iterator();
        }
    }
}
