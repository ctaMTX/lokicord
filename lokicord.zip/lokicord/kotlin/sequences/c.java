package kotlin.sequences;

import java.util.Iterator;
import kotlin.jvm.internal.k;

/* compiled from: Sequences.kt */
public final class c<T> implements Sequence<T>, d<T> {
    /* access modifiers changed from: private */
    public final Sequence<T> blg;
    /* access modifiers changed from: private */
    public final int count;

    public c(Sequence<? extends T> sequence, int i) {
        k.h(sequence, "sequence");
        this.blg = sequence;
        this.count = i;
        if (!(this.count >= 0)) {
            throw new IllegalArgumentException(("count must be non-negative, but was " + this.count + '.').toString());
        }
    }

    public final Sequence<T> dp(int i) {
        int i2 = this.count + 1;
        return i2 < 0 ? new c<>(this, 1) : new c<>(this.blg, i2);
    }

    public final Sequence<T> dq(int i) {
        int i2 = this.count;
        int i3 = i2 + i;
        return i3 < 0 ? new p<>(this, i) : new o<>(this.blg, i2, i3);
    }

    /* compiled from: Sequences.kt */
    public static final class a implements Iterator<T>, kotlin.jvm.internal.a.a {
        private final Iterator<T> aaP;
        final /* synthetic */ c blh;
        private int left;

        public final void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }

        a(c cVar) {
            this.blh = cVar;
            this.aaP = cVar.blg.iterator();
            this.left = cVar.count;
        }

        private final void drop() {
            while (this.left > 0 && this.aaP.hasNext()) {
                this.aaP.next();
                this.left--;
            }
        }

        public final T next() {
            drop();
            return this.aaP.next();
        }

        public final boolean hasNext() {
            drop();
            return this.aaP.hasNext();
        }
    }

    public final Iterator<T> iterator() {
        return new a(this);
    }
}
