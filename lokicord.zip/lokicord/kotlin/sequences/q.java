package kotlin.sequences;

import java.util.Iterator;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;

/* compiled from: Sequences.kt */
public final class q<T, R> implements Sequence<R> {
    /* access modifiers changed from: private */
    public final Sequence<T> blg;
    /* access modifiers changed from: private */
    public final Function1<T, R> blo;

    /* compiled from: Sequences.kt */
    public static final class a implements Iterator<R>, kotlin.jvm.internal.a.a {
        private final Iterator<T> aaP;
        final /* synthetic */ q blF;

        public final void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }

        a(q qVar) {
            this.blF = qVar;
            this.aaP = qVar.blg.iterator();
        }

        public final R next() {
            return this.blF.blo.invoke(this.aaP.next());
        }

        public final boolean hasNext() {
            return this.aaP.hasNext();
        }
    }

    public q(Sequence<? extends T> sequence, Function1<? super T, ? extends R> function1) {
        k.h(sequence, "sequence");
        k.h(function1, "transformer");
        this.blg = sequence;
        this.blo = function1;
    }

    public final Iterator<R> iterator() {
        return new a(this);
    }

    public final <E> Sequence<E> h(Function1<? super R, ? extends Iterator<? extends E>> function1) {
        k.h(function1, "iterator");
        return new g<>(this.blg, this.blo, function1);
    }
}
