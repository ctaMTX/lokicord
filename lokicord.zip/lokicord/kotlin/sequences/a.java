package kotlin.sequences;

import java.util.HashSet;
import java.util.Iterator;
import kotlin.a.ap;
import kotlin.a.b;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;

/* compiled from: Sequences.kt */
final class a<T, K> extends b<T> {
    private final HashSet<K> blc = new HashSet<>();
    private final Iterator<T> bld;
    private final Function1<T, K> ble;

    public a(Iterator<? extends T> it, Function1<? super T, ? extends K> function1) {
        k.h(it, "source");
        k.h(function1, "keySelector");
        this.bld = it;
        this.ble = function1;
    }

    public final void DX() {
        while (this.bld.hasNext()) {
            T next = this.bld.next();
            if (this.blc.add(this.ble.invoke(next))) {
                this.bjI = next;
                this.bjH = ap.bjX;
                return;
            }
        }
        this.bjH = ap.bjZ;
    }
}
