package kotlin.sequences;

import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;
import kotlin.r;

/* compiled from: Sequences.kt */
final class h<T> implements Sequence<T> {
    /* access modifiers changed from: private */
    public final Function0<T> bls;
    /* access modifiers changed from: private */
    public final Function1<T, T> blt;

    /* compiled from: Sequences.kt */
    public static final class a implements Iterator<T>, kotlin.jvm.internal.a.a {
        private int bll = -2;
        private T blm;
        final /* synthetic */ h blu;

        public final void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }

        a(h hVar) {
            this.blu = hVar;
        }

        private final void Eu() {
            T t;
            if (this.bll == -2) {
                t = this.blu.bls.invoke();
            } else {
                Function1 b2 = this.blu.blt;
                T t2 = this.blm;
                if (t2 == null) {
                    k.Em();
                }
                t = b2.invoke(t2);
            }
            this.blm = t;
            this.bll = this.blm == null ? 0 : 1;
        }

        public final T next() {
            if (this.bll < 0) {
                Eu();
            }
            if (this.bll != 0) {
                T t = this.blm;
                if (t != null) {
                    this.bll = -1;
                    return t;
                }
                throw new r("null cannot be cast to non-null type T");
            }
            throw new NoSuchElementException();
        }

        public final boolean hasNext() {
            if (this.bll < 0) {
                Eu();
            }
            return this.bll == 1;
        }
    }

    public h(Function0<? extends T> function0, Function1<? super T, ? extends T> function1) {
        k.h(function0, "getInitialValue");
        k.h(function1, "getNextValue");
        this.bls = function0;
        this.blt = function1;
    }

    public final Iterator<T> iterator() {
        return new a(this);
    }
}
