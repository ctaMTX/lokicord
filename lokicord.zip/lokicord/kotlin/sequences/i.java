package kotlin.sequences;

public final class i extends n {
}
