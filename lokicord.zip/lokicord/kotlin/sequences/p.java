package kotlin.sequences;

import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.jvm.internal.k;

/* compiled from: Sequences.kt */
public final class p<T> implements Sequence<T>, d<T> {
    /* access modifiers changed from: private */
    public final Sequence<T> blg;
    /* access modifiers changed from: private */
    public final int count;

    public p(Sequence<? extends T> sequence, int i) {
        k.h(sequence, "sequence");
        this.blg = sequence;
        this.count = i;
        if (!(this.count >= 0)) {
            throw new IllegalArgumentException(("count must be non-negative, but was " + this.count + '.').toString());
        }
    }

    public final Sequence<T> dp(int i) {
        int i2 = this.count;
        if (1 >= i2) {
            return e.bli;
        }
        return new o<>(this.blg, 1, i2);
    }

    public final Sequence<T> dq(int i) {
        return i >= this.count ? this : new p<>(this.blg, i);
    }

    /* compiled from: Sequences.kt */
    public static final class a implements Iterator<T>, kotlin.jvm.internal.a.a {
        private final Iterator<T> aaP;
        final /* synthetic */ p blE;
        private int left;

        public final void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }

        a(p pVar) {
            this.blE = pVar;
            this.left = pVar.count;
            this.aaP = pVar.blg.iterator();
        }

        public final T next() {
            int i = this.left;
            if (i != 0) {
                this.left = i - 1;
                return this.aaP.next();
            }
            throw new NoSuchElementException();
        }

        public final boolean hasNext() {
            return this.left > 0 && this.aaP.hasNext();
        }
    }

    public final Iterator<T> iterator() {
        return new a(this);
    }
}
