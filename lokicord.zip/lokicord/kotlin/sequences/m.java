package kotlin.sequences;

/* compiled from: _SequencesJvm.kt */
class m extends l {
}
