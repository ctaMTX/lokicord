package kotlin.sequences;

import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;

/* compiled from: Sequences.kt */
public final class g<T, R, E> implements Sequence<E> {
    /* access modifiers changed from: private */
    public final Sequence<T> blg;
    /* access modifiers changed from: private */
    public final Function1<T, R> blo;
    /* access modifiers changed from: private */
    public final Function1<R, Iterator<E>> blp;

    public g(Sequence<? extends T> sequence, Function1<? super T, ? extends R> function1, Function1<? super R, ? extends Iterator<? extends E>> function12) {
        k.h(sequence, "sequence");
        k.h(function1, "transformer");
        k.h(function12, "iterator");
        this.blg = sequence;
        this.blo = function1;
        this.blp = function12;
    }

    /* compiled from: Sequences.kt */
    public static final class a implements Iterator<E>, kotlin.jvm.internal.a.a {
        private final Iterator<T> aaP;
        private Iterator<? extends E> blq;
        final /* synthetic */ g blr;

        public final void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }

        a(g gVar) {
            this.blr = gVar;
            this.aaP = gVar.blg.iterator();
        }

        public final E next() {
            if (Ev()) {
                Iterator<? extends E> it = this.blq;
                if (it == null) {
                    k.Em();
                }
                return it.next();
            }
            throw new NoSuchElementException();
        }

        public final boolean hasNext() {
            return Ev();
        }

        private final boolean Ev() {
            Iterator<? extends E> it = this.blq;
            if (it != null && !it.hasNext()) {
                this.blq = null;
            }
            while (true) {
                if (this.blq == null) {
                    if (this.aaP.hasNext()) {
                        Iterator<? extends E> it2 = (Iterator) this.blr.blp.invoke(this.blr.blo.invoke(this.aaP.next()));
                        if (it2.hasNext()) {
                            this.blq = it2;
                            break;
                        }
                    } else {
                        return false;
                    }
                } else {
                    break;
                }
            }
            return true;
        }
    }

    public final Iterator<E> iterator() {
        return new a(this);
    }
}
