package kotlin.sequences;

import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.jvm.internal.k;

/* compiled from: Sequences.kt */
public final class o<T> implements Sequence<T>, d<T> {
    /* access modifiers changed from: private */
    public final Sequence<T> blg;
    /* access modifiers changed from: private */
    public final int startIndex;
    /* access modifiers changed from: private */
    public final int zY;

    public o(Sequence<? extends T> sequence, int i, int i2) {
        k.h(sequence, "sequence");
        this.blg = sequence;
        this.startIndex = i;
        this.zY = i2;
        boolean z = true;
        if (this.startIndex >= 0) {
            if (this.zY >= 0) {
                if (!(this.zY < this.startIndex ? false : z)) {
                    throw new IllegalArgumentException(("endIndex should be not less than startIndex, but was " + this.zY + " < " + this.startIndex).toString());
                }
                return;
            }
            throw new IllegalArgumentException(("endIndex should be non-negative, but is " + this.zY).toString());
        }
        throw new IllegalArgumentException(("startIndex should be non-negative, but is " + this.startIndex).toString());
    }

    private final int getCount() {
        return this.zY - this.startIndex;
    }

    public final Sequence<T> dp(int i) {
        if (1 >= getCount()) {
            return e.bli;
        }
        return new o<>(this.blg, this.startIndex + 1, this.zY);
    }

    public final Sequence<T> dq(int i) {
        if (i >= getCount()) {
            return this;
        }
        Sequence<T> sequence = this.blg;
        int i2 = this.startIndex;
        return new o<>(sequence, i2, i + i2);
    }

    /* compiled from: Sequences.kt */
    public static final class a implements Iterator<T>, kotlin.jvm.internal.a.a {
        private final Iterator<T> aaP;
        final /* synthetic */ o blD;
        private int position;

        public final void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }

        a(o oVar) {
            this.blD = oVar;
            this.aaP = oVar.blg.iterator();
        }

        private final void drop() {
            while (this.position < this.blD.startIndex && this.aaP.hasNext()) {
                this.aaP.next();
                this.position++;
            }
        }

        public final boolean hasNext() {
            drop();
            return this.position < this.blD.zY && this.aaP.hasNext();
        }

        public final T next() {
            drop();
            if (this.position < this.blD.zY) {
                this.position++;
                return this.aaP.next();
            }
            throw new NoSuchElementException();
        }
    }

    public final Iterator<T> iterator() {
        return new a(this);
    }
}
