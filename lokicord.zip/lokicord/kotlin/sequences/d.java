package kotlin.sequences;

/* compiled from: Sequences.kt */
public interface d<T> extends Sequence<T> {
    Sequence<T> dp(int i);

    Sequence<T> dq(int i);
}
