package kotlin.sequences;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import kotlin.a.ak;
import kotlin.a.m;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.l;

/* compiled from: _Sequences.kt */
public class n extends m {

    /* compiled from: _Sequences.kt */
    static final class b extends l implements Function1<T, T> {
        public static final b blz = new b();

        b() {
            super(1);
        }

        public final T invoke(T t) {
            return t;
        }
    }

    /* compiled from: Iterables.kt */
    public static final class a implements Iterable<T>, kotlin.jvm.internal.a.a {
        final /* synthetic */ Sequence bly;

        public a(Sequence sequence) {
            this.bly = sequence;
        }

        public final Iterator<T> iterator() {
            return this.bly.iterator();
        }
    }

    public static final <T> T c(Sequence<? extends T> sequence) {
        k.h(sequence, "$this$firstOrNull");
        Iterator<? extends T> it = sequence.iterator();
        if (!it.hasNext()) {
            return null;
        }
        return it.next();
    }

    public static final <T> Sequence<T> d(Sequence<? extends T> sequence) {
        k.h(sequence, "$this$drop");
        if (sequence instanceof d) {
            return ((d) sequence).dp(1);
        }
        return new c<>(sequence, 1);
    }

    public static final <T> Sequence<T> b(Sequence<? extends T> sequence, Function1<? super T, Boolean> function1) {
        k.h(sequence, "$this$filter");
        k.h(function1, "predicate");
        return new f<>(sequence, true, function1);
    }

    public static final <T> Sequence<T> c(Sequence<? extends T> sequence, Function1<? super T, Boolean> function1) {
        k.h(sequence, "$this$filterNot");
        k.h(function1, "predicate");
        return new f<>(sequence, false, function1);
    }

    public static final <T> Sequence<T> e(Sequence<? extends T> sequence) {
        k.h(sequence, "$this$filterNotNull");
        return i.c(sequence, c.blA);
    }

    /* compiled from: _Sequences.kt */
    public static final class d implements Sequence<T> {
        final /* synthetic */ Sequence blB;

        public d(Sequence<? extends T> sequence) {
            this.blB = sequence;
        }

        public final Iterator<T> iterator() {
            List g = i.g(this.blB);
            m.sort(g);
            return g.iterator();
        }
    }

    /* compiled from: _Sequences.kt */
    public static final class e implements Sequence<T> {
        final /* synthetic */ Comparator $comparator;
        final /* synthetic */ Sequence blC;

        e(Sequence<? extends T> sequence, Comparator comparator) {
            this.blC = sequence;
            this.$comparator = comparator;
        }

        public final Iterator<T> iterator() {
            List g = i.g(this.blC);
            m.a(g, this.$comparator);
            return g.iterator();
        }
    }

    public static final <T> Sequence<T> a(Sequence<? extends T> sequence, Comparator<? super T> comparator) {
        k.h(sequence, "$this$sortedWith");
        k.h(comparator, "comparator");
        return new e(sequence, comparator);
    }

    public static final <T, C extends Collection<? super T>> C a(Sequence<? extends T> sequence, C c2) {
        k.h(sequence, "$this$toCollection");
        k.h(c2, "destination");
        for (Object add : sequence) {
            c2.add(add);
        }
        return c2;
    }

    public static final <T> List<T> f(Sequence<? extends T> sequence) {
        k.h(sequence, "$this$toList");
        return m.Z(i.g(sequence));
    }

    public static final <T> List<T> g(Sequence<? extends T> sequence) {
        k.h(sequence, "$this$toMutableList");
        return (List) i.a(sequence, new ArrayList());
    }

    public static final <T> Set<T> h(Sequence<? extends T> sequence) {
        k.h(sequence, "$this$toSet");
        return ak.e((Set) i.a(sequence, new LinkedHashSet()));
    }

    public static final <T, R> Sequence<R> d(Sequence<? extends T> sequence, Function1<? super T, ? extends R> function1) {
        k.h(sequence, "$this$map");
        k.h(function1, "transform");
        return new q<>(sequence, function1);
    }

    public static final <T, R> Sequence<R> e(Sequence<? extends T> sequence, Function1<? super T, ? extends R> function1) {
        k.h(sequence, "$this$mapNotNull");
        k.h(function1, "transform");
        return i.e(new q(sequence, function1));
    }

    public static final <T> Sequence<T> i(Sequence<? extends T> sequence) {
        k.h(sequence, "$this$distinct");
        return i.f(sequence, b.blz);
    }

    public static final <T, K> Sequence<T> f(Sequence<? extends T> sequence, Function1<? super T, ? extends K> function1) {
        k.h(sequence, "$this$distinctBy");
        k.h(function1, "selector");
        return new b<>(sequence, function1);
    }

    /* compiled from: _Sequences.kt */
    static final class c extends l implements Function1<T, Boolean> {
        public static final c blA = new c();

        c() {
            super(1);
        }

        public final /* synthetic */ Object invoke(Object obj) {
            return Boolean.valueOf(obj == null);
        }
    }

    public static final <T> Sequence<T> a(Sequence<? extends T> sequence, Sequence<? extends T> sequence2) {
        k.h(sequence, "$this$plus");
        k.h(sequence2, "elements");
        return i.a(i.r(sequence, sequence2));
    }

    public static final <T, A extends Appendable> A a(Sequence<? extends T> sequence, A a2, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i, CharSequence charSequence4, Function1<? super T, ? extends CharSequence> function1) {
        k.h(sequence, "$this$joinTo");
        k.h(a2, "buffer");
        k.h(charSequence, "separator");
        k.h(charSequence2, "prefix");
        k.h(charSequence3, "postfix");
        k.h(charSequence4, "truncated");
        a2.append(charSequence2);
        int i2 = 0;
        for (Object next : sequence) {
            i2++;
            if (i2 > 1) {
                a2.append(charSequence);
            }
            if (i >= 0 && i2 > i) {
                break;
            }
            kotlin.text.l.a(a2, next, function1);
        }
        if (i >= 0 && i2 > i) {
            a2.append(charSequence4);
        }
        a2.append(charSequence3);
        return a2;
    }

    public static /* synthetic */ String a(Sequence sequence, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i, CharSequence charSequence4, int i2) {
        if ((i2 & 1) != 0) {
        }
        CharSequence charSequence5 = charSequence;
        if ((i2 & 2) != 0) {
            charSequence2 = "";
        }
        CharSequence charSequence6 = charSequence2;
        if ((i2 & 4) != 0) {
            charSequence3 = "";
        }
        CharSequence charSequence7 = charSequence3;
        int i3 = (i2 & 8) != 0 ? -1 : i;
        if ((i2 & 16) != 0) {
            charSequence4 = "...";
        }
        return i.a(sequence, charSequence5, charSequence6, charSequence7, i3, charSequence4, (Function1) null);
    }

    public static final <T> String a(Sequence<? extends T> sequence, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i, CharSequence charSequence4, Function1<? super T, ? extends CharSequence> function1) {
        k.h(sequence, "$this$joinToString");
        k.h(charSequence, "separator");
        k.h(charSequence2, "prefix");
        k.h(charSequence3, "postfix");
        k.h(charSequence4, "truncated");
        String sb = ((StringBuilder) i.a(sequence, new StringBuilder(), charSequence, charSequence2, charSequence3, i, charSequence4, (Function1) null)).toString();
        k.g(sb, "joinTo(StringBuilder(), …ed, transform).toString()");
        return sb;
    }

    public static final <T> Iterable<T> j(Sequence<? extends T> sequence) {
        k.h(sequence, "$this$asIterable");
        return new a(sequence);
    }

    public static final <T> Sequence<T> a(Sequence<? extends T> sequence, int i) {
        k.h(sequence, "$this$take");
        if (!(i >= 0)) {
            throw new IllegalArgumentException(("Requested element count " + i + " is less than zero.").toString());
        } else if (i == 0) {
            return e.bli;
        } else {
            if (sequence instanceof d) {
                return ((d) sequence).dq(i);
            }
            return new p<>(sequence, i);
        }
    }
}
