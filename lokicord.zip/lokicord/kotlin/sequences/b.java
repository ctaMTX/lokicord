package kotlin.sequences;

import java.util.Iterator;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;

/* compiled from: Sequences.kt */
public final class b<T, K> implements Sequence<T> {
    private final Function1<T, K> ble;
    private final Sequence<T> blf;

    public b(Sequence<? extends T> sequence, Function1<? super T, ? extends K> function1) {
        k.h(sequence, "source");
        k.h(function1, "keySelector");
        this.blf = sequence;
        this.ble = function1;
    }

    public final Iterator<T> iterator() {
        return new a<>(this.blf.iterator(), this.ble);
    }
}
