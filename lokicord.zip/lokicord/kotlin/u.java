package kotlin;

import java.io.Serializable;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.k;

/* compiled from: Lazy.kt */
public final class u<T> implements Serializable, Lazy<T> {
    private Object _value = s.bjD;
    private Function0<? extends T> initializer;

    public u(Function0<? extends T> function0) {
        k.h(function0, "initializer");
        this.initializer = function0;
    }

    public final T getValue() {
        if (this._value == s.bjD) {
            Function0<? extends T> function0 = this.initializer;
            if (function0 == null) {
                k.Em();
            }
            this._value = function0.invoke();
            this.initializer = null;
        }
        return this._value;
    }

    private final Object writeReplace() {
        return new d(getValue());
    }

    public final String toString() {
        return this._value != s.bjD ? String.valueOf(getValue()) : "Lazy value not initialized yet.";
    }
}
