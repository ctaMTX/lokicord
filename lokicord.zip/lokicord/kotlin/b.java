package kotlin;

import kotlin.jvm.internal.k;

/* compiled from: Exceptions.kt */
public class b {
    public static final void b(Throwable th, Throwable th2) {
        k.h(th, "$this$addSuppressed");
        k.h(th2, "exception");
        kotlin.c.b.bkx.b(th, th2);
    }
}
