package kotlin.coroutines;

import java.io.Serializable;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.k;

/* compiled from: CoroutineContextImpl.kt */
public final class d implements Serializable, CoroutineContext {
    public static final d bkj = new d();
    private static final long serialVersionUID = 0;

    public final <R> R fold(R r, Function2<? super R, ? super CoroutineContext.b, ? extends R> function2) {
        k.h(function2, "operation");
        return r;
    }

    public final <E extends CoroutineContext.b> E get(CoroutineContext.c<E> cVar) {
        k.h(cVar, "key");
        return null;
    }

    public final int hashCode() {
        return 0;
    }

    public final CoroutineContext plus(CoroutineContext coroutineContext) {
        k.h(coroutineContext, "context");
        return coroutineContext;
    }

    public final String toString() {
        return "EmptyCoroutineContext";
    }

    private d() {
    }

    private final Object readResolve() {
        return bkj;
    }

    public final CoroutineContext minusKey(CoroutineContext.c<?> cVar) {
        k.h(cVar, "key");
        return this;
    }
}
