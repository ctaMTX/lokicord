package kotlin.coroutines;

import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.k;

/* compiled from: CoroutineContextImpl.kt */
public abstract class a implements CoroutineContext.b {
    private final CoroutineContext.c<?> key;

    public a(CoroutineContext.c<?> cVar) {
        k.h(cVar, "key");
        this.key = cVar;
    }

    public <R> R fold(R r, Function2<? super R, ? super CoroutineContext.b, ? extends R> function2) {
        k.h(function2, "operation");
        return CoroutineContext.b.a.a(this, r, function2);
    }

    public <E extends CoroutineContext.b> E get(CoroutineContext.c<E> cVar) {
        k.h(cVar, "key");
        return CoroutineContext.b.a.a((CoroutineContext.b) this, cVar);
    }

    public CoroutineContext.c<?> getKey() {
        return this.key;
    }

    public CoroutineContext minusKey(CoroutineContext.c<?> cVar) {
        k.h(cVar, "key");
        return CoroutineContext.b.a.b(this, cVar);
    }

    public CoroutineContext plus(CoroutineContext coroutineContext) {
        k.h(coroutineContext, "context");
        return CoroutineContext.b.a.a((CoroutineContext.b) this, coroutineContext);
    }
}
