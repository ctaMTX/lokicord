package kotlin.coroutines;

import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.l;

/* compiled from: CoroutineContext.kt */
public interface CoroutineContext {

    /* compiled from: CoroutineContext.kt */
    public interface c<E extends b> {
    }

    <R> R fold(R r, Function2<? super R, ? super b, ? extends R> function2);

    <E extends b> E get(c<E> cVar);

    CoroutineContext minusKey(c<?> cVar);

    CoroutineContext plus(CoroutineContext coroutineContext);

    /* compiled from: CoroutineContext.kt */
    public static final class a {

        /* renamed from: kotlin.coroutines.CoroutineContext$a$a  reason: collision with other inner class name */
        /* compiled from: CoroutineContext.kt */
        static final class C0117a extends l implements Function2<CoroutineContext, b, CoroutineContext> {
            public static final C0117a bki = new C0117a();

            C0117a() {
                super(2);
            }

            public final /* synthetic */ Object invoke(Object obj, Object obj2) {
                b bVar;
                CoroutineContext coroutineContext = (CoroutineContext) obj;
                b bVar2 = (b) obj2;
                k.h(coroutineContext, "acc");
                k.h(bVar2, "element");
                CoroutineContext minusKey = coroutineContext.minusKey(bVar2.getKey());
                if (minusKey == d.bkj) {
                    bVar = bVar2;
                } else {
                    c cVar = (c) minusKey.get(c.bkg);
                    if (cVar == null) {
                        bVar = new b(minusKey, bVar2);
                    } else {
                        CoroutineContext minusKey2 = minusKey.minusKey(c.bkg);
                        if (minusKey2 == d.bkj) {
                            bVar = new b(bVar2, cVar);
                        } else {
                            bVar = new b(new b(minusKey2, bVar2), cVar);
                        }
                    }
                }
                return bVar;
            }
        }

        public static CoroutineContext a(CoroutineContext coroutineContext, CoroutineContext coroutineContext2) {
            k.h(coroutineContext2, "context");
            if (coroutineContext2 == d.bkj) {
                return coroutineContext;
            }
            return (CoroutineContext) coroutineContext2.fold(coroutineContext, C0117a.bki);
        }
    }

    /* compiled from: CoroutineContext.kt */
    public interface b extends CoroutineContext {
        <E extends b> E get(c<E> cVar);

        c<?> getKey();

        /* compiled from: CoroutineContext.kt */
        public static final class a {
            public static CoroutineContext a(b bVar, CoroutineContext coroutineContext) {
                k.h(coroutineContext, "context");
                return a.a(bVar, coroutineContext);
            }

            public static <E extends b> E a(b bVar, c<E> cVar) {
                k.h(cVar, "key");
                if (k.n(bVar.getKey(), cVar)) {
                    return bVar;
                }
                return null;
            }

            public static <R> R a(b bVar, R r, Function2<? super R, ? super b, ? extends R> function2) {
                k.h(function2, "operation");
                return function2.invoke(r, bVar);
            }

            public static CoroutineContext b(b bVar, c<?> cVar) {
                k.h(cVar, "key");
                return k.n(bVar.getKey(), cVar) ? d.bkj : bVar;
            }
        }
    }
}
