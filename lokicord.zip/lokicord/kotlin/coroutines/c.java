package kotlin.coroutines;

import kotlin.coroutines.CoroutineContext;

/* compiled from: ContinuationInterceptor.kt */
public interface c extends CoroutineContext.b {
    public static final a bkg = a.bkh;

    <T> Continuation<T> a(Continuation<? super T> continuation);

    void b(Continuation<?> continuation);

    /* compiled from: ContinuationInterceptor.kt */
    public static final class a implements CoroutineContext.c<c> {
        static final /* synthetic */ a bkh = new a();

        private a() {
        }
    }
}
