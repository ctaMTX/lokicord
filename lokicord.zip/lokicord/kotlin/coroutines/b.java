package kotlin.coroutines;

import java.io.Serializable;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.l;
import kotlin.r;

/* compiled from: CoroutineContextImpl.kt */
public final class b implements Serializable, CoroutineContext {
    private final CoroutineContext.b element;
    private final CoroutineContext left;

    /* renamed from: kotlin.coroutines.b$b  reason: collision with other inner class name */
    /* compiled from: CoroutineContextImpl.kt */
    static final class C0119b extends l implements Function2<String, CoroutineContext.b, String> {
        public static final C0119b bkf = new C0119b();

        C0119b() {
            super(2);
        }

        public final /* synthetic */ Object invoke(Object obj, Object obj2) {
            String str = (String) obj;
            CoroutineContext.b bVar = (CoroutineContext.b) obj2;
            k.h(str, "acc");
            k.h(bVar, "element");
            if (str.length() == 0) {
                return bVar.toString();
            }
            return str + ", " + bVar;
        }
    }

    /* compiled from: CoroutineContextImpl.kt */
    static final class c extends l implements Function2<Unit, CoroutineContext.b, Unit> {
        final /* synthetic */ CoroutineContext[] $elements;
        final /* synthetic */ Ref.IntRef $index;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        c(CoroutineContext[] coroutineContextArr, Ref.IntRef intRef) {
            super(2);
            this.$elements = coroutineContextArr;
            this.$index = intRef;
        }

        public final /* synthetic */ Object invoke(Object obj, Object obj2) {
            CoroutineContext.b bVar = (CoroutineContext.b) obj2;
            k.h((Unit) obj, "<anonymous parameter 0>");
            k.h(bVar, "element");
            CoroutineContext[] coroutineContextArr = this.$elements;
            Ref.IntRef intRef = this.$index;
            int i = intRef.element;
            intRef.element = i + 1;
            coroutineContextArr[i] = bVar;
            return Unit.bjE;
        }
    }

    public b(CoroutineContext coroutineContext, CoroutineContext.b bVar) {
        k.h(coroutineContext, "left");
        k.h(bVar, "element");
        this.left = coroutineContext;
        this.element = bVar;
    }

    public final CoroutineContext plus(CoroutineContext coroutineContext) {
        k.h(coroutineContext, "context");
        return CoroutineContext.a.a(this, coroutineContext);
    }

    public final <E extends CoroutineContext.b> E get(CoroutineContext.c<E> cVar) {
        k.h(cVar, "key");
        CoroutineContext coroutineContext = this;
        while (true) {
            b bVar = (b) coroutineContext;
            E e = bVar.element.get(cVar);
            if (e != null) {
                return e;
            }
            coroutineContext = bVar.left;
            if (!(coroutineContext instanceof b)) {
                return coroutineContext.get(cVar);
            }
        }
    }

    public final <R> R fold(R r, Function2<? super R, ? super CoroutineContext.b, ? extends R> function2) {
        k.h(function2, "operation");
        return function2.invoke(this.left.fold(r, function2), this.element);
    }

    public final CoroutineContext minusKey(CoroutineContext.c<?> cVar) {
        k.h(cVar, "key");
        if (this.element.get(cVar) != null) {
            return this.left;
        }
        CoroutineContext minusKey = this.left.minusKey(cVar);
        if (minusKey == this.left) {
            return this;
        }
        if (minusKey == d.bkj) {
            return this.element;
        }
        return new b(minusKey, this.element);
    }

    private final int size() {
        b bVar = this;
        int i = 2;
        while (true) {
            CoroutineContext coroutineContext = bVar.left;
            if (!(coroutineContext instanceof b)) {
                coroutineContext = null;
            }
            bVar = (b) coroutineContext;
            if (bVar == null) {
                return i;
            }
            i++;
        }
    }

    private final boolean a(CoroutineContext.b bVar) {
        return k.n(get(bVar.getKey()), bVar);
    }

    public final boolean equals(Object obj) {
        boolean z;
        if (this == obj) {
            return true;
        }
        if (obj instanceof b) {
            b bVar = (b) obj;
            if (bVar.size() == size()) {
                b bVar2 = this;
                while (true) {
                    if (!bVar.a(bVar2.element)) {
                        z = false;
                        break;
                    }
                    CoroutineContext coroutineContext = bVar2.left;
                    if (coroutineContext instanceof b) {
                        bVar2 = (b) coroutineContext;
                    } else if (coroutineContext != null) {
                        z = bVar.a((CoroutineContext.b) coroutineContext);
                    } else {
                        throw new r("null cannot be cast to non-null type kotlin.coroutines.CoroutineContext.Element");
                    }
                }
                if (z) {
                    return true;
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.left.hashCode() + this.element.hashCode();
    }

    public final String toString() {
        return "[" + ((String) fold("", C0119b.bkf)) + "]";
    }

    private final Object writeReplace() {
        int size = size();
        CoroutineContext[] coroutineContextArr = new CoroutineContext[size];
        Ref.IntRef intRef = new Ref.IntRef();
        boolean z = false;
        intRef.element = 0;
        fold(Unit.bjE, new c(coroutineContextArr, intRef));
        if (intRef.element == size) {
            z = true;
        }
        if (z) {
            return new a(coroutineContextArr);
        }
        throw new IllegalStateException("Check failed.".toString());
    }

    /* compiled from: CoroutineContextImpl.kt */
    static final class a implements Serializable {
        public static final C0118a bke = new C0118a((byte) 0);
        private static final long serialVersionUID = 0;
        private final CoroutineContext[] elements;

        /* renamed from: kotlin.coroutines.b$a$a  reason: collision with other inner class name */
        /* compiled from: CoroutineContextImpl.kt */
        public static final class C0118a {
            private C0118a() {
            }

            public /* synthetic */ C0118a(byte b2) {
                this();
            }
        }

        public a(CoroutineContext[] coroutineContextArr) {
            k.h(coroutineContextArr, "elements");
            this.elements = coroutineContextArr;
        }

        private final Object readResolve() {
            CoroutineContext[] coroutineContextArr = this.elements;
            CoroutineContext coroutineContext = d.bkj;
            for (CoroutineContext plus : coroutineContextArr) {
                coroutineContext = coroutineContext.plus(plus);
            }
            return coroutineContext;
        }
    }
}
