package kotlin.coroutines.jvm.internal;

import kotlin.coroutines.Continuation;
import kotlin.jvm.internal.i;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.w;

/* compiled from: ContinuationImpl.kt */
public abstract class h extends c implements i<Object> {
    private final int arity;

    public int getArity() {
        return this.arity;
    }

    public h(int i, Continuation<Object> continuation) {
        super(continuation);
        this.arity = i;
    }

    public h(int i) {
        this(i, (Continuation<Object>) null);
    }

    public String toString() {
        if (getCompletion() != null) {
            return super.toString();
        }
        String a2 = w.a((i) this);
        k.g(a2, "Reflection.renderLambdaToString(this)");
        return a2;
    }
}
