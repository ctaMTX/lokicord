package kotlin.coroutines.jvm.internal;

import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.internal.k;

/* compiled from: ContinuationImpl.kt */
public abstract class c extends a {
    private final CoroutineContext _context;
    private transient Continuation<Object> intercepted;

    public c(Continuation<Object> continuation, CoroutineContext coroutineContext) {
        super(continuation);
        this._context = coroutineContext;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public c(Continuation<Object> continuation) {
        this(continuation, continuation != null ? continuation.getContext() : null);
    }

    public CoroutineContext getContext() {
        CoroutineContext coroutineContext = this._context;
        if (coroutineContext == null) {
            k.Em();
        }
        return coroutineContext;
    }

    public final Continuation<Object> intercepted() {
        Continuation<Object> continuation = this.intercepted;
        if (continuation == null) {
            kotlin.coroutines.c cVar = (kotlin.coroutines.c) getContext().get(kotlin.coroutines.c.bkg);
            continuation = cVar != null ? cVar.a(this) : this;
            this.intercepted = continuation;
        }
        return continuation;
    }

    /* access modifiers changed from: protected */
    public void releaseIntercepted() {
        Continuation<Object> continuation = this.intercepted;
        if (!(continuation == null || continuation == this)) {
            CoroutineContext.b bVar = getContext().get(kotlin.coroutines.c.bkg);
            if (bVar == null) {
                k.Em();
            }
            ((kotlin.coroutines.c) bVar).b(continuation);
        }
        this.intercepted = b.bko;
    }
}
