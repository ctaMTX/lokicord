package kotlin.coroutines.jvm.internal;

import com.discord.models.domain.ModelAuditLogEntry;
import java.lang.reflect.Method;

/* compiled from: DebugMetadata.kt */
final class f {
    static final a bkp = new a((Method) null, (Method) null, (Method) null);
    public static a bkq;
    public static final f bkr = new f();

    /* compiled from: DebugMetadata.kt */
    static final class a {
        public final Method bks;
        public final Method bkt;
        public final Method bku;

        public a(Method method, Method method2, Method method3) {
            this.bks = method;
            this.bkt = method2;
            this.bku = method3;
        }
    }

    private f() {
    }

    static a b(a aVar) {
        try {
            a aVar2 = new a(Class.class.getDeclaredMethod("getModule", new Class[0]), aVar.getClass().getClassLoader().loadClass("java.lang.Module").getDeclaredMethod("getDescriptor", new Class[0]), aVar.getClass().getClassLoader().loadClass("java.lang.module.ModuleDescriptor").getDeclaredMethod(ModelAuditLogEntry.CHANGE_KEY_NAME, new Class[0]));
            bkq = aVar2;
            return aVar2;
        } catch (Exception unused) {
            a aVar3 = bkp;
            bkq = aVar3;
            return aVar3;
        }
    }
}
