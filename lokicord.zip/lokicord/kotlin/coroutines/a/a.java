package kotlin.coroutines.a;

/* compiled from: Intrinsics.kt */
public enum a {
    COROUTINE_SUSPENDED,
    UNDECIDED,
    RESUMED
}
