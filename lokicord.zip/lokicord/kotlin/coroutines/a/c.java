package kotlin.coroutines.a;

import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.d;
import kotlin.coroutines.jvm.internal.g;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.aa;
import kotlin.jvm.internal.k;
import kotlin.r;

/* compiled from: IntrinsicsJvm.kt */
public class c {
    public static final <R, T> Continuation<Unit> a(Function2<? super R, ? super Continuation<? super T>, ? extends Object> function2, R r, Continuation<? super T> continuation) {
        k.h(function2, "$this$createCoroutineUnintercepted");
        k.h(continuation, "completion");
        k.h(continuation, "completion");
        if (function2 instanceof kotlin.coroutines.jvm.internal.a) {
            return ((kotlin.coroutines.jvm.internal.a) function2).create(r, continuation);
        }
        CoroutineContext context = continuation.getContext();
        if (context == d.bkj) {
            if (continuation != null) {
                return new a(continuation, continuation, function2, r);
            }
            throw new r("null cannot be cast to non-null type kotlin.coroutines.Continuation<kotlin.Any?>");
        } else if (continuation != null) {
            return new b(continuation, context, continuation, context, function2, r);
        } else {
            throw new r("null cannot be cast to non-null type kotlin.coroutines.Continuation<kotlin.Any?>");
        }
    }

    public static final <T> Continuation<T> c(Continuation<? super T> continuation) {
        Continuation<Object> intercepted;
        k.h(continuation, "$this$intercepted");
        kotlin.coroutines.jvm.internal.c cVar = (kotlin.coroutines.jvm.internal.c) (!(continuation instanceof kotlin.coroutines.jvm.internal.c) ? null : continuation);
        return (cVar == null || (intercepted = cVar.intercepted()) == null) ? continuation : intercepted;
    }

    /* compiled from: IntrinsicsJvm.kt */
    public static final class a extends g {
        final /* synthetic */ Continuation $completion;
        final /* synthetic */ Object $receiver$inlined;
        final /* synthetic */ Function2 $this_createCoroutineUnintercepted$inlined;
        private int label;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(Continuation continuation, Continuation continuation2, Function2 function2, Object obj) {
            super(continuation2);
            this.$completion = continuation;
            this.$this_createCoroutineUnintercepted$inlined = function2;
            this.$receiver$inlined = obj;
        }

        public final Object invokeSuspend(Object obj) {
            int i = this.label;
            if (i == 0) {
                this.label = 1;
                Continuation continuation = this;
                Function2 function2 = this.$this_createCoroutineUnintercepted$inlined;
                if (function2 != null) {
                    return ((Function2) aa.bi(function2)).invoke(this.$receiver$inlined, continuation);
                }
                throw new r("null cannot be cast to non-null type (R, kotlin.coroutines.Continuation<T>) -> kotlin.Any?");
            } else if (i == 1) {
                this.label = 2;
                return obj;
            } else {
                throw new IllegalStateException("This coroutine had already completed".toString());
            }
        }
    }

    /* compiled from: IntrinsicsJvm.kt */
    public static final class b extends kotlin.coroutines.jvm.internal.c {
        final /* synthetic */ Continuation $completion;
        final /* synthetic */ CoroutineContext $context;
        final /* synthetic */ Object $receiver$inlined;
        final /* synthetic */ Function2 $this_createCoroutineUnintercepted$inlined;
        private int label;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public b(Continuation continuation, CoroutineContext coroutineContext, Continuation continuation2, CoroutineContext coroutineContext2, Function2 function2, Object obj) {
            super(continuation2, coroutineContext2);
            this.$completion = continuation;
            this.$context = coroutineContext;
            this.$this_createCoroutineUnintercepted$inlined = function2;
            this.$receiver$inlined = obj;
        }

        public final Object invokeSuspend(Object obj) {
            int i = this.label;
            if (i == 0) {
                this.label = 1;
                Continuation continuation = this;
                Function2 function2 = this.$this_createCoroutineUnintercepted$inlined;
                if (function2 != null) {
                    return ((Function2) aa.bi(function2)).invoke(this.$receiver$inlined, continuation);
                }
                throw new r("null cannot be cast to non-null type (R, kotlin.coroutines.Continuation<T>) -> kotlin.Any?");
            } else if (i == 1) {
                this.label = 2;
                return obj;
            } else {
                throw new IllegalStateException("This coroutine had already completed".toString());
            }
        }
    }
}
