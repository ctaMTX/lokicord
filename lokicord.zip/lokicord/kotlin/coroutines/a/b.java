package kotlin.coroutines.a;

public final class b extends d {
}
