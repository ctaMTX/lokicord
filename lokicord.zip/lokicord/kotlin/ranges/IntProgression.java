package kotlin.ranges;

import java.util.Iterator;
import kotlin.c.c;

/* compiled from: Progressions.kt */
public class IntProgression implements Iterable<Integer>, kotlin.jvm.internal.a.a {
    public static final a bkS = new a((byte) 0);
    public final int bkP;
    public final int bkQ;
    public final int bkR;

    public IntProgression(int i, int i2, int i3) {
        if (i3 == 0) {
            throw new IllegalArgumentException("Step must be non-zero.");
        } else if (i3 != Integer.MIN_VALUE) {
            this.bkP = i;
            if (i3 > 0) {
                if (i < i2) {
                    i2 -= c.k(i2, i, i3);
                }
            } else if (i3 >= 0) {
                throw new IllegalArgumentException("Step is zero.");
            } else if (i > i2) {
                i2 += c.k(i, i2, -i3);
            }
            this.bkQ = i2;
            this.bkR = i3;
        } else {
            throw new IllegalArgumentException("Step must be greater than Int.MIN_VALUE to avoid overflow on negation.");
        }
    }

    public boolean isEmpty() {
        return this.bkR > 0 ? this.bkP > this.bkQ : this.bkP < this.bkQ;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof IntProgression)) {
            return false;
        }
        if (isEmpty() && ((IntProgression) obj).isEmpty()) {
            return true;
        }
        IntProgression intProgression = (IntProgression) obj;
        return this.bkP == intProgression.bkP && this.bkQ == intProgression.bkQ && this.bkR == intProgression.bkR;
    }

    public int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        return (((this.bkP * 31) + this.bkQ) * 31) + this.bkR;
    }

    public String toString() {
        StringBuilder sb;
        int i;
        if (this.bkR > 0) {
            sb = new StringBuilder();
            sb.append(this.bkP);
            sb.append("..");
            sb.append(this.bkQ);
            sb.append(" step ");
            i = this.bkR;
        } else {
            sb = new StringBuilder();
            sb.append(this.bkP);
            sb.append(" downTo ");
            sb.append(this.bkQ);
            sb.append(" step ");
            i = -this.bkR;
        }
        sb.append(i);
        return sb.toString();
    }

    /* compiled from: Progressions.kt */
    public static final class a {
        private a() {
        }

        public /* synthetic */ a(byte b2) {
            this();
        }

        public static IntProgression l(int i, int i2, int i3) {
            return new IntProgression(i, i2, i3);
        }
    }

    public /* synthetic */ Iterator iterator() {
        return new b(this.bkP, this.bkQ, this.bkR);
    }
}
