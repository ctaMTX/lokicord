package kotlin.ranges;

import java.util.NoSuchElementException;
import kotlin.a.ab;

/* compiled from: ProgressionIterators.kt */
public final class b extends ab {
    private final int bkR;
    private final int bkT;
    private int bkU;
    private boolean hasNext;

    public b(int i, int i2, int i3) {
        this.bkR = i3;
        this.bkT = i2;
        boolean z = true;
        if (this.bkR <= 0 ? i < i2 : i > i2) {
            z = false;
        }
        this.hasNext = z;
        this.bkU = !this.hasNext ? this.bkT : i;
    }

    public final boolean hasNext() {
        return this.hasNext;
    }

    public final int nextInt() {
        int i = this.bkU;
        if (i != this.bkT) {
            this.bkU = this.bkR + i;
        } else if (this.hasNext) {
            this.hasNext = false;
        } else {
            throw new NoSuchElementException();
        }
        return i;
    }
}
