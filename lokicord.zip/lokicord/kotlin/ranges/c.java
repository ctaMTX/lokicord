package kotlin.ranges;

public final class c extends f {
}
