package kotlin.ranges;

import kotlin.ranges.IntProgression;
import kotlin.ranges.IntRange;

/* compiled from: _Ranges.kt */
public class f extends e {
    public static final int Z(int i, int i2) {
        return i < i2 ? i2 : i;
    }

    public static final int aa(int i, int i2) {
        return i > i2 ? i2 : i;
    }

    public static final long f(long j, long j2) {
        return j < j2 ? j2 : j;
    }

    public static final long g(long j, long j2) {
        return j > j2 ? j2 : j;
    }

    public static final IntProgression X(int i, int i2) {
        IntProgression.a aVar = IntProgression.bkS;
        return IntProgression.a.l(i, i2, -1);
    }

    public static final IntRange Y(int i, int i2) {
        if (i2 > Integer.MIN_VALUE) {
            return new IntRange(i, i2 - 1);
        }
        IntRange.a aVar = IntRange.bkW;
        return IntRange.bkV;
    }

    public static final int m(int i, int i2, int i3) {
        if (i2 > i3) {
            throw new IllegalArgumentException("Cannot coerce value to an empty range: maximum " + i3 + " is less than minimum " + i2 + '.');
        } else if (i < i2) {
            return i2;
        } else {
            return i > i3 ? i3 : i;
        }
    }
}
