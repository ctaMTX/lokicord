package kotlin.ranges;

/* compiled from: Ranges.kt */
class e extends d {
}
