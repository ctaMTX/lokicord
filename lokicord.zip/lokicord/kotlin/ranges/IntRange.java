package kotlin.ranges;

/* compiled from: Ranges.kt */
public final class IntRange extends IntProgression implements a<Integer> {
    /* access modifiers changed from: private */
    public static final IntRange bkV = new IntRange(1, 0);
    public static final a bkW = new a((byte) 0);

    public IntRange(int i, int i2) {
        super(i, i2, 1);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof IntRange)) {
            return false;
        }
        if (isEmpty() && ((IntRange) obj).isEmpty()) {
            return true;
        }
        IntRange intRange = (IntRange) obj;
        return this.bkP == intRange.bkP && this.bkQ == intRange.bkQ;
    }

    public final int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        return (this.bkP * 31) + this.bkQ;
    }

    public final String toString() {
        return this.bkP + ".." + this.bkQ;
    }

    /* compiled from: Ranges.kt */
    public static final class a {
        private a() {
        }

        public /* synthetic */ a(byte b2) {
            this();
        }
    }

    public final /* synthetic */ Comparable getStart() {
        return Integer.valueOf(this.bkP);
    }

    public final /* synthetic */ Comparable getEndInclusive() {
        return Integer.valueOf(this.bkQ);
    }

    public final boolean contains(int i) {
        return this.bkP <= i && i <= this.bkQ;
    }

    public final boolean isEmpty() {
        return this.bkP > this.bkQ;
    }
}
