package kotlin;

import kotlin.jvm.internal.k;
import kotlin.m;

/* compiled from: Result.kt */
public final class n {
    public static final Object o(Throwable th) {
        k.h(th, "exception");
        return new m.b(th);
    }
}
