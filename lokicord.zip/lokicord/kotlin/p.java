package kotlin;

import java.io.Serializable;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.k;

/* compiled from: LazyJVM.kt */
public final class p<T> implements Serializable, Lazy<T> {
    private volatile Object _value;
    private Function0<? extends T> initializer;
    private final Object lock;

    public /* synthetic */ p(Function0 function0) {
        this(function0, (Object) null);
    }

    private p(Function0<? extends T> function0, Object obj) {
        k.h(function0, "initializer");
        this.initializer = function0;
        this._value = s.bjD;
        this.lock = this;
    }

    public final T getValue() {
        T t;
        T t2 = this._value;
        if (t2 != s.bjD) {
            return t2;
        }
        synchronized (this.lock) {
            t = this._value;
            if (t == s.bjD) {
                Function0 function0 = this.initializer;
                if (function0 == null) {
                    k.Em();
                }
                t = function0.invoke();
                this._value = t;
                this.initializer = null;
            }
        }
        return t;
    }

    private final Object writeReplace() {
        return new d(getValue());
    }

    public final String toString() {
        return this._value != s.bjD ? String.valueOf(getValue()) : "Lazy value not initialized yet.";
    }
}
