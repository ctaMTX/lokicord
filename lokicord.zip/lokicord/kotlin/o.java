package kotlin;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.k;

/* compiled from: LazyJVM.kt */
public final class o<T> implements Serializable, Lazy<T> {
    public static final a bjC = new a((byte) 0);
    private static final AtomicReferenceFieldUpdater<o<?>, Object> valueUpdater = AtomicReferenceFieldUpdater.newUpdater(o.class, Object.class, "_value");
    private volatile Object _value = s.bjD;

    /* renamed from: final  reason: not valid java name */
    private final Object f8final = s.bjD;
    private volatile Function0<? extends T> initializer;

    public o(Function0<? extends T> function0) {
        k.h(function0, "initializer");
        this.initializer = function0;
    }

    public final T getValue() {
        T t = this._value;
        if (t != s.bjD) {
            return t;
        }
        Function0<? extends T> function0 = this.initializer;
        if (function0 != null) {
            T invoke = function0.invoke();
            if (valueUpdater.compareAndSet(this, s.bjD, invoke)) {
                this.initializer = null;
                return invoke;
            }
        }
        return this._value;
    }

    private final Object writeReplace() {
        return new d(getValue());
    }

    /* compiled from: LazyJVM.kt */
    public static final class a {
        private a() {
        }

        public /* synthetic */ a(byte b2) {
            this();
        }
    }

    public final String toString() {
        return this._value != s.bjD ? String.valueOf(getValue()) : "Lazy value not initialized yet.";
    }
}
