package kotlin.c;

import java.lang.reflect.Method;
import kotlin.f.b;
import kotlin.f.c;
import kotlin.jvm.internal.k;

/* compiled from: PlatformImplementations.kt */
public class a {

    /* renamed from: kotlin.c.a$a  reason: collision with other inner class name */
    /* compiled from: PlatformImplementations.kt */
    static final class C0116a {
        public static final Method bkv;
        public static final C0116a bkw = new C0116a();

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v3, resolved type: java.lang.Class[]} */
        /* JADX WARNING: type inference failed for: r5v6 */
        /* JADX WARNING: Code restructure failed: missing block: B:9:0x0045, code lost:
            if (kotlin.jvm.internal.k.n((java.lang.Class) r5, r0) != false) goto L_0x0049;
         */
        /* JADX WARNING: Multi-variable type inference failed */
        static {
            /*
                kotlin.c.a$a r0 = new kotlin.c.a$a
                r0.<init>()
                bkw = r0
                java.lang.Class<java.lang.Throwable> r0 = java.lang.Throwable.class
                java.lang.reflect.Method[] r1 = r0.getMethods()
                java.lang.String r2 = "throwableClass.methods"
                kotlin.jvm.internal.k.g(r1, r2)
                int r2 = r1.length
                r3 = 0
                r4 = 0
            L_0x0015:
                r5 = 0
                if (r4 >= r2) goto L_0x0050
                r6 = r1[r4]
                java.lang.String r7 = "it"
                kotlin.jvm.internal.k.g(r6, r7)
                java.lang.String r7 = r6.getName()
                java.lang.String r8 = "addSuppressed"
                boolean r7 = kotlin.jvm.internal.k.n(r7, r8)
                r8 = 1
                if (r7 == 0) goto L_0x0048
                java.lang.Class[] r7 = r6.getParameterTypes()
                java.lang.String r9 = "it.parameterTypes"
                kotlin.jvm.internal.k.g(r7, r9)
                java.lang.String r9 = "$this$singleOrNull"
                kotlin.jvm.internal.k.h(r7, r9)
                int r9 = r7.length
                if (r9 != r8) goto L_0x003f
                r5 = r7[r3]
            L_0x003f:
                java.lang.Class r5 = (java.lang.Class) r5
                boolean r5 = kotlin.jvm.internal.k.n(r5, r0)
                if (r5 == 0) goto L_0x0048
                goto L_0x0049
            L_0x0048:
                r8 = 0
            L_0x0049:
                if (r8 == 0) goto L_0x004d
                r5 = r6
                goto L_0x0050
            L_0x004d:
                int r4 = r4 + 1
                goto L_0x0015
            L_0x0050:
                bkv = r5
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: kotlin.c.a.C0116a.<clinit>():void");
        }

        private C0116a() {
        }
    }

    public void b(Throwable th, Throwable th2) {
        k.h(th, "cause");
        k.h(th2, "exception");
        Method method = C0116a.bkv;
        if (method != null) {
            method.invoke(th, new Object[]{th2});
        }
    }

    public static c Eg() {
        return new b();
    }
}
