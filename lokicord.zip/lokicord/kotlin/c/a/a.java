package kotlin.c.a;

import kotlin.jvm.internal.k;

/* compiled from: JDK7PlatformImplementations.kt */
public class a extends kotlin.c.a {
    public final void b(Throwable th, Throwable th2) {
        k.h(th, "cause");
        k.h(th2, "exception");
    }
}
