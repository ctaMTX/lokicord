package kotlin.c;

/* compiled from: progressionUtil.kt */
public final class c {
    private static final int V(int i, int i2) {
        int i3 = i % i2;
        return i3 >= 0 ? i3 : i3 + i2;
    }

    public static final int k(int i, int i2, int i3) {
        return V(V(i, i3) - V(i2, i3), i3);
    }
}
