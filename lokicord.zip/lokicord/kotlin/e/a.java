package kotlin.e;

public final class a extends c {
}
