package kotlin.e;

/* compiled from: MathH.kt */
class b {
}
