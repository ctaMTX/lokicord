package kotlin;

import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.k;

/* compiled from: LazyJVM.kt */
public class h {
    public static final <T> Lazy<T> b(Function0<? extends T> function0) {
        k.h(function0, "initializer");
        return new p<>(function0);
    }
}
