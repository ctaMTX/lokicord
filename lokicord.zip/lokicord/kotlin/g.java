package kotlin;

public final /* synthetic */ class g {
    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

    static {
        int[] iArr = new int[j.values().length];
        $EnumSwitchMapping$0 = iArr;
        iArr[j.SYNCHRONIZED.ordinal()] = 1;
        $EnumSwitchMapping$0[j.PUBLICATION.ordinal()] = 2;
        $EnumSwitchMapping$0[j.NONE.ordinal()] = 3;
    }
}
