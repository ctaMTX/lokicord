package kotlin;

/* compiled from: TypeCastException.kt */
public final class r extends ClassCastException {
    public r() {
    }

    public r(String str) {
        super(str);
    }
}
