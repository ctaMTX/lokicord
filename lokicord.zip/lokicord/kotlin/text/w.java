package kotlin.text;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import kotlin.a.ao;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.l;
import kotlin.ranges.c;

/* compiled from: _Strings.kt */
public class w extends v {
    public static final char m(CharSequence charSequence) {
        k.h(charSequence, "$this$first");
        if (!(charSequence.length() == 0)) {
            return charSequence.charAt(0);
        }
        throw new NoSuchElementException("Char sequence is empty.");
    }

    public static final String k(String str, int i) {
        k.h(str, "$this$take");
        if (i >= 0) {
            String substring = str.substring(0, c.aa(i, str.length()));
            k.g(substring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
            return substring;
        }
        throw new IllegalArgumentException(("Requested character count " + i + " is less than zero.").toString());
    }

    public static final List<String> b(CharSequence charSequence, int i) {
        k.h(charSequence, "$this$chunked");
        return l.a(charSequence, i, i);
    }

    public static final List<String> a(CharSequence charSequence, int i, int i2) {
        k.h(charSequence, "$this$windowed");
        return l.a(charSequence, i, i2, true, a.bmc);
    }

    public static final <R> List<R> a(CharSequence charSequence, int i, int i2, boolean z, Function1<? super CharSequence, ? extends R> function1) {
        k.h(charSequence, "$this$windowed");
        k.h(function1, "transform");
        ao.U(i, i2);
        int length = charSequence.length();
        ArrayList arrayList = new ArrayList(((length + i2) - 1) / i2);
        int i3 = 0;
        while (i3 < length) {
            int i4 = i3 + i;
            if (i4 > length) {
                i4 = length;
            }
            arrayList.add(function1.invoke(charSequence.subSequence(i3, i4)));
            i3 += i2;
        }
        return arrayList;
    }

    /* compiled from: _Strings.kt */
    static final class a extends l implements Function1<CharSequence, String> {
        public static final a bmc = new a();

        a() {
            super(1);
        }

        public final /* synthetic */ Object invoke(Object obj) {
            CharSequence charSequence = (CharSequence) obj;
            k.h(charSequence, "it");
            return charSequence.toString();
        }
    }
}
