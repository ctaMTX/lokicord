package kotlin.text;

/* compiled from: CharJVM.kt */
class b {
    public static final boolean isWhitespace(char c2) {
        return Character.isWhitespace(c2) || Character.isSpaceChar(c2);
    }
}
