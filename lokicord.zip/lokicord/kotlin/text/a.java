package kotlin.text;

public final class a extends c {
}
