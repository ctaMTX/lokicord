package kotlin.text;

import kotlin.jvm.internal.k;
import kotlin.ranges.IntRange;

/* compiled from: Regex.kt */
public final class f {
    private final IntRange range;
    private final String value;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        return k.n(this.value, fVar.value) && k.n(this.range, fVar.range);
    }

    public final int hashCode() {
        String str = this.value;
        int i = 0;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        IntRange intRange = this.range;
        if (intRange != null) {
            i = intRange.hashCode();
        }
        return hashCode + i;
    }

    public final String toString() {
        return "MatchGroup(value=" + this.value + ", range=" + this.range + ")";
    }

    public f(String str, IntRange intRange) {
        k.h(str, "value");
        k.h(intRange, "range");
        this.value = str;
        this.range = intRange;
    }
}
