package kotlin.text;

/* compiled from: _StringsJvm.kt */
class v extends u {
}
