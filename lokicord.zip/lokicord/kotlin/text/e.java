package kotlin.text;

import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.Pair;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.k;
import kotlin.r;
import kotlin.ranges.IntRange;
import kotlin.ranges.c;
import kotlin.sequences.Sequence;

/* compiled from: Strings.kt */
final class e implements Sequence<IntRange> {
    /* access modifiers changed from: private */
    public final CharSequence blH;
    /* access modifiers changed from: private */
    public final Function2<CharSequence, Integer, Pair<Integer, Integer>> blI;
    /* access modifiers changed from: private */
    public final int limit;
    /* access modifiers changed from: private */
    public final int startIndex;

    public e(CharSequence charSequence, int i, int i2, Function2<? super CharSequence, ? super Integer, Pair<Integer, Integer>> function2) {
        k.h(charSequence, "input");
        k.h(function2, "getNextMatch");
        this.blH = charSequence;
        this.startIndex = i;
        this.limit = i2;
        this.blI = function2;
    }

    /* compiled from: Strings.kt */
    public static final class a implements Iterator<IntRange>, kotlin.jvm.internal.a.a {
        private int blJ;
        private int blK;
        private IntRange blL;
        private int blM;
        final /* synthetic */ e blN;
        private int bll = -1;

        public final void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }

        a(e eVar) {
            this.blN = eVar;
            this.blJ = c.m(eVar.startIndex, 0, eVar.blH.length());
            this.blK = this.blJ;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:7:0x0022, code lost:
            if (r6.blM < kotlin.text.e.a(r6.blN)) goto L_0x0024;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private final void Eu() {
            /*
                r6 = this;
                int r0 = r6.blK
                r1 = 0
                if (r0 >= 0) goto L_0x000b
                r6.bll = r1
                r0 = 0
                r6.blL = r0
                return
            L_0x000b:
                kotlin.text.e r0 = r6.blN
                int r0 = r0.limit
                r2 = -1
                r3 = 1
                if (r0 <= 0) goto L_0x0024
                int r0 = r6.blM
                int r0 = r0 + r3
                r6.blM = r0
                int r0 = r6.blM
                kotlin.text.e r4 = r6.blN
                int r4 = r4.limit
                if (r0 >= r4) goto L_0x0032
            L_0x0024:
                int r0 = r6.blK
                kotlin.text.e r4 = r6.blN
                java.lang.CharSequence r4 = r4.blH
                int r4 = r4.length()
                if (r0 <= r4) goto L_0x0048
            L_0x0032:
                int r0 = r6.blJ
                kotlin.ranges.IntRange r1 = new kotlin.ranges.IntRange
                kotlin.text.e r4 = r6.blN
                java.lang.CharSequence r4 = r4.blH
                int r4 = kotlin.text.l.l(r4)
                r1.<init>(r0, r4)
                r6.blL = r1
                r6.blK = r2
                goto L_0x009b
            L_0x0048:
                kotlin.text.e r0 = r6.blN
                kotlin.jvm.functions.Function2 r0 = r0.blI
                kotlin.text.e r4 = r6.blN
                java.lang.CharSequence r4 = r4.blH
                int r5 = r6.blK
                java.lang.Integer r5 = java.lang.Integer.valueOf(r5)
                java.lang.Object r0 = r0.invoke(r4, r5)
                kotlin.Pair r0 = (kotlin.Pair) r0
                if (r0 != 0) goto L_0x0078
                int r0 = r6.blJ
                kotlin.ranges.IntRange r1 = new kotlin.ranges.IntRange
                kotlin.text.e r4 = r6.blN
                java.lang.CharSequence r4 = r4.blH
                int r4 = kotlin.text.l.l(r4)
                r1.<init>(r0, r4)
                r6.blL = r1
                r6.blK = r2
                goto L_0x009b
            L_0x0078:
                A r2 = r0.first
                java.lang.Number r2 = (java.lang.Number) r2
                int r2 = r2.intValue()
                B r0 = r0.second
                java.lang.Number r0 = (java.lang.Number) r0
                int r0 = r0.intValue()
                int r4 = r6.blJ
                kotlin.ranges.IntRange r4 = kotlin.ranges.c.Y(r4, r2)
                r6.blL = r4
                int r2 = r2 + r0
                r6.blJ = r2
                int r2 = r6.blJ
                if (r0 != 0) goto L_0x0098
                r1 = 1
            L_0x0098:
                int r2 = r2 + r1
                r6.blK = r2
            L_0x009b:
                r6.bll = r3
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: kotlin.text.e.a.Eu():void");
        }

        public final boolean hasNext() {
            if (this.bll == -1) {
                Eu();
            }
            return this.bll == 1;
        }

        public final /* synthetic */ Object next() {
            if (this.bll == -1) {
                Eu();
            }
            if (this.bll != 0) {
                IntRange intRange = this.blL;
                if (intRange != null) {
                    this.blL = null;
                    this.bll = -1;
                    return intRange;
                }
                throw new r("null cannot be cast to non-null type kotlin.ranges.IntRange");
            }
            throw new NoSuchElementException();
        }
    }

    public final Iterator<IntRange> iterator() {
        return new a(this);
    }
}
