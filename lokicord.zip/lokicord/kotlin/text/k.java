package kotlin.text;

/* compiled from: Regex.kt */
public enum k {
    IGNORE_CASE(2),
    MULTILINE(8),
    LITERAL(16),
    UNIX_LINES(1),
    COMMENTS(4),
    DOT_MATCHES_ALL(32),
    CANON_EQ(128);
    
    private final int mask;
    final int value;

    private k(int i, int i2) {
        this.value = i;
        this.mask = i2;
    }
}
