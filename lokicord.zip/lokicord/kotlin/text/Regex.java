package kotlin.text;

import java.io.Serializable;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.j;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.w;
import kotlin.reflect.KDeclarationContainer;
import kotlin.sequences.Sequence;
import kotlin.sequences.i;

/* compiled from: Regex.kt */
public final class Regex implements Serializable {
    public static final a blR = new a((byte) 0);
    private Set<? extends k> _options;
    public final Pattern nativePattern;

    /* compiled from: Regex.kt */
    static final /* synthetic */ class d extends j implements Function1<MatchResult, MatchResult> {
        public static final d blT = new d();

        d() {
            super(1);
        }

        public final String getName() {
            return "next";
        }

        public final KDeclarationContainer getOwner() {
            return w.Q(MatchResult.class);
        }

        public final String getSignature() {
            return "next()Lkotlin/text/MatchResult;";
        }

        public final /* synthetic */ Object invoke(Object obj) {
            MatchResult matchResult = (MatchResult) obj;
            k.h(matchResult, "p1");
            return matchResult.Ex();
        }
    }

    public Regex(Pattern pattern) {
        k.h(pattern, "nativePattern");
        this.nativePattern = pattern;
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public Regex(java.lang.String r2) {
        /*
            r1 = this;
            java.lang.String r0 = "pattern"
            kotlin.jvm.internal.k.h(r2, r0)
            java.util.regex.Pattern r2 = java.util.regex.Pattern.compile(r2)
            java.lang.String r0 = "Pattern.compile(pattern)"
            kotlin.jvm.internal.k.g(r2, r0)
            r1.<init>((java.util.regex.Pattern) r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlin.text.Regex.<init>(java.lang.String):void");
    }

    public final boolean g(CharSequence charSequence) {
        k.h(charSequence, "input");
        return this.nativePattern.matcher(charSequence).matches();
    }

    public final MatchResult a(CharSequence charSequence, int i) {
        k.h(charSequence, "input");
        Matcher matcher = this.nativePattern.matcher(charSequence);
        k.g(matcher, "nativePattern.matcher(input)");
        return j.a(matcher, i, charSequence);
    }

    public final Sequence<MatchResult> h(CharSequence charSequence) {
        k.h(charSequence, "input");
        return i.a(new c(this, charSequence, 0), d.blT);
    }

    public final MatchResult i(CharSequence charSequence) {
        k.h(charSequence, "input");
        Matcher matcher = this.nativePattern.matcher(charSequence);
        k.g(matcher, "nativePattern.matcher(input)");
        return j.a(matcher, charSequence);
    }

    public final String a(CharSequence charSequence, String str) {
        k.h(charSequence, "input");
        k.h(str, "replacement");
        String replaceAll = this.nativePattern.matcher(charSequence).replaceAll(str);
        k.g(replaceAll, "nativePattern.matcher(in…).replaceAll(replacement)");
        return replaceAll;
    }

    public final String toString() {
        String pattern = this.nativePattern.toString();
        k.g(pattern, "nativePattern.toString()");
        return pattern;
    }

    private final Object writeReplace() {
        String pattern = this.nativePattern.pattern();
        k.g(pattern, "nativePattern.pattern()");
        return new b(pattern, this.nativePattern.flags());
    }

    /* compiled from: Regex.kt */
    static final class b implements Serializable {
        public static final a blS = new a((byte) 0);
        private static final long serialVersionUID = 0;
        private final int flags;
        private final String pattern;

        /* compiled from: Regex.kt */
        public static final class a {
            private a() {
            }

            public /* synthetic */ a(byte b2) {
                this();
            }
        }

        public b(String str, int i) {
            k.h(str, "pattern");
            this.pattern = str;
            this.flags = i;
        }

        private final Object readResolve() {
            Pattern compile = Pattern.compile(this.pattern, this.flags);
            k.g(compile, "Pattern.compile(pattern, flags)");
            return new Regex(compile);
        }
    }

    /* compiled from: Regex.kt */
    public static final class a {
        private a() {
        }

        public /* synthetic */ a(byte b2) {
            this();
        }
    }

    /* compiled from: Regex.kt */
    static final class c extends l implements Function0<MatchResult> {
        final /* synthetic */ CharSequence $input;
        final /* synthetic */ int $startIndex = 0;
        final /* synthetic */ Regex this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        c(Regex regex, CharSequence charSequence, int i) {
            super(0);
            this.this$0 = regex;
            this.$input = charSequence;
        }

        public final /* synthetic */ Object invoke() {
            return this.this$0.a(this.$input, this.$startIndex);
        }
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public Regex(java.lang.String r2, kotlin.text.k r3) {
        /*
            r1 = this;
            java.lang.String r0 = "pattern"
            kotlin.jvm.internal.k.h(r2, r0)
            java.lang.String r0 = "option"
            kotlin.jvm.internal.k.h(r3, r0)
            int r3 = r3.value
            r0 = r3 & 2
            if (r0 == 0) goto L_0x0012
            r3 = r3 | 64
        L_0x0012:
            java.util.regex.Pattern r2 = java.util.regex.Pattern.compile(r2, r3)
            java.lang.String r3 = "Pattern.compile(pattern,…nicodeCase(option.value))"
            kotlin.jvm.internal.k.g(r2, r3)
            r1.<init>((java.util.regex.Pattern) r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlin.text.Regex.<init>(java.lang.String, kotlin.text.k):void");
    }
}
