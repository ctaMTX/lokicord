package kotlin.text;

import kotlin.jvm.internal.k;

/* compiled from: StringNumberConversions.kt */
public class s extends r {
    public static final Integer dU(String str) {
        k.h(str, "$this$toIntOrNull");
        return l.dV(str);
    }

    /* JADX WARNING: Removed duplicated region for block: B:18:0x0032 A[LOOP:0: B:18:0x0032->B:29:0x004f, LOOP_START, PHI: r2 r3 
      PHI: (r2v2 int) = (r2v0 int), (r2v4 int) binds: [B:17:0x0030, B:29:0x004f] A[DONT_GENERATE, DONT_INLINE]
      PHI: (r3v2 int) = (r3v1 int), (r3v3 int) binds: [B:17:0x0030, B:29:0x004f] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x0054  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0059  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final java.lang.Integer dV(java.lang.String r8) {
        /*
            java.lang.String r0 = "$this$toIntOrNull"
            kotlin.jvm.internal.k.h(r8, r0)
            int r0 = r8.length()
            r1 = 0
            if (r0 != 0) goto L_0x000d
            return r1
        L_0x000d:
            r2 = 0
            char r3 = r8.charAt(r2)
            r4 = 48
            r5 = -2147483647(0xffffffff80000001, float:-1.4E-45)
            r6 = 1
            if (r3 >= r4) goto L_0x002d
            if (r0 != r6) goto L_0x001d
            return r1
        L_0x001d:
            r4 = 45
            if (r3 != r4) goto L_0x0026
            r5 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = 1
            r4 = 1
            goto L_0x002f
        L_0x0026:
            r4 = 43
            if (r3 != r4) goto L_0x002c
            r3 = 1
            goto L_0x002e
        L_0x002c:
            return r1
        L_0x002d:
            r3 = 0
        L_0x002e:
            r4 = 0
        L_0x002f:
            int r0 = r0 - r6
            if (r3 > r0) goto L_0x0052
        L_0x0032:
            char r6 = r8.charAt(r3)
            r7 = 10
            int r6 = java.lang.Character.digit(r6, r7)
            if (r6 >= 0) goto L_0x003f
            return r1
        L_0x003f:
            r7 = -214748364(0xfffffffff3333334, float:-1.4197688E31)
            if (r2 >= r7) goto L_0x0045
            return r1
        L_0x0045:
            int r2 = r2 * 10
            int r7 = r5 + r6
            if (r2 >= r7) goto L_0x004c
            return r1
        L_0x004c:
            int r2 = r2 - r6
            if (r3 == r0) goto L_0x0052
            int r3 = r3 + 1
            goto L_0x0032
        L_0x0052:
            if (r4 == 0) goto L_0x0059
            java.lang.Integer r8 = java.lang.Integer.valueOf(r2)
            return r8
        L_0x0059:
            int r8 = -r2
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlin.text.s.dV(java.lang.String):java.lang.Integer");
    }

    public static final Long dW(String str) {
        k.h(str, "$this$toLongOrNull");
        return l.dX(str);
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x0035 A[LOOP:0: B:17:0x0035->B:28:0x005b, LOOP_START, PHI: r2 r8 
      PHI: (r2v2 int) = (r2v1 int), (r2v3 int) binds: [B:16:0x0033, B:28:0x005b] A[DONT_GENERATE, DONT_INLINE]
      PHI: (r8v2 long) = (r8v0 long), (r8v4 long) binds: [B:16:0x0033, B:28:0x005b] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x0060  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x0065  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final java.lang.Long dX(java.lang.String r14) {
        /*
            java.lang.String r0 = "$this$toLongOrNull"
            kotlin.jvm.internal.k.h(r14, r0)
            int r0 = r14.length()
            r1 = 0
            if (r0 != 0) goto L_0x000d
            return r1
        L_0x000d:
            r2 = 0
            char r3 = r14.charAt(r2)
            r4 = 48
            r5 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            r7 = 1
            if (r3 >= r4) goto L_0x002f
            if (r0 != r7) goto L_0x001f
            return r1
        L_0x001f:
            r4 = 45
            if (r3 != r4) goto L_0x0028
            r5 = -9223372036854775808
            r2 = 1
            r3 = 1
            goto L_0x0030
        L_0x0028:
            r4 = 43
            if (r3 != r4) goto L_0x002e
            r2 = 1
            goto L_0x002f
        L_0x002e:
            return r1
        L_0x002f:
            r3 = 0
        L_0x0030:
            r8 = 0
            int r0 = r0 - r7
            if (r2 > r0) goto L_0x005e
        L_0x0035:
            char r4 = r14.charAt(r2)
            r7 = 10
            int r4 = java.lang.Character.digit(r4, r7)
            if (r4 >= 0) goto L_0x0042
            return r1
        L_0x0042:
            r10 = -922337203685477580(0xf333333333333334, double:-8.390303882365713E246)
            int r7 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r7 >= 0) goto L_0x004c
            return r1
        L_0x004c:
            r10 = 10
            long r8 = r8 * r10
            long r10 = (long) r4
            long r12 = r5 + r10
            int r4 = (r8 > r12 ? 1 : (r8 == r12 ? 0 : -1))
            if (r4 >= 0) goto L_0x0058
            return r1
        L_0x0058:
            long r8 = r8 - r10
            if (r2 == r0) goto L_0x005e
            int r2 = r2 + 1
            goto L_0x0035
        L_0x005e:
            if (r3 == 0) goto L_0x0065
            java.lang.Long r14 = java.lang.Long.valueOf(r8)
            return r14
        L_0x0065:
            long r0 = -r8
            java.lang.Long r14 = java.lang.Long.valueOf(r0)
            return r14
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlin.text.s.dX(java.lang.String):java.lang.Long");
    }
}
