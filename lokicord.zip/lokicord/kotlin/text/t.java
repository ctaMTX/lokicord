package kotlin.text;

import java.util.Iterator;
import kotlin.a.ab;
import kotlin.jvm.internal.k;
import kotlin.sequences.i;
import kotlin.text.u;

/* compiled from: StringsJVM.kt */
public class t extends s {
    public static final boolean af(String str, String str2) {
        if (str == null) {
            return str2 == null;
        }
        return str.equalsIgnoreCase(str2);
    }

    public static final String a(String str, char c2, char c3, boolean z) {
        k.h(str, "$this$replace");
        String replace = str.replace(c2, c3);
        k.g(replace, "(this as java.lang.Strin…replace(oldChar, newChar)");
        return replace;
    }

    public static final String c(String str, String str2, String str3, boolean z) {
        k.h(str, "$this$replace");
        k.h(str2, "oldValue");
        k.h(str3, "newValue");
        CharSequence charSequence = str;
        String[] strArr = {str2};
        k.h(charSequence, "$this$splitToSequence");
        k.h(strArr, "delimiters");
        return i.a(i.d(u.a(charSequence, strArr, 0, false, 0), new u.c(charSequence)), (CharSequence) str3, (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, 62);
    }

    public static final boolean b(String str, String str2, boolean z) {
        k.h(str, "$this$startsWith");
        k.h(str2, "prefix");
        return str.startsWith(str2);
    }

    public static final boolean c(String str, String str2, boolean z) {
        k.h(str, "$this$endsWith");
        k.h(str2, "suffix");
        return str.endsWith(str2);
    }

    public static final int d(String str, String str2, boolean z) {
        k.h(str, "$this$compareTo");
        k.h(str2, "other");
        if (z) {
            return str.compareToIgnoreCase(str2);
        }
        return str.compareTo(str2);
    }

    public static final boolean j(CharSequence charSequence) {
        boolean z;
        k.h(charSequence, "$this$isBlank");
        if (charSequence.length() != 0) {
            Iterator it = l.k(charSequence).iterator();
            while (true) {
                if (it.hasNext()) {
                    if (!a.isWhitespace(charSequence.charAt(((ab) it).nextInt()))) {
                        z = false;
                        break;
                    }
                } else {
                    z = true;
                    break;
                }
            }
            if (z) {
                return true;
            }
            return false;
        }
        return true;
    }

    public static final boolean a(String str, int i, String str2, int i2, int i3, boolean z) {
        k.h(str, "$this$regionMatches");
        k.h(str2, "other");
        if (!z) {
            return str.regionMatches(i, str2, i2, i3);
        }
        return str.regionMatches(z, i, str2, i2, i3);
    }
}
