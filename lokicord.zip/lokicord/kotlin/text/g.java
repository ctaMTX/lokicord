package kotlin.text;

import java.util.Collection;
import kotlin.jvm.internal.a.a;

/* compiled from: MatchResult.kt */
public interface g extends Collection<f>, a {
}
