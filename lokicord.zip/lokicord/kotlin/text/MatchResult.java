package kotlin.text;

import java.util.List;
import kotlin.ranges.IntRange;

/* compiled from: MatchResult.kt */
public interface MatchResult {
    List<String> Ew();

    MatchResult Ex();

    IntRange getRange();

    String getValue();
}
