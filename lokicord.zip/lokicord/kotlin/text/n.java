package kotlin.text;

/* compiled from: RegexExtensionsJVM.kt */
class n extends m {
}
