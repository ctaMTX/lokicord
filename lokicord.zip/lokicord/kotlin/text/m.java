package kotlin.text;

/* compiled from: Indent.kt */
class m {
}
