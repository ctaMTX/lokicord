package kotlin.text;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;

/* compiled from: StringBuilder.kt */
public class q extends p {
    public static final <T> void a(Appendable appendable, T t, Function1<? super T, ? extends CharSequence> function1) {
        k.h(appendable, "$this$appendElement");
        if (function1 != null) {
            appendable.append((CharSequence) function1.invoke(t));
            return;
        }
        if (t != null ? t instanceof CharSequence : true) {
            appendable.append((CharSequence) t);
        } else if (t instanceof Character) {
            appendable.append(((Character) t).charValue());
        } else {
            appendable.append(String.valueOf(t));
        }
    }
}
