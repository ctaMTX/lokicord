package kotlin.text;

/* compiled from: StringNumberConversionsJVM.kt */
class r extends q {
}
