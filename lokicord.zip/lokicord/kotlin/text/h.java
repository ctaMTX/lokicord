package kotlin.text;

public interface h extends g {
}
