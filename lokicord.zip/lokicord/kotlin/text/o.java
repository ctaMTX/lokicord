package kotlin.text;

/* compiled from: RegexExtensions.kt */
class o extends n {
}
