package kotlin.text;

import java.util.regex.Matcher;

/* compiled from: Regex.kt */
public final class j {
    static final MatchResult a(Matcher matcher, int i, CharSequence charSequence) {
        if (!matcher.find(i)) {
            return null;
        }
        return new i(matcher, charSequence);
    }

    static final MatchResult a(Matcher matcher, CharSequence charSequence) {
        if (!matcher.matches()) {
            return null;
        }
        return new i(matcher, charSequence);
    }
}
