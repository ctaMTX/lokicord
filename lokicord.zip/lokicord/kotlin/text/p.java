package kotlin.text;

/* compiled from: StringBuilderJVM.kt */
class p extends o {
}
