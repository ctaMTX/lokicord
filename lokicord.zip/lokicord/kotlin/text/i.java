package kotlin.text;

import java.util.Iterator;
import java.util.List;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import kotlin.a.d;
import kotlin.a.m;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.l;
import kotlin.ranges.IntRange;
import kotlin.ranges.c;

/* compiled from: Regex.kt */
final class i implements MatchResult {
    private final CharSequence blH;
    private final g blO = new b(this);
    private List<String> blP;
    /* access modifiers changed from: private */
    public final Matcher matcher;

    public i(Matcher matcher2, CharSequence charSequence) {
        k.h(matcher2, "matcher");
        k.h(charSequence, "input");
        this.matcher = matcher2;
        this.blH = charSequence;
    }

    /* compiled from: Regex.kt */
    public static final class b extends kotlin.a.a<f> implements h {
        final /* synthetic */ i blQ;

        public final boolean isEmpty() {
            return false;
        }

        /* compiled from: Regex.kt */
        static final class a extends l implements Function1<Integer, f> {
            final /* synthetic */ b this$0;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            a(b bVar) {
                super(1);
                this.this$0 = bVar;
            }

            public final /* synthetic */ Object invoke(Object obj) {
                int intValue = ((Number) obj).intValue();
                b bVar = this.this$0;
                MatchResult a2 = bVar.blQ.matcher;
                IntRange Y = c.Y(a2.start(intValue), a2.end(intValue));
                if (Y.bkP < 0) {
                    return null;
                }
                String group = bVar.blQ.matcher.group(intValue);
                k.g(group, "matchResult.group(index)");
                return new f(group, Y);
            }
        }

        b(i iVar) {
            this.blQ = iVar;
        }

        public final /* bridge */ boolean contains(Object obj) {
            boolean z;
            if (obj != null) {
                z = obj instanceof f;
            } else {
                z = true;
            }
            if (!z) {
                return false;
            }
            return super.contains((f) obj);
        }

        public final int getSize() {
            return this.blQ.matcher.groupCount() + 1;
        }

        public final Iterator<f> iterator() {
            return kotlin.sequences.i.d(m.x(m.f(this)), new a(this)).iterator();
        }
    }

    /* compiled from: Regex.kt */
    public static final class a extends d<String> {
        final /* synthetic */ i blQ;

        a(i iVar) {
            this.blQ = iVar;
        }

        public final /* bridge */ boolean contains(Object obj) {
            if (!(obj instanceof String)) {
                return false;
            }
            return super.contains((String) obj);
        }

        public final /* bridge */ int indexOf(Object obj) {
            if (!(obj instanceof String)) {
                return -1;
            }
            return super.indexOf((String) obj);
        }

        public final /* bridge */ int lastIndexOf(Object obj) {
            if (!(obj instanceof String)) {
                return -1;
            }
            return super.lastIndexOf((String) obj);
        }

        public final int getSize() {
            return this.blQ.matcher.groupCount() + 1;
        }

        public final /* synthetic */ Object get(int i) {
            String group = this.blQ.matcher.group(i);
            return group == null ? "" : group;
        }
    }

    public final List<String> Ew() {
        if (this.blP == null) {
            this.blP = new a(this);
        }
        List<String> list = this.blP;
        if (list == null) {
            k.Em();
        }
        return list;
    }

    public final IntRange getRange() {
        MatchResult matchResult = this.matcher;
        return c.Y(matchResult.start(), matchResult.end());
    }

    public final String getValue() {
        String group = this.matcher.group();
        k.g(group, "matchResult.group()");
        return group;
    }

    public final MatchResult Ex() {
        int end = this.matcher.end() + (this.matcher.end() == this.matcher.start() ? 1 : 0);
        if (end > this.blH.length()) {
            return null;
        }
        Matcher matcher2 = this.matcher.pattern().matcher(this.blH);
        k.g(matcher2, "matcher.pattern().matcher(input)");
        return j.a(matcher2, end, this.blH);
    }
}
