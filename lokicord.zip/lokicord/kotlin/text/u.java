package kotlin.text;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Pair;
import kotlin.a.g;
import kotlin.a.m;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.l;
import kotlin.q;
import kotlin.ranges.IntProgression;
import kotlin.ranges.IntRange;
import kotlin.sequences.Sequence;
import kotlin.sequences.i;

/* compiled from: Strings.kt */
public class u extends t {
    public static final IntRange k(CharSequence charSequence) {
        k.h(charSequence, "$this$indices");
        return new IntRange(0, charSequence.length() - 1);
    }

    public static final int l(CharSequence charSequence) {
        k.h(charSequence, "$this$lastIndex");
        return charSequence.length() - 1;
    }

    public static final String a(String str, char c2, String str2) {
        k.h(str, "$this$substringBefore");
        k.h(str2, "missingDelimiterValue");
        int a2 = l.a((CharSequence) str, c2, 0, false, 6);
        if (a2 == -1) {
            return str2;
        }
        String substring = str.substring(0, a2);
        k.g(substring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
        return substring;
    }

    public static /* synthetic */ String ag(String str, String str2) {
        k.h(str, "$this$substringAfter");
        k.h(str2, "delimiter");
        k.h(str, "missingDelimiterValue");
        int a2 = l.a((CharSequence) str, str2, 0, false, 6);
        if (a2 == -1) {
            return str;
        }
        String substring = str.substring(a2 + str2.length(), str.length());
        k.g(substring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
        return substring;
    }

    public static final String b(String str, char c2, String str2) {
        k.h(str, "$this$substringAfterLast");
        k.h(str2, "missingDelimiterValue");
        int a2 = l.b((CharSequence) str, c2, l.l(str), false);
        if (a2 == -1) {
            return str2;
        }
        String substring = str.substring(a2 + 1, str.length());
        k.g(substring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
        return substring;
    }

    public static final boolean a(CharSequence charSequence, CharSequence charSequence2, int i, int i2, boolean z) {
        k.h(charSequence, "$this$regionMatchesImpl");
        k.h(charSequence2, "other");
        if (i < 0 || charSequence.length() - i2 < 0 || i > charSequence2.length() - i2) {
            return false;
        }
        for (int i3 = 0; i3 < i2; i3++) {
            if (!a.a(charSequence.charAt(i3 + 0), charSequence2.charAt(i + i3), z)) {
                return false;
            }
        }
        return true;
    }

    public static final int a(CharSequence charSequence, char[] cArr, int i, boolean z) {
        boolean z2;
        k.h(charSequence, "$this$indexOfAny");
        k.h(cArr, "chars");
        if (z || cArr.length != 1 || !(charSequence instanceof String)) {
            int Z = kotlin.ranges.c.Z(i, 0);
            int l = l.l(charSequence);
            if (Z > l) {
                return -1;
            }
            while (true) {
                char charAt = charSequence.charAt(Z);
                int length = cArr.length;
                int i2 = 0;
                while (true) {
                    if (i2 >= length) {
                        z2 = false;
                        break;
                    } else if (a.a(cArr[i2], charAt, z)) {
                        z2 = true;
                        break;
                    } else {
                        i2++;
                    }
                }
                if (z2) {
                    return Z;
                }
                if (Z == l) {
                    return -1;
                }
                Z++;
            }
        } else {
            return ((String) charSequence).indexOf(g.a(cArr), i);
        }
    }

    public static final int a(CharSequence charSequence, CharSequence charSequence2, int i, int i2, boolean z, boolean z2) {
        IntProgression intProgression;
        if (!z2) {
            intProgression = new IntRange(kotlin.ranges.c.Z(i, 0), kotlin.ranges.c.aa(i2, charSequence.length()));
        } else {
            intProgression = kotlin.ranges.c.X(kotlin.ranges.c.aa(i, l.l(charSequence)), kotlin.ranges.c.Z(i2, 0));
        }
        if (!(charSequence instanceof String) || !(charSequence2 instanceof String)) {
            int i3 = intProgression.bkP;
            int i4 = intProgression.bkQ;
            int i5 = intProgression.bkR;
            if (i5 >= 0) {
                if (i3 > i4) {
                    return -1;
                }
            } else if (i3 < i4) {
                return -1;
            }
            while (!l.a(charSequence2, charSequence, i3, charSequence2.length(), z)) {
                if (i3 == i4) {
                    return -1;
                }
                i3 += i5;
            }
            return i3;
        }
        int i6 = intProgression.bkP;
        int i7 = intProgression.bkQ;
        int i8 = intProgression.bkR;
        if (i8 >= 0) {
            if (i6 > i7) {
                return -1;
            }
        } else if (i6 < i7) {
            return -1;
        }
        while (true) {
            if (l.a((String) charSequence2, 0, (String) charSequence, i6, charSequence2.length(), z)) {
                return i6;
            }
            if (i6 == i7) {
                return -1;
            }
            i6 += i8;
        }
    }

    public static /* synthetic */ int a(CharSequence charSequence, char c2, int i, boolean z, int i2) {
        if ((i2 & 2) != 0) {
            i = 0;
        }
        if ((i2 & 4) != 0) {
            z = false;
        }
        return l.a(charSequence, c2, i, z);
    }

    public static final int a(CharSequence charSequence, char c2, int i, boolean z) {
        k.h(charSequence, "$this$indexOf");
        if (!z && (charSequence instanceof String)) {
            return ((String) charSequence).indexOf(c2, i);
        }
        return l.a(charSequence, new char[]{c2}, i, z);
    }

    public static /* synthetic */ int a(CharSequence charSequence, String str, int i, boolean z, int i2) {
        if ((i2 & 2) != 0) {
            i = 0;
        }
        if ((i2 & 4) != 0) {
            z = false;
        }
        return l.a(charSequence, str, i, z);
    }

    public static final int a(CharSequence charSequence, String str, int i, boolean z) {
        k.h(charSequence, "$this$indexOf");
        k.h(str, "string");
        if (z || !(charSequence instanceof String)) {
            return a(charSequence, str, i, charSequence.length(), z, false);
        }
        return ((String) charSequence).indexOf(str, i);
    }

    public static final int b(CharSequence charSequence, char c2, int i, boolean z) {
        boolean z2;
        k.h(charSequence, "$this$lastIndexOf");
        boolean z3 = charSequence instanceof String;
        if (z3) {
            return ((String) charSequence).lastIndexOf(c2, i);
        }
        char[] cArr = {c2};
        k.h(charSequence, "$this$lastIndexOfAny");
        k.h(cArr, "chars");
        if (z3) {
            return ((String) charSequence).lastIndexOf(g.a(cArr), i);
        }
        for (int aa = kotlin.ranges.c.aa(i, l.l(charSequence)); aa >= 0; aa--) {
            char charAt = charSequence.charAt(aa);
            int i2 = 0;
            while (true) {
                if (i2 > 0) {
                    z2 = false;
                    break;
                } else if (a.a(cArr[i2], charAt, false)) {
                    z2 = true;
                    break;
                } else {
                    i2++;
                }
            }
            if (z2) {
                return aa;
            }
        }
        return -1;
    }

    public static final boolean a(CharSequence charSequence, CharSequence charSequence2, boolean z) {
        k.h(charSequence, "$this$contains");
        k.h(charSequence2, "other");
        return charSequence2 instanceof String ? l.a(charSequence, (String) charSequence2, 0, z, 2) >= 0 : a(charSequence, charSequence2, 0, charSequence.length(), z, false) >= 0;
    }

    public static final boolean a(CharSequence charSequence, char c2, boolean z) {
        k.h(charSequence, "$this$contains");
        return l.a(charSequence, c2, 0, false, 2) >= 0;
    }

    /* access modifiers changed from: private */
    public static final Sequence<IntRange> a(CharSequence charSequence, String[] strArr, int i, boolean z, int i2) {
        if (i2 >= 0) {
            return new e(charSequence, 0, i2, new b(g.asList(strArr), z));
        }
        throw new IllegalArgumentException(("Limit must be non-negative, but was " + i2 + '.').toString());
    }

    public static final List<String> b(CharSequence charSequence, String[] strArr, boolean z, int i) {
        k.h(charSequence, "$this$split");
        k.h(strArr, "delimiters");
        boolean z2 = true;
        if (strArr.length == 1) {
            String str = strArr[0];
            if (str.length() != 0) {
                z2 = false;
            }
            if (!z2) {
                return a(charSequence, str, false, 0);
            }
        }
        Iterable<IntRange> j = i.j(a(charSequence, strArr, 0, false, 0));
        Collection arrayList = new ArrayList(m.a(j, 10));
        for (IntRange a2 : j) {
            arrayList.add(l.a(charSequence, a2));
        }
        return (List) arrayList;
    }

    public static /* synthetic */ List a(CharSequence charSequence, char[] cArr, int i, int i2) {
        if ((i2 & 4) != 0) {
            i = 0;
        }
        return l.a(charSequence, cArr, false, i);
    }

    public static final List<String> a(CharSequence charSequence, char[] cArr, boolean z, int i) {
        k.h(charSequence, "$this$split");
        k.h(cArr, "delimiters");
        boolean z2 = true;
        if (cArr.length == 1) {
            return a(charSequence, String.valueOf(cArr[0]), false, i);
        }
        if (i < 0) {
            z2 = false;
        }
        if (z2) {
            Iterable<IntRange> j = i.j(new e(charSequence, 0, i, new a(cArr, false)));
            Collection arrayList = new ArrayList(m.a(j, 10));
            for (IntRange a2 : j) {
                arrayList.add(l.a(charSequence, a2));
            }
            return (List) arrayList;
        }
        throw new IllegalArgumentException(("Limit must be non-negative, but was " + i + '.').toString());
    }

    private static final List<String> a(CharSequence charSequence, String str, boolean z, int i) {
        int i2 = 0;
        if (i >= 0) {
            int a2 = l.a(charSequence, str, 0, z);
            if (a2 == -1 || i == 1) {
                return m.ba(charSequence.toString());
            }
            boolean z2 = i > 0;
            int i3 = 10;
            if (z2) {
                i3 = kotlin.ranges.c.aa(i, 10);
            }
            ArrayList arrayList = new ArrayList(i3);
            do {
                arrayList.add(charSequence.subSequence(i2, a2).toString());
                i2 = str.length() + a2;
                if ((z2 && arrayList.size() == i - 1) || (a2 = l.a(charSequence, str, i2, z)) == -1) {
                    arrayList.add(charSequence.subSequence(i2, charSequence.length()).toString());
                }
                arrayList.add(charSequence.subSequence(i2, a2).toString());
                i2 = str.length() + a2;
                break;
            } while ((a2 = l.a(charSequence, str, i2, z)) == -1);
            arrayList.add(charSequence.subSequence(i2, charSequence.length()).toString());
            return arrayList;
        }
        throw new IllegalArgumentException(("Limit must be non-negative, but was " + i + '.').toString());
    }

    public static final CharSequence trim(CharSequence charSequence) {
        k.h(charSequence, "$this$trim");
        int length = charSequence.length() - 1;
        int i = 0;
        boolean z = false;
        while (i <= length) {
            boolean isWhitespace = a.isWhitespace(charSequence.charAt(!z ? i : length));
            if (z) {
                if (!isWhitespace) {
                    break;
                }
                length--;
            } else if (!isWhitespace) {
                z = true;
            } else {
                i++;
            }
        }
        return charSequence.subSequence(i, length + 1);
    }

    public static final String a(CharSequence charSequence, IntRange intRange) {
        k.h(charSequence, "$this$substring");
        k.h(intRange, "range");
        return charSequence.subSequence(intRange.bkP, intRange.bkQ + 1).toString();
    }

    /* compiled from: Strings.kt */
    static final class a extends l implements Function2<CharSequence, Integer, Pair<? extends Integer, ? extends Integer>> {
        final /* synthetic */ char[] $delimiters;
        final /* synthetic */ boolean $ignoreCase;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(char[] cArr, boolean z) {
            super(2);
            this.$delimiters = cArr;
            this.$ignoreCase = z;
        }

        public final /* synthetic */ Object invoke(Object obj, Object obj2) {
            CharSequence charSequence = (CharSequence) obj;
            int intValue = ((Number) obj2).intValue();
            k.h(charSequence, "$receiver");
            int a2 = l.a(charSequence, this.$delimiters, intValue, this.$ignoreCase);
            if (a2 < 0) {
                return null;
            }
            return q.m(Integer.valueOf(a2), 1);
        }
    }

    /* compiled from: Strings.kt */
    static final class b extends l implements Function2<CharSequence, Integer, Pair<? extends Integer, ? extends Integer>> {
        final /* synthetic */ List $delimitersList;
        final /* synthetic */ boolean $ignoreCase;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        b(List list, boolean z) {
            super(2);
            this.$delimitersList = list;
            this.$ignoreCase = z;
        }

        /* JADX WARNING: Removed duplicated region for block: B:60:0x0126  */
        /* JADX WARNING: Removed duplicated region for block: B:62:0x0139 A[RETURN] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final /* synthetic */ java.lang.Object invoke(java.lang.Object r14, java.lang.Object r15) {
            /*
                r13 = this;
                java.lang.CharSequence r14 = (java.lang.CharSequence) r14
                java.lang.Number r15 = (java.lang.Number) r15
                int r15 = r15.intValue()
                java.lang.String r0 = "$receiver"
                kotlin.jvm.internal.k.h(r14, r0)
                java.util.List r0 = r13.$delimitersList
                java.util.Collection r0 = (java.util.Collection) r0
                boolean r7 = r13.$ignoreCase
                r1 = 0
                r8 = 0
                if (r7 != 0) goto L_0x008b
                int r2 = r0.size()
                r3 = 1
                if (r2 != r3) goto L_0x008b
                java.lang.Iterable r0 = (java.lang.Iterable) r0
                java.lang.String r2 = "$this$single"
                kotlin.jvm.internal.k.h(r0, r2)
                boolean r4 = r0 instanceof java.util.List
                if (r4 == 0) goto L_0x004f
                java.util.List r0 = (java.util.List) r0
                kotlin.jvm.internal.k.h(r0, r2)
                int r2 = r0.size()
                if (r2 == 0) goto L_0x0045
                if (r2 != r3) goto L_0x003b
                java.lang.Object r0 = r0.get(r1)
                goto L_0x0064
            L_0x003b:
                java.lang.IllegalArgumentException r14 = new java.lang.IllegalArgumentException
                java.lang.String r15 = "List has more than one element."
                r14.<init>(r15)
                java.lang.Throwable r14 = (java.lang.Throwable) r14
                throw r14
            L_0x0045:
                java.util.NoSuchElementException r14 = new java.util.NoSuchElementException
                java.lang.String r15 = "List is empty."
                r14.<init>(r15)
                java.lang.Throwable r14 = (java.lang.Throwable) r14
                throw r14
            L_0x004f:
                java.util.Iterator r0 = r0.iterator()
                boolean r2 = r0.hasNext()
                if (r2 == 0) goto L_0x0081
                java.lang.Object r2 = r0.next()
                boolean r0 = r0.hasNext()
                if (r0 != 0) goto L_0x0077
                r0 = r2
            L_0x0064:
                java.lang.String r0 = (java.lang.String) r0
                r2 = 4
                int r14 = kotlin.text.l.a((java.lang.CharSequence) r14, (java.lang.String) r0, (int) r15, (boolean) r1, (int) r2)
                if (r14 < 0) goto L_0x0123
                java.lang.Integer r14 = java.lang.Integer.valueOf(r14)
                kotlin.Pair r14 = kotlin.q.m(r14, r0)
                goto L_0x0124
            L_0x0077:
                java.lang.IllegalArgumentException r14 = new java.lang.IllegalArgumentException
                java.lang.String r15 = "Collection has more than one element."
                r14.<init>(r15)
                java.lang.Throwable r14 = (java.lang.Throwable) r14
                throw r14
            L_0x0081:
                java.util.NoSuchElementException r14 = new java.util.NoSuchElementException
                java.lang.String r15 = "Collection is empty."
                r14.<init>(r15)
                java.lang.Throwable r14 = (java.lang.Throwable) r14
                throw r14
            L_0x008b:
                int r15 = kotlin.ranges.c.Z(r15, r1)
                kotlin.ranges.IntRange r1 = new kotlin.ranges.IntRange
                int r2 = r14.length()
                r1.<init>(r15, r2)
                kotlin.ranges.IntProgression r1 = (kotlin.ranges.IntProgression) r1
                boolean r15 = r14 instanceof java.lang.String
                if (r15 == 0) goto L_0x00e2
                int r15 = r1.bkP
                int r9 = r1.bkQ
                int r10 = r1.bkR
                if (r10 < 0) goto L_0x00a9
                if (r15 > r9) goto L_0x0123
                goto L_0x00ab
            L_0x00a9:
                if (r15 < r9) goto L_0x0123
            L_0x00ab:
                r1 = r0
                java.lang.Iterable r1 = (java.lang.Iterable) r1
                java.util.Iterator r11 = r1.iterator()
            L_0x00b2:
                boolean r1 = r11.hasNext()
                if (r1 == 0) goto L_0x00d0
                java.lang.Object r12 = r11.next()
                r1 = r12
                java.lang.String r1 = (java.lang.String) r1
                r2 = 0
                r3 = r14
                java.lang.String r3 = (java.lang.String) r3
                int r5 = r1.length()
                r4 = r15
                r6 = r7
                boolean r1 = kotlin.text.l.a(r1, r2, r3, r4, r5, r6)
                if (r1 == 0) goto L_0x00b2
                goto L_0x00d1
            L_0x00d0:
                r12 = r8
            L_0x00d1:
                java.lang.String r12 = (java.lang.String) r12
                if (r12 == 0) goto L_0x00de
                java.lang.Integer r14 = java.lang.Integer.valueOf(r15)
                kotlin.Pair r14 = kotlin.q.m(r14, r12)
                goto L_0x0124
            L_0x00de:
                if (r15 == r9) goto L_0x0123
                int r15 = r15 + r10
                goto L_0x00ab
            L_0x00e2:
                int r15 = r1.bkP
                int r2 = r1.bkQ
                int r1 = r1.bkR
                if (r1 < 0) goto L_0x00ed
                if (r15 > r2) goto L_0x0123
                goto L_0x00ef
            L_0x00ed:
                if (r15 < r2) goto L_0x0123
            L_0x00ef:
                r3 = r0
                java.lang.Iterable r3 = (java.lang.Iterable) r3
                java.util.Iterator r3 = r3.iterator()
            L_0x00f6:
                boolean r4 = r3.hasNext()
                if (r4 == 0) goto L_0x0111
                java.lang.Object r4 = r3.next()
                r5 = r4
                java.lang.String r5 = (java.lang.String) r5
                r6 = r5
                java.lang.CharSequence r6 = (java.lang.CharSequence) r6
                int r5 = r5.length()
                boolean r5 = kotlin.text.l.a((java.lang.CharSequence) r6, (java.lang.CharSequence) r14, (int) r15, (int) r5, (boolean) r7)
                if (r5 == 0) goto L_0x00f6
                goto L_0x0112
            L_0x0111:
                r4 = r8
            L_0x0112:
                java.lang.String r4 = (java.lang.String) r4
                if (r4 == 0) goto L_0x011f
                java.lang.Integer r14 = java.lang.Integer.valueOf(r15)
                kotlin.Pair r14 = kotlin.q.m(r14, r4)
                goto L_0x0124
            L_0x011f:
                if (r15 == r2) goto L_0x0123
                int r15 = r15 + r1
                goto L_0x00ef
            L_0x0123:
                r14 = r8
            L_0x0124:
                if (r14 == 0) goto L_0x0139
                A r15 = r14.first
                B r14 = r14.second
                java.lang.String r14 = (java.lang.String) r14
                int r14 = r14.length()
                java.lang.Integer r14 = java.lang.Integer.valueOf(r14)
                kotlin.Pair r14 = kotlin.q.m(r15, r14)
                return r14
            L_0x0139:
                return r8
            */
            throw new UnsupportedOperationException("Method not decompiled: kotlin.text.u.b.invoke(java.lang.Object, java.lang.Object):java.lang.Object");
        }
    }

    /* compiled from: Strings.kt */
    static final class c extends l implements Function1<IntRange, String> {
        final /* synthetic */ CharSequence $this_splitToSequence;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        c(CharSequence charSequence) {
            super(1);
            this.$this_splitToSequence = charSequence;
        }

        public final /* synthetic */ Object invoke(Object obj) {
            IntRange intRange = (IntRange) obj;
            k.h(intRange, "it");
            return l.a(this.$this_splitToSequence, intRange);
        }
    }
}
