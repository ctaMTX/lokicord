package kotlin.text;

public final class l extends w {
    private l() {
    }
}
