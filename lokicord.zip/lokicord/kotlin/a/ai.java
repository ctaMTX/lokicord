package kotlin.a;

import java.util.List;
import kotlin.jvm.internal.k;
import kotlin.ranges.IntRange;

/* compiled from: ReversedViews.kt */
public final class ai<T> extends e<T> {
    private final List<T> bjW;

    public ai(List<T> list) {
        k.h(list, "delegate");
        this.bjW = list;
    }

    public final int getSize() {
        return this.bjW.size();
    }

    public final T get(int i) {
        return this.bjW.get(u.c(this, i));
    }

    public final void clear() {
        this.bjW.clear();
    }

    public final T removeAt(int i) {
        return this.bjW.remove(u.c(this, i));
    }

    public final T set(int i, T t) {
        return this.bjW.set(u.c(this, i), t);
    }

    public final void add(int i, T t) {
        List<T> list = this.bjW;
        int size = size();
        if (i < 0 || size < i) {
            throw new IndexOutOfBoundsException("Position index " + i + " must be in range [" + new IntRange(0, size()) + "].");
        }
        list.add(size() - i, t);
    }
}
