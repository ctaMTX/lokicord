package kotlin.a;

public final class ad extends ah {
}
