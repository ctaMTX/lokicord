package kotlin.a;

import java.util.Iterator;
import kotlin.jvm.internal.a.a;

/* compiled from: Iterators.kt */
public abstract class ac implements Iterator<Long>, a {
    public abstract long nextLong();

    public void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final Long next() {
        return Long.valueOf(nextLong());
    }
}
