package kotlin.a;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import kotlin.jvm.internal.a.a;
import kotlin.jvm.internal.b;
import kotlin.jvm.internal.k;

/* compiled from: Collections.kt */
final class f<T> implements Collection<T>, a {
    private final T[] bjO;
    private final boolean bjP;

    public final boolean add(T t) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final boolean addAll(Collection<? extends T> collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final void clear() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final boolean remove(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final boolean removeAll(Collection<? extends Object> collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final boolean retainAll(Collection<? extends Object> collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final <T> T[] toArray(T[] tArr) {
        return kotlin.jvm.internal.f.a(this, tArr);
    }

    public f(T[] tArr, boolean z) {
        k.h(tArr, "values");
        this.bjO = tArr;
        this.bjP = z;
    }

    public final boolean isEmpty() {
        return this.bjO.length == 0;
    }

    public final boolean contains(Object obj) {
        T[] tArr = this.bjO;
        k.h(tArr, "$this$contains");
        return g.b(tArr, obj) >= 0;
    }

    public final boolean containsAll(Collection<? extends Object> collection) {
        k.h(collection, "elements");
        Iterable<Object> iterable = collection;
        if (((Collection) iterable).isEmpty()) {
            return true;
        }
        for (Object contains : iterable) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    public final Iterator<T> iterator() {
        return b.q(this.bjO);
    }

    public final Object[] toArray() {
        T[] tArr = this.bjO;
        boolean z = this.bjP;
        k.h(tArr, "$this$copyToArrayOfAny");
        if (z && k.n(tArr.getClass(), Object[].class)) {
            return tArr;
        }
        Object[] copyOf = Arrays.copyOf(tArr, tArr.length, Object[].class);
        k.g(copyOf, "java.util.Arrays.copyOf(… Array<Any?>::class.java)");
        return copyOf;
    }

    public final /* bridge */ int size() {
        return this.bjO.length;
    }
}
