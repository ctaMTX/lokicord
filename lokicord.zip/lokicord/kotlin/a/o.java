package kotlin.a;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.jvm.internal.k;
import kotlin.ranges.IntRange;

/* compiled from: Collections.kt */
public class o extends n {
    public static final <T> Collection<T> k(T[] tArr) {
        k.h(tArr, "$this$asCollection");
        return new f<>(tArr, false);
    }

    public static final <T> List<T> l(T... tArr) {
        k.h(tArr, "elements");
        return tArr.length > 0 ? g.asList(tArr) : y.bjT;
    }

    public static final <T> List<T> m(T... tArr) {
        k.h(tArr, "elements");
        return tArr.length == 0 ? new ArrayList<>() : new ArrayList<>(new f(tArr, true));
    }

    public static final <T> ArrayList<T> n(T... tArr) {
        k.h(tArr, "elements");
        return tArr.length == 0 ? new ArrayList<>() : new ArrayList<>(new f(tArr, true));
    }

    public static final <T> List<T> o(T... tArr) {
        k.h(tArr, "elements");
        return g.f(tArr);
    }

    public static final IntRange f(Collection<?> collection) {
        k.h(collection, "$this$indices");
        return new IntRange(0, collection.size() - 1);
    }

    public static final <T> int Y(List<? extends T> list) {
        k.h(list, "$this$lastIndex");
        return list.size() - 1;
    }

    public static final <T> List<T> Z(List<? extends T> list) {
        k.h(list, "$this$optimizeReadOnlyList");
        int size = list.size();
        if (size == 0) {
            return y.bjT;
        }
        if (size != 1) {
            return list;
        }
        return m.ba(list.get(0));
    }

    public static final void DY() {
        throw new ArithmeticException("Index overflow has happened.");
    }

    public static final void DZ() {
        throw new ArithmeticException("Count overflow has happened.");
    }
}
