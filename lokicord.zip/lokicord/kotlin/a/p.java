package kotlin.a;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import kotlin.jvm.internal.k;

/* compiled from: Iterables.kt */
public class p extends o {
    public static final <T> int a(Iterable<? extends T> iterable, int i) {
        k.h(iterable, "$this$collectionSizeOrDefault");
        return iterable instanceof Collection ? ((Collection) iterable).size() : i;
    }

    private static final <T> boolean g(Collection<? extends T> collection) {
        return collection.size() > 2 && (collection instanceof ArrayList);
    }

    public static final <T> Collection<T> a(Iterable<? extends T> iterable, Iterable<? extends T> iterable2) {
        k.h(iterable, "$this$convertToSetForSetOperationWith");
        k.h(iterable2, "source");
        if (iterable instanceof Set) {
            return (Collection) iterable;
        }
        if (iterable instanceof Collection) {
            if ((iterable2 instanceof Collection) && ((Collection) iterable2).size() < 2) {
                return (Collection) iterable;
            }
            Collection<T> collection = (Collection) iterable;
            if (!g(collection)) {
                return collection;
            }
        }
        return m.q(iterable);
    }

    public static final <T> List<T> k(Iterable<? extends Iterable<? extends T>> iterable) {
        k.h(iterable, "$this$flatten");
        ArrayList arrayList = new ArrayList();
        for (Iterable a2 : iterable) {
            m.a(arrayList, a2);
        }
        return arrayList;
    }
}
