package kotlin.a;

public final class m extends w {
}
