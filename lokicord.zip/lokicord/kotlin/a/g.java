package kotlin.a;

public final class g extends k {
}
