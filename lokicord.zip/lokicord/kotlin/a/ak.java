package kotlin.a;

public final class ak extends an {
}
