package kotlin.a;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import kotlin.jvm.internal.b;
import kotlin.ranges.IntRange;
import kotlin.sequences.Sequence;
import kotlin.sequences.e;

/* compiled from: _Arrays.kt */
public class k extends j {

    /* compiled from: Sequences.kt */
    public static final class a implements Sequence<T> {
        final /* synthetic */ Object[] bjQ;

        public a(Object[] objArr) {
            this.bjQ = objArr;
        }

        public final Iterator<T> iterator() {
            return b.q(this.bjQ);
        }
    }

    public static final <T> T d(T[] tArr) {
        kotlin.jvm.internal.k.h(tArr, "$this$firstOrNull");
        if (tArr.length == 0) {
            return null;
        }
        return tArr[0];
    }

    public static final <T> int b(T[] tArr, T t) {
        kotlin.jvm.internal.k.h(tArr, "$this$indexOf");
        int i = 0;
        if (t == null) {
            int length = tArr.length;
            while (i < length) {
                if (tArr[i] == null) {
                    return i;
                }
                i++;
            }
            return -1;
        }
        int length2 = tArr.length;
        while (i < length2) {
            if (kotlin.jvm.internal.k.n(t, tArr[i])) {
                return i;
            }
            i++;
        }
        return -1;
    }

    public static final <T> T e(T[] tArr) {
        kotlin.jvm.internal.k.h(tArr, "$this$last");
        if (!(tArr.length == 0)) {
            return tArr[g.g(tArr)];
        }
        throw new NoSuchElementException("Array is empty.");
    }

    public static final char a(char[] cArr) {
        kotlin.jvm.internal.k.h(cArr, "$this$single");
        int length = cArr.length;
        if (length == 0) {
            throw new NoSuchElementException("Array is empty.");
        } else if (length == 1) {
            return cArr[0];
        } else {
            throw new IllegalArgumentException("Array has more than one element.");
        }
    }

    public static final <T> List<T> f(T[] tArr) {
        kotlin.jvm.internal.k.h(tArr, "$this$filterNotNull");
        return (List) g.a(tArr, new ArrayList());
    }

    public static final <C extends Collection<? super T>, T> C a(T[] tArr, C c2) {
        kotlin.jvm.internal.k.h(tArr, "$this$filterNotNullTo");
        kotlin.jvm.internal.k.h(c2, "destination");
        for (T t : tArr) {
            if (t != null) {
                c2.add(t);
            }
        }
        return c2;
    }

    public static final IntRange h(int[] iArr) {
        kotlin.jvm.internal.k.h(iArr, "$this$indices");
        return new IntRange(0, g.i(iArr));
    }

    public static final <T> int g(T[] tArr) {
        kotlin.jvm.internal.k.h(tArr, "$this$lastIndex");
        return tArr.length - 1;
    }

    public static final int i(int[] iArr) {
        kotlin.jvm.internal.k.h(iArr, "$this$lastIndex");
        return iArr.length - 1;
    }

    public static final <T, C extends Collection<? super T>> C b(T[] tArr, C c2) {
        kotlin.jvm.internal.k.h(tArr, "$this$toCollection");
        kotlin.jvm.internal.k.h(c2, "destination");
        for (T add : tArr) {
            c2.add(add);
        }
        return c2;
    }

    public static final <C extends Collection<? super Long>> C a(long[] jArr, C c2) {
        kotlin.jvm.internal.k.h(jArr, "$this$toCollection");
        kotlin.jvm.internal.k.h(c2, "destination");
        for (long valueOf : jArr) {
            c2.add(Long.valueOf(valueOf));
        }
        return c2;
    }

    public static final <T> List<T> h(T[] tArr) {
        kotlin.jvm.internal.k.h(tArr, "$this$toMutableList");
        return new ArrayList<>(m.k(tArr));
    }

    public static final List<Integer> j(int[] iArr) {
        kotlin.jvm.internal.k.h(iArr, "$this$toMutableList");
        ArrayList arrayList = new ArrayList(iArr.length);
        for (int valueOf : iArr) {
            arrayList.add(Integer.valueOf(valueOf));
        }
        return arrayList;
    }

    public static final <T> Set<T> i(T[] tArr) {
        kotlin.jvm.internal.k.h(tArr, "$this$toSet");
        int length = tArr.length;
        if (length == 0) {
            return aa.bjV;
        }
        if (length != 1) {
            return (Set) g.b(tArr, new LinkedHashSet(ad.dm(tArr.length)));
        }
        return ak.bb(tArr[0]);
    }

    public static final <T> Sequence<T> j(T[] tArr) {
        kotlin.jvm.internal.k.h(tArr, "$this$asSequence");
        if (tArr.length == 0) {
            return e.bli;
        }
        return new a(tArr);
    }
}
