package kotlin.a;

/* compiled from: Arrays.kt */
class i extends h {
}
