package kotlin.a;

import java.util.Map;
import kotlin.jvm.internal.k;
import kotlin.sequences.Sequence;

/* compiled from: _Maps.kt */
public class ah extends ag {
    public static final <K, V> Sequence<Map.Entry<K, V>> t(Map<? extends K, ? extends V> map) {
        k.h(map, "$this$asSequence");
        return m.x(map.entrySet());
    }
}
