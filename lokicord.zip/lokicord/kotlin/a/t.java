package kotlin.a;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.RandomAccess;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.aa;
import kotlin.jvm.internal.k;
import kotlin.r;
import kotlin.sequences.Sequence;

/* compiled from: MutableCollections.kt */
public class t extends s {
    public static final <T> boolean a(Collection<? super T> collection, Iterable<? extends T> iterable) {
        k.h(collection, "$this$addAll");
        k.h(iterable, "elements");
        if (iterable instanceof Collection) {
            return collection.addAll((Collection) iterable);
        }
        boolean z = false;
        for (Object add : iterable) {
            if (collection.add(add)) {
                z = true;
            }
        }
        return z;
    }

    public static final <T> boolean a(Collection<? super T> collection, Sequence<? extends T> sequence) {
        k.h(collection, "$this$addAll");
        k.h(sequence, "elements");
        boolean z = false;
        for (Object add : sequence) {
            if (collection.add(add)) {
                z = true;
            }
        }
        return z;
    }

    public static final <T> boolean a(Iterable<? extends T> iterable, Function1<? super T, Boolean> function1, boolean z) {
        Iterator<? extends T> it = iterable.iterator();
        boolean z2 = false;
        while (it.hasNext()) {
            if (function1.invoke(it.next()).booleanValue()) {
                it.remove();
                z2 = true;
            }
        }
        return z2;
    }

    public static final <T> boolean a(List<T> list, Function1<? super T, Boolean> function1) {
        k.h(list, "$this$removeAll");
        k.h(function1, "predicate");
        return b(list, function1);
    }

    private static final <T> boolean b(List<T> list, Function1<? super T, Boolean> function1) {
        int i;
        if (list instanceof RandomAccess) {
            int Y = m.Y(list);
            if (Y >= 0) {
                int i2 = 0;
                i = 0;
                while (true) {
                    T t = list.get(i2);
                    if (!function1.invoke(t).booleanValue()) {
                        if (i != i2) {
                            list.set(i, t);
                        }
                        i++;
                    }
                    if (i2 == Y) {
                        break;
                    }
                    i2++;
                }
            } else {
                i = 0;
            }
            if (i >= list.size()) {
                return false;
            }
            int Y2 = m.Y(list);
            if (Y2 >= i) {
                while (true) {
                    list.remove(Y2);
                    if (Y2 == i) {
                        break;
                    }
                    Y2--;
                }
            }
            return true;
        } else if (list != null) {
            return a(aa.bc(list), function1, true);
        } else {
            throw new r("null cannot be cast to non-null type kotlin.collections.MutableIterable<T>");
        }
    }
}
