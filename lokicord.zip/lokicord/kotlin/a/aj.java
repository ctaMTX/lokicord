package kotlin.a;

import java.util.List;
import kotlin.jvm.internal.k;

/* compiled from: ReversedViews.kt */
final class aj<T> extends d<T> {
    private final List<T> bjW;

    public aj(List<? extends T> list) {
        k.h(list, "delegate");
        this.bjW = list;
    }

    public final int getSize() {
        return this.bjW.size();
    }

    public final T get(int i) {
        return this.bjW.get(u.c(this, i));
    }
}
