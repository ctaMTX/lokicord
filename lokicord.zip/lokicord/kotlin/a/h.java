package kotlin.a;

/* compiled from: ArraysJVM.kt */
class h {
}
