package kotlin.a;

import java.util.Collections;
import java.util.List;
import kotlin.jvm.internal.k;

/* compiled from: CollectionsJVM.kt */
public class n {
    public static final <T> List<T> ba(T t) {
        List<T> singletonList = Collections.singletonList(t);
        k.g(singletonList, "java.util.Collections.singletonList(element)");
        return singletonList;
    }
}
