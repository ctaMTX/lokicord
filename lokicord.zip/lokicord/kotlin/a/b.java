package kotlin.a;

import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.jvm.internal.a.a;

/* compiled from: AbstractIterator.kt */
public abstract class b<T> implements Iterator<T>, a {
    protected int bjH = ap.bjY;
    protected T bjI;

    /* access modifiers changed from: protected */
    public abstract void DX();

    public void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean hasNext() {
        if (this.bjH != ap.bka) {
            int i = c.$EnumSwitchMapping$0[this.bjH - 1];
            if (i == 1) {
                return false;
            }
            if (i == 2) {
                return true;
            }
            this.bjH = ap.bka;
            DX();
            return this.bjH == ap.bjX;
        }
        throw new IllegalArgumentException("Failed requirement.".toString());
    }

    public T next() {
        if (hasNext()) {
            this.bjH = ap.bjY;
            return this.bjI;
        }
        throw new NoSuchElementException();
    }
}
