package kotlin.a;

import androidx.appcompat.widget.ActivityChooserView;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.Pair;
import kotlin.jvm.internal.k;
import kotlin.r;

/* compiled from: Maps.kt */
public class ag extends af {
    public static final <K, V> Map<K, V> emptyMap() {
        z zVar = z.bjU;
        if (zVar != null) {
            return zVar;
        }
        throw new r("null cannot be cast to non-null type kotlin.collections.Map<K, V>");
    }

    public static final <K, V> Map<K, V> a(Pair<? extends K, ? extends V>... pairArr) {
        k.h(pairArr, "pairs");
        return pairArr.length > 0 ? ad.a(pairArr, new LinkedHashMap(ad.dm(pairArr.length))) : ad.emptyMap();
    }

    public static final <K, V> Map<K, V> b(Pair<? extends K, ? extends V>... pairArr) {
        k.h(pairArr, "pairs");
        Map<K, V> linkedHashMap = new LinkedHashMap<>(ad.dm(pairArr.length));
        ad.a(linkedHashMap, pairArr);
        return linkedHashMap;
    }

    public static final int dm(int i) {
        if (i < 3) {
            return i + 1;
        }
        return i < 1073741824 ? i + (i / 3) : ActivityChooserView.ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
    }

    public static final <K, V> void a(Map<? super K, ? super V> map, Pair<? extends K, ? extends V>[] pairArr) {
        k.h(map, "$this$putAll");
        k.h(pairArr, "pairs");
        for (Pair<? extends K, ? extends V> pair : pairArr) {
            map.put(pair.first, pair.second);
        }
    }

    public static final <K, V, M extends Map<? super K, ? super V>> M a(Pair<? extends K, ? extends V>[] pairArr, M m) {
        k.h(pairArr, "$this$toMap");
        k.h(m, "destination");
        ad.a(m, pairArr);
        return m;
    }

    public static final <K, V> Map<K, V> r(Map<? extends K, ? extends V> map) {
        k.h(map, "$this$toMutableMap");
        return new LinkedHashMap<>(map);
    }

    public static final <K, V> Map<K, V> a(Map<? extends K, ? extends V> map, Pair<? extends K, ? extends V> pair) {
        k.h(map, "$this$plus");
        k.h(pair, "pair");
        if (map.isEmpty()) {
            return ad.a(pair);
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(map);
        linkedHashMap.put(pair.first, pair.second);
        return linkedHashMap;
    }

    public static final <K, V> Map<K, V> a(Map<? extends K, ? extends V> map, Map<? extends K, ? extends V> map2) {
        k.h(map, "$this$plus");
        k.h(map2, "map");
        LinkedHashMap linkedHashMap = new LinkedHashMap(map);
        linkedHashMap.putAll(map2);
        return linkedHashMap;
    }

    public static final <K, V> Map<K, V> s(Map<K, ? extends V> map) {
        k.h(map, "$this$optimizeReadOnlyMap");
        int size = map.size();
        if (size == 0) {
            return ad.emptyMap();
        }
        if (size != 1) {
            return map;
        }
        return ad.q(map);
    }
}
