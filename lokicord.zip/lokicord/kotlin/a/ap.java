package kotlin.a;

/* compiled from: AbstractIterator.kt */
public final class ap extends Enum<ap> {
    public static final int bjX = 1;
    public static final int bjY = 2;
    public static final int bjZ = 3;
    public static final int bka = 4;
    private static final /* synthetic */ int[] bkb = {1, 2, 3, 4};

    public static int[] Ea() {
        return (int[]) bkb.clone();
    }
}
