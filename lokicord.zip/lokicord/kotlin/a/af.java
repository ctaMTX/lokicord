package kotlin.a;

import java.util.Collections;
import java.util.Map;
import kotlin.Pair;
import kotlin.jvm.internal.k;

/* compiled from: MapsJVM.kt */
public class af extends ae {
    public static final <K, V> Map<K, V> q(Map<? extends K, ? extends V> map) {
        k.h(map, "$this$toSingletonMap");
        Map.Entry next = map.entrySet().iterator().next();
        Map<K, V> singletonMap = Collections.singletonMap(next.getKey(), next.getValue());
        k.g(singletonMap, "java.util.Collections.singletonMap(key, value)");
        k.g(singletonMap, "with(entries.iterator().…ingletonMap(key, value) }");
        return singletonMap;
    }

    public static final <K, V> Map<K, V> a(Pair<? extends K, ? extends V> pair) {
        k.h(pair, "pair");
        Map<K, V> singletonMap = Collections.singletonMap(pair.first, pair.second);
        k.g(singletonMap, "java.util.Collections.si…(pair.first, pair.second)");
        return singletonMap;
    }
}
