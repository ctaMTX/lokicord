package kotlin.a;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import java.util.RandomAccess;
import kotlin.jvm.internal.k;

/* compiled from: AbstractList.kt */
public abstract class d<E> extends a<E> implements List<E>, kotlin.jvm.internal.a.a {
    public static final a bjJ = new a((byte) 0);

    public void add(int i, E e) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean addAll(int i, Collection<? extends E> collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public abstract E get(int i);

    public E remove(int i) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public E set(int i, E e) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    protected d() {
    }

    public Iterator<E> iterator() {
        return new b();
    }

    public ListIterator<E> listIterator() {
        return new c(0);
    }

    public ListIterator<E> listIterator(int i) {
        return new c(i);
    }

    public List<E> subList(int i, int i2) {
        return new C0114d<>(this, i, i2);
    }

    /* renamed from: kotlin.a.d$d  reason: collision with other inner class name */
    /* compiled from: AbstractList.kt */
    static final class C0114d<E> extends d<E> implements RandomAccess {
        private int bjL;
        private final d<E> bjM;
        private final int bjN;

        public C0114d(d<? extends E> dVar, int i, int i2) {
            k.h(dVar, "list");
            this.bjM = dVar;
            this.bjN = i;
            int i3 = this.bjN;
            int size = this.bjM.size();
            if (i3 < 0 || i2 > size) {
                throw new IndexOutOfBoundsException("fromIndex: " + i3 + ", toIndex: " + i2 + ", size: " + size);
            } else if (i3 <= i2) {
                this.bjL = i2 - this.bjN;
            } else {
                throw new IllegalArgumentException("fromIndex: " + i3 + " > toIndex: " + i2);
            }
        }

        public final E get(int i) {
            int i2 = this.bjL;
            if (i >= 0 && i < i2) {
                return this.bjM.get(this.bjN + i);
            }
            throw new IndexOutOfBoundsException("index: " + i + ", size: " + i2);
        }

        public final int getSize() {
            return this.bjL;
        }
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof List)) {
            return false;
        }
        Collection<Object> collection = this;
        Collection collection2 = (Collection) obj;
        k.h(collection, "c");
        k.h(collection2, "other");
        if (collection.size() != collection2.size()) {
            return false;
        }
        Iterator it = collection2.iterator();
        for (Object n : collection) {
            if (!k.n(n, it.next())) {
                return false;
            }
        }
        return true;
    }

    public int hashCode() {
        Collection collection = this;
        k.h(collection, "c");
        Iterator it = collection.iterator();
        int i = 1;
        while (it.hasNext()) {
            Object next = it.next();
            i = (i * 31) + (next != null ? next.hashCode() : 0);
        }
        return i;
    }

    /* compiled from: AbstractList.kt */
    class b implements Iterator<E>, kotlin.jvm.internal.a.a {
        int index;

        public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }

        public b() {
        }

        public boolean hasNext() {
            return this.index < d.this.size();
        }

        public E next() {
            if (hasNext()) {
                d dVar = d.this;
                int i = this.index;
                this.index = i + 1;
                return dVar.get(i);
            }
            throw new NoSuchElementException();
        }
    }

    /* compiled from: AbstractList.kt */
    class c extends d<E>.b implements ListIterator<E>, kotlin.jvm.internal.a.a {
        public final void add(E e) {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }

        public final void set(E e) {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }

        public c(int i) {
            super();
            a aVar = d.bjJ;
            int size = d.this.size();
            if (i < 0 || i > size) {
                throw new IndexOutOfBoundsException("index: " + i + ", size: " + size);
            }
            this.index = i;
        }

        public final E previous() {
            if (hasPrevious()) {
                this.index--;
                return d.this.get(this.index);
            }
            throw new NoSuchElementException();
        }

        public final boolean hasPrevious() {
            return this.index > 0;
        }

        public final int nextIndex() {
            return this.index;
        }

        public final int previousIndex() {
            return this.index - 1;
        }
    }

    /* compiled from: AbstractList.kt */
    public static final class a {
        private a() {
        }

        public /* synthetic */ a(byte b2) {
            this();
        }
    }

    public int indexOf(Object obj) {
        int i = 0;
        for (Object n : this) {
            if (k.n(n, obj)) {
                return i;
            }
            i++;
        }
        return -1;
    }

    public int lastIndexOf(Object obj) {
        ListIterator listIterator = listIterator(size());
        while (listIterator.hasPrevious()) {
            if (k.n(listIterator.previous(), obj)) {
                return listIterator.nextIndex();
            }
        }
        return -1;
    }
}
