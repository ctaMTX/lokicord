package kotlin.a;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import kotlin.jvm.internal.k;

/* compiled from: MutableCollectionsJVM.kt */
public class s extends r {
    public static final <T extends Comparable<? super T>> void sort(List<T> list) {
        k.h(list, "$this$sort");
        if (list.size() > 1) {
            Collections.sort(list);
        }
    }

    public static final <T> void a(List<T> list, Comparator<? super T> comparator) {
        k.h(list, "$this$sortWith");
        k.h(comparator, "comparator");
        if (list.size() > 1) {
            Collections.sort(list, comparator);
        }
    }
}
