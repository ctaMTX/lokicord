package kotlin.a;

import java.util.AbstractList;
import java.util.List;

/* compiled from: AbstractMutableList.kt */
public abstract class e<E> extends AbstractList<E> implements List<E>, kotlin.jvm.internal.a.e {
    public abstract int getSize();

    public abstract E removeAt(int i);

    protected e() {
    }

    public final E remove(int i) {
        return removeAt(i);
    }

    public final int size() {
        return getSize();
    }
}
