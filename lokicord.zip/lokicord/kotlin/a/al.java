package kotlin.a;

import java.util.Collections;
import java.util.Set;
import kotlin.jvm.internal.k;

/* compiled from: SetsJVM.kt */
public class al {
    public static final <T> Set<T> bb(T t) {
        Set<T> singleton = Collections.singleton(t);
        k.g(singleton, "java.util.Collections.singleton(element)");
        return singleton;
    }
}
