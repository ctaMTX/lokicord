package kotlin.a;

/* compiled from: Iterators.kt */
class r extends q {
}
