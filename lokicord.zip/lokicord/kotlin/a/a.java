package kotlin.a;

import java.util.Collection;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.f;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.l;
import kotlin.r;

/* compiled from: AbstractCollection.kt */
public abstract class a<E> implements Collection<E>, kotlin.jvm.internal.a.a {
    public boolean add(E e) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean addAll(Collection<? extends E> collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public void clear() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public abstract int getSize();

    public boolean remove(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean removeAll(Collection<? extends Object> collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean retainAll(Collection<? extends Object> collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    protected a() {
    }

    public final int size() {
        return getSize();
    }

    public boolean containsAll(Collection<? extends Object> collection) {
        k.h(collection, "elements");
        Iterable<Object> iterable = collection;
        if (((Collection) iterable).isEmpty()) {
            return true;
        }
        for (Object contains : iterable) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public String toString() {
        return m.a((Iterable) this, (CharSequence) ", ", (CharSequence) "[", (CharSequence) "]", 0, (CharSequence) null, (Function1) new C0113a(this), 24);
    }

    public Object[] toArray() {
        return f.k(this);
    }

    public <T> T[] toArray(T[] tArr) {
        k.h(tArr, "array");
        T[] a2 = f.a(this, tArr);
        if (a2 != null) {
            return a2;
        }
        throw new r("null cannot be cast to non-null type kotlin.Array<T>");
    }

    public boolean contains(Object obj) {
        if (isEmpty()) {
            return false;
        }
        for (Object n : this) {
            if (k.n(n, obj)) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: kotlin.a.a$a  reason: collision with other inner class name */
    /* compiled from: AbstractCollection.kt */
    static final class C0113a extends l implements Function1<E, CharSequence> {
        final /* synthetic */ a this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        C0113a(a aVar) {
            super(1);
            this.this$0 = aVar;
        }

        public final /* synthetic */ Object invoke(Object obj) {
            return obj == this.this$0 ? "(this Collection)" : String.valueOf(obj);
        }
    }
}
