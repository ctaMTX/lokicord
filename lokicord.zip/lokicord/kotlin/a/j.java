package kotlin.a;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import kotlin.jvm.internal.k;

/* compiled from: _ArraysJvm.kt */
public class j extends i {
    public static final <T> void sort(T[] tArr) {
        k.h(tArr, "$this$sort");
        if (tArr.length > 1) {
            Arrays.sort(tArr);
        }
    }

    public static final <T> void a(T[] tArr, Comparator<? super T> comparator) {
        k.h(tArr, "$this$sortWith");
        k.h(comparator, "comparator");
        if (tArr.length > 1) {
            Arrays.sort(tArr, comparator);
        }
    }

    public static final <T> List<T> asList(T[] tArr) {
        k.h(tArr, "$this$asList");
        List<T> asList = Arrays.asList(tArr);
        k.g(asList, "ArraysUtilJVM.asList(this)");
        return asList;
    }
}
