package kotlin.a;

import java.util.Collections;
import java.util.List;
import kotlin.jvm.internal.k;

/* compiled from: _CollectionsJvm.kt */
public class v extends u {
    public static final <T> void reverse(List<T> list) {
        k.h(list, "$this$reverse");
        Collections.reverse(list);
    }
}
