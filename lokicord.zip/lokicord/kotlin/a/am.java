package kotlin.a;

import java.util.Set;
import kotlin.jvm.internal.k;

/* compiled from: Sets.kt */
public class am extends al {
    public static final <T> Set<T> p(T... tArr) {
        k.h(tArr, "elements");
        return tArr.length > 0 ? g.i(tArr) : aa.bjV;
    }

    public static final <T> Set<T> e(Set<? extends T> set) {
        k.h(set, "$this$optimizeReadOnlySet");
        int size = set.size();
        if (size == 0) {
            return aa.bjV;
        }
        if (size != 1) {
            return set;
        }
        return ak.bb(set.iterator().next());
    }
}
