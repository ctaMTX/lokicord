package kotlin.a;

import java.util.List;
import kotlin.jvm.internal.k;
import kotlin.ranges.IntRange;

/* compiled from: ReversedViews.kt */
public class u extends t {
    public static final <T> List<T> aa(List<? extends T> list) {
        k.h(list, "$this$asReversed");
        return new aj<>(list);
    }

    public static final /* synthetic */ int c(List list, int i) {
        int Y = m.Y(list);
        if (i >= 0 && Y >= i) {
            return m.Y(list) - i;
        }
        throw new IndexOutOfBoundsException("Element index " + i + " must be in range [" + new IntRange(0, m.Y(list)) + "].");
    }
}
