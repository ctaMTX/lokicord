package kotlin.a;

/* compiled from: IteratorsJVM.kt */
class q extends p {
}
