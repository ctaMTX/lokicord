package kotlin.a;

public final /* synthetic */ class c {
    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

    static {
        int[] iArr = new int[ap.Ea().length];
        $EnumSwitchMapping$0 = iArr;
        iArr[ap.bjZ - 1] = 1;
        $EnumSwitchMapping$0[ap.bjX - 1] = 2;
    }
}
