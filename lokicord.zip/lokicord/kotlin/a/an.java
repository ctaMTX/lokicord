package kotlin.a;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;
import kotlin.jvm.internal.k;

/* compiled from: _Sets.kt */
public class an extends am {
    public static final <T> Set<T> a(Set<? extends T> set, Iterable<? extends T> iterable) {
        k.h(set, "$this$minus");
        k.h(iterable, "elements");
        Iterable iterable2 = set;
        Collection<? extends T> a2 = m.a(iterable, (Iterable<? extends T>) iterable2);
        if (a2.isEmpty()) {
            return m.t(iterable2);
        }
        if (a2 instanceof Set) {
            Collection linkedHashSet = new LinkedHashSet();
            for (Object next : iterable2) {
                if (!a2.contains(next)) {
                    linkedHashSet.add(next);
                }
            }
            return (Set) linkedHashSet;
        }
        LinkedHashSet linkedHashSet2 = new LinkedHashSet(set);
        linkedHashSet2.removeAll(a2);
        return linkedHashSet2;
    }

    public static final <T> Set<T> a(Set<? extends T> set, T t) {
        k.h(set, "$this$plus");
        LinkedHashSet linkedHashSet = new LinkedHashSet(ad.dm(set.size() + 1));
        linkedHashSet.addAll(set);
        linkedHashSet.add(t);
        return linkedHashSet;
    }
}
