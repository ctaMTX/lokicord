package kotlin.a;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.RandomAccess;
import java.util.Set;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.k;
import kotlin.r;
import kotlin.sequences.Sequence;
import kotlin.text.l;

/* compiled from: _Collections.kt */
public class w extends v {

    /* compiled from: Sequences.kt */
    public static final class a implements Sequence<T> {
        final /* synthetic */ Iterable bjR;

        public a(Iterable iterable) {
            this.bjR = iterable;
        }

        public final Iterator<T> iterator() {
            return this.bjR.iterator();
        }
    }

    public static final <T> boolean a(Iterable<? extends T> iterable, T t) {
        k.h(iterable, "$this$contains");
        if (iterable instanceof Collection) {
            return ((Collection) iterable).contains(t);
        }
        return m.b(iterable, t) >= 0;
    }

    public static final <T> T l(Iterable<? extends T> iterable) {
        k.h(iterable, "$this$first");
        if (iterable instanceof List) {
            return m.ab((List) iterable);
        }
        Iterator<? extends T> it = iterable.iterator();
        if (it.hasNext()) {
            return it.next();
        }
        throw new NoSuchElementException("Collection is empty.");
    }

    public static final <T> T ab(List<? extends T> list) {
        k.h(list, "$this$first");
        if (!list.isEmpty()) {
            return list.get(0);
        }
        throw new NoSuchElementException("List is empty.");
    }

    public static final <T> T ac(List<? extends T> list) {
        k.h(list, "$this$firstOrNull");
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    public static final <T> T d(List<? extends T> list, int i) {
        k.h(list, "$this$getOrNull");
        if (i < 0 || i > m.Y(list)) {
            return null;
        }
        return list.get(i);
    }

    public static final <T> int b(Iterable<? extends T> iterable, T t) {
        k.h(iterable, "$this$indexOf");
        if (iterable instanceof List) {
            return ((List) iterable).indexOf(t);
        }
        int i = 0;
        for (Object next : iterable) {
            if (i < 0) {
                m.DY();
            }
            if (k.n(t, next)) {
                return i;
            }
            i++;
        }
        return -1;
    }

    public static final <T> T m(Iterable<? extends T> iterable) {
        T next;
        k.h(iterable, "$this$last");
        if (iterable instanceof List) {
            return m.ad((List) iterable);
        }
        Iterator<? extends T> it = iterable.iterator();
        if (it.hasNext()) {
            do {
                next = it.next();
            } while (it.hasNext());
            return next;
        }
        throw new NoSuchElementException("Collection is empty.");
    }

    public static final <T> T ad(List<? extends T> list) {
        k.h(list, "$this$last");
        if (!list.isEmpty()) {
            return list.get(m.Y(list));
        }
        throw new NoSuchElementException("List is empty.");
    }

    public static final <T> T ae(List<? extends T> list) {
        k.h(list, "$this$lastOrNull");
        if (list.isEmpty()) {
            return null;
        }
        return list.get(list.size() - 1);
    }

    public static final <T> List<T> b(Iterable<? extends T> iterable, int i) {
        ArrayList arrayList;
        k.h(iterable, "$this$drop");
        int i2 = 0;
        if (!(i >= 0)) {
            throw new IllegalArgumentException(("Requested element count " + i + " is less than zero.").toString());
        } else if (i == 0) {
            return m.r(iterable);
        } else {
            if (iterable instanceof Collection) {
                Collection collection = (Collection) iterable;
                int size = collection.size() - i;
                if (size <= 0) {
                    return y.bjT;
                }
                if (size == 1) {
                    return m.ba(m.m(iterable));
                }
                arrayList = new ArrayList(size);
                if (iterable instanceof List) {
                    if (iterable instanceof RandomAccess) {
                        int size2 = collection.size();
                        while (i < size2) {
                            arrayList.add(((List) iterable).get(i));
                            i++;
                        }
                    } else {
                        Iterator listIterator = ((List) iterable).listIterator(i);
                        while (listIterator.hasNext()) {
                            arrayList.add(listIterator.next());
                        }
                    }
                    return arrayList;
                }
            } else {
                arrayList = new ArrayList();
            }
            for (Object next : iterable) {
                if (i2 >= i) {
                    arrayList.add(next);
                } else {
                    i2++;
                }
            }
            return m.Z(arrayList);
        }
    }

    public static final <T> List<T> n(Iterable<? extends T> iterable) {
        k.h(iterable, "$this$filterNotNull");
        return (List) m.a(iterable, new ArrayList());
    }

    public static final <C extends Collection<? super T>, T> C a(Iterable<? extends T> iterable, C c2) {
        k.h(iterable, "$this$filterNotNullTo");
        k.h(c2, "destination");
        for (Object next : iterable) {
            if (next != null) {
                c2.add(next);
            }
        }
        return c2;
    }

    public static final <T> List<T> o(Iterable<? extends T> iterable) {
        k.h(iterable, "$this$reversed");
        if ((iterable instanceof Collection) && ((Collection) iterable).size() <= 1) {
            return m.r(iterable);
        }
        List<T> s = m.s(iterable);
        m.reverse(s);
        return s;
    }

    public static final <T extends Comparable<? super T>> List<T> p(Iterable<? extends T> iterable) {
        k.h(iterable, "$this$sorted");
        Collection collection = (Collection) iterable;
        if (collection.size() <= 1) {
            return m.r(iterable);
        }
        Object[] array = collection.toArray(new Comparable[0]);
        if (array == null) {
            throw new r("null cannot be cast to non-null type kotlin.Array<T>");
        } else if (array != null) {
            Comparable[] comparableArr = (Comparable[]) array;
            if (comparableArr != null) {
                Object[] objArr = (Object[]) comparableArr;
                g.sort(objArr);
                return g.asList(objArr);
            }
            throw new r("null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
        } else {
            throw new r("null cannot be cast to non-null type kotlin.Array<T>");
        }
    }

    public static final <T> List<T> a(Iterable<? extends T> iterable, Comparator<? super T> comparator) {
        k.h(iterable, "$this$sortedWith");
        k.h(comparator, "comparator");
        if (iterable instanceof Collection) {
            Collection collection = (Collection) iterable;
            if (collection.size() <= 1) {
                return m.r(iterable);
            }
            Object[] array = collection.toArray(new Object[0]);
            if (array == null) {
                throw new r("null cannot be cast to non-null type kotlin.Array<T>");
            } else if (array != null) {
                g.a(array, comparator);
                return g.asList(array);
            } else {
                throw new r("null cannot be cast to non-null type kotlin.Array<T>");
            }
        } else {
            List<T> s = m.s(iterable);
            m.a(s, comparator);
            return s;
        }
    }

    public static final int[] h(Collection<Integer> collection) {
        k.h(collection, "$this$toIntArray");
        int[] iArr = new int[collection.size()];
        int i = 0;
        for (Integer intValue : collection) {
            iArr[i] = intValue.intValue();
            i++;
        }
        return iArr;
    }

    public static final long[] i(Collection<Long> collection) {
        k.h(collection, "$this$toLongArray");
        long[] jArr = new long[collection.size()];
        int i = 0;
        for (Long longValue : collection) {
            jArr[i] = longValue.longValue();
            i++;
        }
        return jArr;
    }

    public static final <T, C extends Collection<? super T>> C b(Iterable<? extends T> iterable, C c2) {
        k.h(iterable, "$this$toCollection");
        k.h(c2, "destination");
        for (Object add : iterable) {
            c2.add(add);
        }
        return c2;
    }

    public static final <T> HashSet<T> q(Iterable<? extends T> iterable) {
        k.h(iterable, "$this$toHashSet");
        return (HashSet) m.b(iterable, new HashSet(ad.dm(m.a(iterable, 12))));
    }

    public static final <T> List<T> r(Iterable<? extends T> iterable) {
        k.h(iterable, "$this$toList");
        if (!(iterable instanceof Collection)) {
            return m.Z(m.s(iterable));
        }
        Collection collection = (Collection) iterable;
        int size = collection.size();
        if (size == 0) {
            return y.bjT;
        }
        if (size != 1) {
            return m.j(collection);
        }
        return m.ba(iterable instanceof List ? ((List) iterable).get(0) : iterable.iterator().next());
    }

    public static final <T> List<T> s(Iterable<? extends T> iterable) {
        k.h(iterable, "$this$toMutableList");
        if (iterable instanceof Collection) {
            return m.j((Collection) iterable);
        }
        return (List) m.b(iterable, new ArrayList());
    }

    public static final <T> List<T> j(Collection<? extends T> collection) {
        k.h(collection, "$this$toMutableList");
        return new ArrayList<>(collection);
    }

    public static final <T> Set<T> t(Iterable<? extends T> iterable) {
        k.h(iterable, "$this$toSet");
        if (!(iterable instanceof Collection)) {
            return ak.e((Set) m.b(iterable, new LinkedHashSet()));
        }
        Collection collection = (Collection) iterable;
        int size = collection.size();
        if (size == 0) {
            return aa.bjV;
        }
        if (size != 1) {
            return (Set) m.b(iterable, new LinkedHashSet(ad.dm(collection.size())));
        }
        return ak.bb(iterable instanceof List ? ((List) iterable).get(0) : iterable.iterator().next());
    }

    public static final <T> List<T> u(Iterable<? extends T> iterable) {
        k.h(iterable, "$this$distinct");
        return m.r(m.v(iterable));
    }

    public static final <T> Set<T> v(Iterable<? extends T> iterable) {
        k.h(iterable, "$this$toMutableSet");
        if (iterable instanceof Collection) {
            return new LinkedHashSet<>((Collection) iterable);
        }
        return (Set) m.b(iterable, new LinkedHashSet());
    }

    public static final <T extends Comparable<? super T>> T w(Iterable<? extends T> iterable) {
        k.h(iterable, "$this$max");
        Iterator<? extends T> it = iterable.iterator();
        if (!it.hasNext()) {
            return null;
        }
        T t = (Comparable) it.next();
        while (it.hasNext()) {
            T t2 = (Comparable) it.next();
            if (t.compareTo(t2) < 0) {
                t = t2;
            }
        }
        return t;
    }

    public static final <T> List<T> b(Iterable<? extends T> iterable, Iterable<? extends T> iterable2) {
        k.h(iterable, "$this$minus");
        k.h(iterable2, "elements");
        Collection<? extends T> a2 = m.a(iterable2, iterable);
        if (a2.isEmpty()) {
            return m.r(iterable);
        }
        Collection arrayList = new ArrayList();
        for (Object next : iterable) {
            if (!a2.contains(next)) {
                arrayList.add(next);
            }
        }
        return (List) arrayList;
    }

    public static final <T> List<T> a(Collection<? extends T> collection, T t) {
        k.h(collection, "$this$plus");
        ArrayList arrayList = new ArrayList(collection.size() + 1);
        arrayList.addAll(collection);
        arrayList.add(t);
        return arrayList;
    }

    public static final <T> List<T> b(Collection<? extends T> collection, Iterable<? extends T> iterable) {
        k.h(collection, "$this$plus");
        k.h(iterable, "elements");
        if (iterable instanceof Collection) {
            Collection collection2 = (Collection) iterable;
            ArrayList arrayList = new ArrayList(collection.size() + collection2.size());
            arrayList.addAll(collection);
            arrayList.addAll(collection2);
            return arrayList;
        }
        ArrayList arrayList2 = new ArrayList(collection);
        m.a(arrayList2, iterable);
        return arrayList2;
    }

    public static final <T, A extends Appendable> A a(Iterable<? extends T> iterable, A a2, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i, CharSequence charSequence4, Function1<? super T, ? extends CharSequence> function1) {
        k.h(iterable, "$this$joinTo");
        k.h(a2, "buffer");
        k.h(charSequence, "separator");
        k.h(charSequence2, "prefix");
        k.h(charSequence3, "postfix");
        k.h(charSequence4, "truncated");
        a2.append(charSequence2);
        int i2 = 0;
        for (Object next : iterable) {
            i2++;
            if (i2 > 1) {
                a2.append(charSequence);
            }
            if (i >= 0 && i2 > i) {
                break;
            }
            l.a(a2, next, function1);
        }
        if (i >= 0 && i2 > i) {
            a2.append(charSequence4);
        }
        a2.append(charSequence3);
        return a2;
    }

    public static /* synthetic */ String a(Iterable iterable, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i, CharSequence charSequence4, Function1 function1, int i2) {
        if ((i2 & 1) != 0) {
        }
        CharSequence charSequence5 = charSequence;
        if ((i2 & 2) != 0) {
            charSequence2 = "";
        }
        CharSequence charSequence6 = charSequence2;
        if ((i2 & 4) != 0) {
            charSequence3 = "";
        }
        CharSequence charSequence7 = charSequence3;
        int i3 = (i2 & 8) != 0 ? -1 : i;
        if ((i2 & 16) != 0) {
            charSequence4 = "...";
        }
        CharSequence charSequence8 = charSequence4;
        if ((i2 & 32) != 0) {
            function1 = null;
        }
        return m.a(iterable, charSequence5, charSequence6, charSequence7, i3, charSequence8, function1);
    }

    public static final <T> String a(Iterable<? extends T> iterable, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i, CharSequence charSequence4, Function1<? super T, ? extends CharSequence> function1) {
        k.h(iterable, "$this$joinToString");
        k.h(charSequence, "separator");
        k.h(charSequence2, "prefix");
        k.h(charSequence3, "postfix");
        k.h(charSequence4, "truncated");
        String sb = ((StringBuilder) m.a(iterable, new StringBuilder(), charSequence, charSequence2, charSequence3, i, charSequence4, function1)).toString();
        k.g(sb, "joinTo(StringBuilder(), …ed, transform).toString()");
        return sb;
    }

    public static final <T> Sequence<T> x(Iterable<? extends T> iterable) {
        k.h(iterable, "$this$asSequence");
        return new a(iterable);
    }

    public static final double y(Iterable<Long> iterable) {
        k.h(iterable, "$this$average");
        double d = 0.0d;
        int i = 0;
        for (Long longValue : iterable) {
            double longValue2 = (double) longValue.longValue();
            Double.isNaN(longValue2);
            d += longValue2;
            i++;
            if (i < 0) {
                m.DZ();
            }
        }
        if (i == 0) {
            g gVar = g.bkB;
            return g.Ek();
        }
        double d2 = (double) i;
        Double.isNaN(d2);
        return d / d2;
    }

    public static final int z(Iterable<Integer> iterable) {
        k.h(iterable, "$this$sum");
        int i = 0;
        for (Integer intValue : iterable) {
            i += intValue.intValue();
        }
        return i;
    }

    public static final long A(Iterable<Long> iterable) {
        k.h(iterable, "$this$sum");
        long j = 0;
        for (Long longValue : iterable) {
            j += longValue.longValue();
        }
        return j;
    }

    public static final float B(Iterable<Float> iterable) {
        k.h(iterable, "$this$sum");
        float f = 0.0f;
        for (Float floatValue : iterable) {
            f += floatValue.floatValue();
        }
        return f;
    }

    public static final <T> List<T> c(Iterable<? extends T> iterable, int i) {
        k.h(iterable, "$this$take");
        int i2 = 0;
        if (!(i >= 0)) {
            throw new IllegalArgumentException(("Requested element count " + i + " is less than zero.").toString());
        } else if (i == 0) {
            return y.bjT;
        } else {
            if (iterable instanceof Collection) {
                if (i >= ((Collection) iterable).size()) {
                    return m.r(iterable);
                }
                if (i == 1) {
                    return m.ba(m.l(iterable));
                }
            }
            ArrayList arrayList = new ArrayList(i);
            for (Object next : iterable) {
                int i3 = i2 + 1;
                if (i2 == i) {
                    break;
                }
                arrayList.add(next);
                i2 = i3;
            }
            return m.Z(arrayList);
        }
    }
}
