package kotlin;

/* compiled from: UninitializedPropertyAccessException.kt */
public final class t extends RuntimeException {
    public t() {
    }

    public t(String str) {
        super(str);
    }
}
