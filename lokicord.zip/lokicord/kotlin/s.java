package kotlin;

/* compiled from: Lazy.kt */
public final class s {
    public static final s bjD = new s();

    private s() {
    }
}
