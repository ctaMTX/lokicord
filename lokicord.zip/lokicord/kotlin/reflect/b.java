package kotlin.reflect;

/* compiled from: KClass.kt */
public interface b<T> extends KDeclarationContainer, a {
}
