package kotlin.reflect;

import java.lang.annotation.Annotation;
import java.util.List;

/* compiled from: KAnnotatedElement.kt */
public interface a {
    List<Annotation> getAnnotations();
}
