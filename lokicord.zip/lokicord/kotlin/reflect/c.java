package kotlin.reflect;

/* compiled from: KProperty.kt */
public interface c<T, R> extends KMutableProperty<R>, d<T, R> {
}
