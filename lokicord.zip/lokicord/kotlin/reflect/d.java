package kotlin.reflect;

import kotlin.jvm.functions.Function1;
import kotlin.reflect.KProperty;

/* compiled from: KProperty.kt */
public interface d<T, R> extends Function1<T, R>, KProperty<R> {

    /* compiled from: KProperty.kt */
    public interface a<T, R> extends Function1<T, R>, KProperty.Getter<R> {
    }

    a<T, R> Eq();

    R get(T t);
}
