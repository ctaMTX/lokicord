package kotlin.reflect;

/* compiled from: KType.kt */
public interface KType extends a {
}
