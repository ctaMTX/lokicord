package kotlin.reflect;

import kotlin.c;

/* compiled from: KFunction.kt */
public interface KFunction<R> extends c<R>, KCallable<R> {
    boolean isExternal();

    boolean isInfix();

    boolean isInline();

    boolean isOperator();

    boolean isSuspend();
}
