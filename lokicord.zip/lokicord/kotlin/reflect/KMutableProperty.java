package kotlin.reflect;

import kotlin.Unit;

/* compiled from: KProperty.kt */
public interface KMutableProperty<R> extends KProperty<R> {

    /* compiled from: KProperty.kt */
    public interface Setter<R> extends KFunction<Unit> {
    }
}
