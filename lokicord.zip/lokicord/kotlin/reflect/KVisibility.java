package kotlin.reflect;

/* compiled from: KVisibility.kt */
public enum KVisibility {
    PUBLIC,
    PROTECTED,
    INTERNAL,
    PRIVATE
}
