package kotlin.reflect;

/* compiled from: KDeclarationContainer.kt */
public interface KDeclarationContainer {
}
