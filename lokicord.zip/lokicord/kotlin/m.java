package kotlin;

import java.io.Serializable;
import kotlin.jvm.internal.k;

/* compiled from: Result.kt */
public final class m<T> implements Serializable {
    public static final a bjB = new a((byte) 0);
    private final Object value;

    public static Object aZ(Object obj) {
        return obj;
    }

    public final boolean equals(Object obj) {
        return (obj instanceof m) && k.n(this.value, ((m) obj).value);
    }

    public final int hashCode() {
        Object obj = this.value;
        if (obj != null) {
            return obj.hashCode();
        }
        return 0;
    }

    public final String toString() {
        Object obj = this.value;
        if (obj instanceof b) {
            return obj.toString();
        }
        return "Success(" + obj + ')';
    }

    public static final boolean aW(Object obj) {
        return !(obj instanceof b);
    }

    public static final boolean aX(Object obj) {
        return obj instanceof b;
    }

    public static final Throwable aY(Object obj) {
        if (obj instanceof b) {
            return ((b) obj).exception;
        }
        return null;
    }

    /* compiled from: Result.kt */
    public static final class a {
        private a() {
        }

        public /* synthetic */ a(byte b2) {
            this();
        }
    }

    /* compiled from: Result.kt */
    public static final class b implements Serializable {
        public final Throwable exception;

        public b(Throwable th) {
            k.h(th, "exception");
            this.exception = th;
        }

        public final boolean equals(Object obj) {
            return (obj instanceof b) && k.n(this.exception, ((b) obj).exception);
        }

        public final int hashCode() {
            return this.exception.hashCode();
        }

        public final String toString() {
            return "Failure(" + this.exception + ')';
        }
    }
}
