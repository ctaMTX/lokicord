package kotlin.properties;

/* compiled from: Delegates.kt */
public final class a {
    public static final a bkI = new a();

    private a() {
    }
}
