package kotlin.properties;

import kotlin.jvm.internal.k;
import kotlin.reflect.KProperty;

/* compiled from: ObservableProperty.kt */
public abstract class b<T> implements ReadWriteProperty<Object, T> {
    private T value;

    /* access modifiers changed from: protected */
    public void afterChange(KProperty<?> kProperty, T t, T t2) {
        k.h(kProperty, "property");
    }

    /* access modifiers changed from: protected */
    public boolean beforeChange(KProperty<?> kProperty, T t, T t2) {
        k.h(kProperty, "property");
        return true;
    }

    public b(T t) {
        this.value = t;
    }

    public T getValue(Object obj, KProperty<?> kProperty) {
        k.h(kProperty, "property");
        return this.value;
    }

    public void setValue(Object obj, KProperty<?> kProperty, T t) {
        k.h(kProperty, "property");
        T t2 = this.value;
        if (beforeChange(kProperty, t2, t)) {
            this.value = t;
            afterChange(kProperty, t2, t);
        }
    }
}
