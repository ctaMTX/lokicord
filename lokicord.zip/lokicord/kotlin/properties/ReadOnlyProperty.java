package kotlin.properties;

import kotlin.reflect.KProperty;

/* compiled from: Interfaces.kt */
public interface ReadOnlyProperty<R, T> {
    T getValue(R r, KProperty<?> kProperty);
}
