package kotlin.b;

/* compiled from: _Comparisons.kt */
class d extends c {
}
