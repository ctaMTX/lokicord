package kotlin.b;

public final class a extends d {
}
