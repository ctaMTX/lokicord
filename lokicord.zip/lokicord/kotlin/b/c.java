package kotlin.b;

/* compiled from: _ComparisonsJvm.kt */
class c extends b {
}
