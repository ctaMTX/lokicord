package kotlin.b;

import java.util.Comparator;
import kotlin.jvm.functions.Function1;

/* compiled from: Comparisons.kt */
public class b {
    public static final <T extends Comparable<?>> int a(T t, T t2) {
        if (t == t2) {
            return 0;
        }
        if (t == null) {
            return -1;
        }
        if (t2 == null) {
            return 1;
        }
        return t.compareTo(t2);
    }

    /* compiled from: Comparisons.kt */
    public static final class a<T> implements Comparator<T> {
        final /* synthetic */ Function1[] bkc;

        public a(Function1[] function1Arr) {
            this.bkc = function1Arr;
        }

        public final int compare(T t, T t2) {
            for (Function1 function1 : this.bkc) {
                int a2 = a.a((Comparable) function1.invoke(t), (Comparable) function1.invoke(t2));
                if (a2 != 0) {
                    return a2;
                }
            }
            return 0;
        }
    }

    /* renamed from: kotlin.b.b$b  reason: collision with other inner class name */
    /* compiled from: Comparisons.kt */
    public static final class C0115b<T> implements Comparator<T> {
        final /* synthetic */ Comparator $comparator;
        final /* synthetic */ Comparator bkd;

        public C0115b(Comparator comparator, Comparator comparator2) {
            this.bkd = comparator;
            this.$comparator = comparator2;
        }

        public final int compare(T t, T t2) {
            int compare = this.bkd.compare(t, t2);
            if (compare != 0) {
                return compare;
            }
            return this.$comparator.compare(t, t2);
        }
    }
}
