package kotlin;

import java.io.Serializable;

/* compiled from: Lazy.kt */
public final class d<T> implements Serializable, Lazy<T> {
    private final T value;

    public d(T t) {
        this.value = t;
    }

    public final T getValue() {
        return this.value;
    }

    public final String toString() {
        return String.valueOf(getValue());
    }
}
