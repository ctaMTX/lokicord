package kotlin;

/* compiled from: Exceptions.kt */
public final class a extends b {
}
