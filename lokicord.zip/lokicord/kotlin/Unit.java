package kotlin;

/* compiled from: Unit.kt */
public final class Unit {
    public static final Unit bjE = new Unit();

    public final String toString() {
        return "kotlin.Unit";
    }

    private Unit() {
    }
}
