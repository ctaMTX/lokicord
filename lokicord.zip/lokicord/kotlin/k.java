package kotlin;

/* compiled from: NoWhenBranchMatchedException.kt */
public final class k extends RuntimeException {
}
