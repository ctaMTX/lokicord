package kotlin.f;

import java.util.Random;
import kotlin.jvm.internal.k;

/* compiled from: PlatformRandom.kt */
public final class b extends a {
    private final a bkJ = new a();

    /* compiled from: PlatformRandom.kt */
    public static final class a extends ThreadLocal<Random> {
        a() {
        }

        public final /* synthetic */ Object initialValue() {
            return new Random();
        }
    }

    public final Random Er() {
        Object obj = this.bkJ.get();
        k.g(obj, "implStorage.get()");
        return (Random) obj;
    }
}
