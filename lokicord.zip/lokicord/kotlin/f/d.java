package kotlin.f;

/* compiled from: Random.kt */
public final class d {
    public static final int W(int i, int i2) {
        return (i >>> (32 - i2)) & ((-i2) >> 31);
    }
}
