package kotlin.f;

import java.util.Random;
import kotlin.jvm.internal.k;

/* compiled from: PlatformRandom.kt */
public abstract class a extends c {
    public abstract Random Er();

    public final int dn(int i) {
        return d.W(Er().nextInt(), i);
    }

    public final int nextInt() {
        return Er().nextInt();
    }

    public final long nextLong() {
        return Er().nextLong();
    }

    public final byte[] A(byte[] bArr) {
        k.h(bArr, "array");
        Er().nextBytes(bArr);
        return bArr;
    }
}
