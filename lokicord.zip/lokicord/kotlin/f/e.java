package kotlin.f;

/* compiled from: XorWowRandom.kt */
public final class e extends c {
    private int bkO;
    private int v;
    private int w;
    private int x;
    private int y;
    private int z;

    private e(int i, int i2, int i3, int i4) {
        this.x = i;
        this.y = i2;
        this.z = 0;
        this.w = 0;
        this.v = i3;
        this.bkO = i4;
        if (((((this.x | this.y) | this.z) | this.w) | this.v) != 0) {
            for (int i5 = 0; i5 < 64; i5++) {
                nextInt();
            }
            return;
        }
        throw new IllegalArgumentException("Initial state must have at least one non-zero element.".toString());
    }

    public e(int i, int i2) {
        this(i, i2, i ^ -1, (i << 10) ^ (i2 >>> 4));
    }

    public final int nextInt() {
        int i = this.x;
        int i2 = i ^ (i >>> 2);
        this.x = this.y;
        this.y = this.z;
        this.z = this.w;
        int i3 = this.v;
        this.w = i3;
        int i4 = ((i2 ^ (i2 << 1)) ^ i3) ^ (i3 << 4);
        this.v = i4;
        this.bkO += 362437;
        return i4 + this.bkO;
    }

    public final int dn(int i) {
        return d.W(nextInt(), i);
    }
}
