package kotlin.f;

import kotlin.jvm.internal.k;

/* compiled from: Random.kt */
public abstract class c {
    /* access modifiers changed from: package-private */
    public static final c bkK = kotlin.c.a.Eg();
    public static final a bkL = a.bkN;
    public static final b bkM = new b((byte) 0);

    public abstract int dn(int i);

    public int nextInt() {
        return dn(32);
    }

    public long nextLong() {
        return (((long) nextInt()) << 32) + ((long) nextInt());
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x001a  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0084  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public byte[] l(byte[] r7, int r8, int r9) {
        /*
            r6 = this;
            java.lang.String r0 = "array"
            kotlin.jvm.internal.k.h(r7, r0)
            int r0 = r7.length
            r1 = 0
            r2 = 1
            if (r8 >= 0) goto L_0x000b
            goto L_0x0015
        L_0x000b:
            if (r0 < r8) goto L_0x0015
            int r0 = r7.length
            if (r9 >= 0) goto L_0x0011
            goto L_0x0015
        L_0x0011:
            if (r0 < r9) goto L_0x0015
            r0 = 1
            goto L_0x0016
        L_0x0015:
            r0 = 0
        L_0x0016:
            java.lang.String r3 = "fromIndex ("
            if (r0 == 0) goto L_0x0084
            if (r8 > r9) goto L_0x001d
            goto L_0x001e
        L_0x001d:
            r2 = 0
        L_0x001e:
            if (r2 == 0) goto L_0x005f
            int r0 = r9 - r8
            int r0 = r0 / 4
            r2 = r8
            r8 = 0
        L_0x0026:
            if (r8 >= r0) goto L_0x0049
            int r3 = r6.nextInt()
            byte r4 = (byte) r3
            r7[r2] = r4
            int r4 = r2 + 1
            int r5 = r3 >>> 8
            byte r5 = (byte) r5
            r7[r4] = r5
            int r4 = r2 + 2
            int r5 = r3 >>> 16
            byte r5 = (byte) r5
            r7[r4] = r5
            int r4 = r2 + 3
            int r3 = r3 >>> 24
            byte r3 = (byte) r3
            r7[r4] = r3
            int r2 = r2 + 4
            int r8 = r8 + 1
            goto L_0x0026
        L_0x0049:
            int r9 = r9 - r2
            int r8 = r9 * 8
            int r8 = r6.dn(r8)
        L_0x0050:
            if (r1 >= r9) goto L_0x005e
            int r0 = r2 + r1
            int r3 = r1 * 8
            int r3 = r8 >>> r3
            byte r3 = (byte) r3
            r7[r0] = r3
            int r1 = r1 + 1
            goto L_0x0050
        L_0x005e:
            return r7
        L_0x005f:
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>(r3)
            r7.append(r8)
            java.lang.String r8 = ") must be not greater than toIndex ("
            r7.append(r8)
            r7.append(r9)
            java.lang.String r8 = ")."
            r7.append(r8)
            java.lang.String r7 = r7.toString()
            java.lang.IllegalArgumentException r8 = new java.lang.IllegalArgumentException
            java.lang.String r7 = r7.toString()
            r8.<init>(r7)
            java.lang.Throwable r8 = (java.lang.Throwable) r8
            throw r8
        L_0x0084:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>(r3)
            r0.append(r8)
            java.lang.String r8 = ") or toIndex ("
            r0.append(r8)
            r0.append(r9)
            java.lang.String r8 = ") are out of range: 0.."
            r0.append(r8)
            int r7 = r7.length
            r0.append(r7)
            r7 = 46
            r0.append(r7)
            java.lang.String r7 = r0.toString()
            java.lang.IllegalArgumentException r8 = new java.lang.IllegalArgumentException
            java.lang.String r7 = r7.toString()
            r8.<init>(r7)
            java.lang.Throwable r8 = (java.lang.Throwable) r8
            goto L_0x00b3
        L_0x00b2:
            throw r8
        L_0x00b3:
            goto L_0x00b2
        */
        throw new UnsupportedOperationException("Method not decompiled: kotlin.f.c.l(byte[], int, int):byte[]");
    }

    public byte[] A(byte[] bArr) {
        k.h(bArr, "array");
        return l(bArr, 0, bArr.length);
    }

    /* renamed from: do  reason: not valid java name */
    public byte[] m22do(int i) {
        return A(new byte[i]);
    }

    /* compiled from: Random.kt */
    public static final class b extends c {
        private b() {
        }

        public /* synthetic */ b(byte b2) {
            this();
        }

        public final int dn(int i) {
            return c.bkK.dn(i);
        }

        public final int nextInt() {
            return c.bkK.nextInt();
        }

        public final long nextLong() {
            return c.bkK.nextLong();
        }

        public final byte[] A(byte[] bArr) {
            k.h(bArr, "array");
            return c.bkK.A(bArr);
        }

        /* renamed from: do  reason: not valid java name */
        public final byte[] m23do(int i) {
            return c.bkK.m22do(i);
        }

        public final byte[] l(byte[] bArr, int i, int i2) {
            k.h(bArr, "array");
            return c.bkK.l(bArr, i, i2);
        }
    }

    static {
        kotlin.c.a aVar = kotlin.c.b.bkx;
    }

    /* compiled from: Random.kt */
    public static final class a extends c {
        public static final a bkN = new a();

        private a() {
        }

        public final int dn(int i) {
            return c.bkK.dn(i);
        }
    }
}
