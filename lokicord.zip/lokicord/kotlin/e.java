package kotlin;

/* compiled from: KotlinNullPointerException.kt */
public final class e extends NullPointerException {
}
